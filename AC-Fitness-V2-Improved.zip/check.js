try{var t=JSON.parse(localStorage.getItem('acfv2_theme')||'{}'),r=document.documentElement,m=t.mode==='auto'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):(t.mode||'dark');r.setAttribute('data-theme',m);if(t.accent&&t.accent!=='violet')r.setAttribute('data-accent',t.accent);}catch(e){}



// ══════════════════════════════════════════════════════
// STATE
// ══════════════════════════════════════════════════════
let APP={
  user:null,weights:[],measurements:[],workouts:[],
  water:{},activeWorkout:null,challenges:{},customProgram:null,
  fatigue:{},dailyNotes:{},
  _wtTimer:null,_restTimer:null,_restSecs:90
};
const save=()=>{try{localStorage.setItem('acfv2',JSON.stringify(APP,(k,v)=>(k==='_wtTimer'||k==='_restTimer')?undefined:v));}catch(e){if(!window._sw){window._sw=1;try{toast('⚠️ تعذّر حفظ بياناتك على الجهاز (التخزين ممتلئ أو غير متاح) — صدّر نسخة احتياطية الآن','⚠️');}catch(_){}}}};
// ══════════════════════════════════════════════════════
// نظام الخطط المتعددة — يستبدل APP.customProgram (خانة واحدة تُستبدَل في كل
// مرة) بمصفوفة APP.plans، بحيث يمكن حفظ أكثر من خطة (من الذكاء الاصطناعي عند
// التسجيل، ومن جداول يدخلها المستخدم يدوياً) في نفس الوقت، وتحديد أيها "أساسية"
// (وهي ما يُشغّله "ابدأ التمرين")، وحذف أي منها لوحدها.
// خطة النظام الجاهز (buildProgram) ليست جزءاً من هذه المصفوفة عمداً — تبقى
// دائماً كضمانة تعمل فوراً ولا تُحذف، حتى لو حُذفت كل الخطط الأخرى.
// ══════════════════════════════════════════════════════
function migrateLegacyPlans(){
  if(Array.isArray(APP.plans))return; // تمت الهجرة مسبقاً — لا تكرارها
  APP.plans=[];
  if(APP.customProgram){
    const cp=APP.customProgram;
    APP.plans.push({
      id:genPlanId(),
      type:cp.aiGenerated?'ai-onboarding':'manual',
      name:cp.name||'خطتي',
      text:cp.text||'',
      parsed:cp.parsed||null,
      isPrimary:!!cp.aiGenerated,
      createdAt:cp.analyzedAt||cp.savedAt||new Date().toISOString()
    });
  }
  delete APP.customProgram;
}
function genPlanId(){return'plan_'+Date.now()+Math.random().toString(36).slice(2,7);}
function getPrimaryPlan(){return(APP.plans||[]).find(p=>p.isPrimary&&p.parsed?.days?.length)||null;}
function getPlanById(id){return(APP.plans||[]).find(p=>p.id===id);}
function setPrimaryPlan(id){(APP.plans||[]).forEach(p=>{p.isPrimary=(p.id===id);});save();renderCustomBanner();renderHome();toast('⭐ أصبحت هذه خطتك الأساسية');}
function deletePlan(id){
  const p=getPlanById(id);
  if(!p)return;
  if(!confirm(`حذف "${p.name}"؟`))return;
  APP.plans=(APP.plans||[]).filter(x=>x.id!==id);
  save();
  renderCustomBanner();renderHome();
  toast('🗑 تم حذف الخطة');
}
function deleteGeneratedProgram(){
  const hasActivePlan=!!getPrimaryPlan();
  const msg=hasActivePlan
    ?'حذف البرنامج الجاهز؟ خطتك المخصصة النشطة ستبقى تعمل بلا أي تغيير.'
    :'⚠️ ليس لديك خطة مخصصة نشطة حالياً — إن حذفت هذا البرنامج، لن يبقى لديك أي برنامج تدريبي حتى تُضيف واحداً أو تُعيد الإعداد. حذف؟';
  if(!confirm(msg))return;
  APP.user.program=null;
  save();
  renderPrograms();renderHome();
  toast('🗑 تم حذف البرنامج الجاهز');
}
const load=()=>{try{const d=localStorage.getItem('acfv2');if(d)Object.assign(APP,JSON.parse(d));APP._wtTimer=null;APP._restTimer=null;migrateLegacyPlans();}catch(e){}};
const showAppShell=()=>{['hdr','nav','app'].forEach(id=>{const e=document.getElementById(id);if(e)e.style.display=id==='app'?'block':id==='nav'?'flex':'flex';});};

// ══════════════════════════════════════════════════════
// SPORTS DATABASE
// ══════════════════════════════════════════════════════
const SPORTS=[
  {id:'bodybuilding',name:'كمال أجسام',eng:'Bodybuilding',ico:'💪'},
  {id:'powerlifting',name:'رفع الأثقال',eng:'Powerlifting',ico:'🔩'},
  {id:'calisthenics',name:'كاليستنكس',eng:'Calisthenics',ico:'🤸'},
  {id:'crossfit',name:'كروسفيت',eng:'CrossFit',ico:'⚡'},
  {id:'boxing',name:'ملاكمة',eng:'Boxing',ico:'🥊'},
  {id:'wrestling',name:'مصارعة',eng:'Wrestling',ico:'🤼'},
  {id:'bjj',name:'جوجيتسو',eng:'BJJ',ico:'🥋'},
  {id:'mma',name:'MMA',eng:'MMA',ico:'🥋'},
  {id:'running',name:'الجري',eng:'Running',ico:'🏃'},
  {id:'swimming',name:'السباحة',eng:'Swimming',ico:'🏊'},
  {id:'football',name:'كرة القدم',eng:'Football',ico:'⚽'},
  {id:'basketball',name:'كرة السلة',eng:'Basketball',ico:'🏀'},
  {id:'cycling',name:'دراجات',eng:'Cycling',ico:'🚴'},
  {id:'general',name:'لياقة عامة',eng:'General Fitness',ico:'🌟'}
];

// ══════════════════════════════════════════════════════
// EXERCISE DATABASE (50+ exercises)
// ══════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════
// EXERCISE POSE ILLUSTRATIONS — self-contained animated SVG
// stick figures (no external images/network dependency).
// Each pose has two joint states (A/B); CSS crossfades between
// them on a loop to show the movement pattern.
// ══════════════════════════════════════════════════════
const POSES={
  squat:{
    A:{head:[50,15],shL:[43,25],shR:[57,25],elL:[36,38],elR:[64,38],haL:[34,52],haR:[66,52],hip:[50,48],knL:[44,68],knR:[56,68],ftL:[43,88],ftR:[57,88]},
    B:{head:[50,32],shL:[43,42],shR:[57,42],elL:[30,46],elR:[70,46],haL:[26,52],haR:[74,52],hip:[50,60],knL:[36,66],knR:[64,66],ftL:[42,88],ftR:[58,88]}
  },
  lunge:{
    A:{head:[46,15],shL:[39,25],shR:[53,25],elL:[35,38],elR:[57,38],haL:[33,50],haR:[59,50],hip:[46,48],knL:[38,66],knR:[58,64],ftL:[36,88],ftR:[68,80]},
    B:{head:[50,22],shL:[43,32],shR:[57,32],elL:[38,44],elR:[62,44],haL:[35,55],haR:[65,55],hip:[50,52],knL:[38,70],knR:[64,58],ftL:[34,88],ftR:[70,82]}
  },
  hinge:{
    A:{head:[50,15],shL:[43,25],shR:[57,25],elL:[41,40],elR:[59,40],haL:[40,55],haR:[60,55],hip:[50,48],knL:[44,68],knR:[56,68],ftL:[43,88],ftR:[57,88]},
    B:{head:[68,30],shL:[62,35],shR:[72,35],elL:[57,50],elR:[75,50],haL:[52,62],haR:[80,62],hip:[50,50],knL:[46,68],knR:[56,68],ftL:[43,88],ftR:[57,88]}
  },
  hip_lift:{
    A:{head:[20,60],shL:[32,60],shR:[32,52],elL:[26,68],elR:[26,44],haL:[20,74],haR:[20,38],hip:[50,64],knL:[68,52],knR:[68,58],ftL:[84,64],ftR:[84,58]},
    B:{head:[20,60],shL:[32,60],shR:[32,52],elL:[26,68],elR:[26,44],haL:[20,74],haR:[20,38],hip:[50,44],knL:[68,52],knR:[68,58],ftL:[84,64],ftR:[84,58]}
  },
  push_h:{
    A:{head:[20,42],sh:[32,46],el:[50,60],ha:[64,76],hip:[48,52],kn:[66,62],ft:[86,68]},
    B:{head:[20,60],sh:[32,62],el:[52,70],ha:[64,76],hip:[48,66],kn:[66,70],ft:[86,72]}
  },
  push_v:{
    A:{head:[50,20],shL:[43,30],shR:[57,30],elL:[36,42],elR:[64,42],haL:[38,54],haR:[62,54],hip:[50,54],ftL:[44,88],ftR:[56,88]},
    B:{head:[50,20],shL:[43,30],shR:[57,30],elL:[38,20],elR:[62,20],haL:[42,8],haR:[58,8],hip:[50,54],ftL:[44,88],ftR:[56,88]}
  },
  pull:{
    A:{head:[50,20],shL:[43,30],shR:[57,30],elL:[34,36],elR:[66,36],haL:[24,32],haR:[76,32],hip:[50,54],ftL:[44,88],ftR:[56,88]},
    B:{head:[50,20],shL:[43,30],shR:[57,30],elL:[38,34],elR:[62,34],haL:[40,26],haR:[60,26],hip:[50,54],ftL:[44,88],ftR:[56,88]}
  },
  curl:{
    A:{head:[50,20],shL:[43,30],shR:[57,30],elL:[41,48],elR:[59,48],haL:[39,66],haR:[61,66],hip:[50,54],ftL:[44,88],ftR:[56,88]},
    B:{head:[50,20],shL:[43,30],shR:[57,30],elL:[41,48],elR:[59,48],haL:[36,28],haR:[64,28],hip:[50,54],ftL:[44,88],ftR:[56,88]}
  },
  calf:{
    A:{head:[50,18],shL:[43,28],shR:[57,28],elL:[41,42],elR:[59,42],haL:[40,56],haR:[60,56],hip:[50,52],knL:[44,70],knR:[56,70],ftL:[43,88],ftR:[57,88]},
    B:{head:[50,12],shL:[43,22],shR:[57,22],elL:[41,36],elR:[59,36],haL:[40,50],haR:[60,50],hip:[50,46],knL:[44,66],knR:[56,66],ftL:[43,86],ftR:[57,86]}
  },
  core:{
    A:{head:[18,46],sh:[32,48],el:[46,58],ha:[58,66],hip:[52,50],kn:[70,54],ft:[90,56]},
    B:{head:[24,36],sh:[36,42],el:[48,54],ha:[58,66],hip:[52,50],kn:[66,44],ft:[82,34]}
  },
  cardio:{
    A:{head:[44,18],shL:[37,28],shR:[51,28],elL:[28,22],elR:[54,40],haL:[18,14],haR:[58,54],hip:[44,50],knL:[36,68],knR:[54,64],ftL:[30,86],ftR:[64,82]},
    B:{head:[52,20],shL:[45,30],shR:[59,30],elL:[64,36],elR:[50,22],haL:[76,48],haR:[46,12],hip:[48,52],knL:[58,66],knR:[38,66],ftL:[66,84],ftR:[28,84]}
  }
};
// Map every exercise ID to the pose archetype that best represents its movement.
// Match a free-text exercise name (as extracted by the AI from a custom
// program) back to a real EX-database key. Without this, any exercise from
// a custom/AI-analyzed program is a bare {name} string disconnected from
// the database — losing its timer, icon, guidance text, suggested reps,
// and rest time entirely, even when the name is an exact match like "بلانك".
// إشارة إضافية مستقلة لاكتشاف تمارين "الثبات/الوقت" (بلانك وأشباهه) بالاسم
// مباشرة، حتى لو لم يُطابَق التمرين بدقة كافية لقاعدة البيانات — نُبقي معيار
// matchExerciseId صارماً (فالمطابقة الخاطئة تُظهر تعليمات وصورة تمرين مختلف
// تماماً)، لكن معرفة "هل هو تمرين مؤقّت" أخف خطورة فنسمح فيها بكلمات مفتاحية.
function looksLikeTimedHold(name){
  if(!name)return false;
  return/بلانك|plank|ثبات|hold|إطالة|تمديد|stretch|شادو|shadow|نط الحبل|jump rope|هاي نيز|high knees|ماونتن|mountain climber/i.test(name);
}
function matchExerciseId(name){
  if(!name)return null;
  const norm=s=>String(s).trim().toLowerCase().replace(/[إأآا]/g,'ا').replace(/ة/g,'ه').replace(/\s+/g,' ');
  const target=norm(name);
  if(!target)return null;
  // مطابقة تامة أولاً — الأدق والأكثر أماناً.
  for(const id in EX){
    const ex=EX[id];
    if(norm(ex.n)===target||norm(ex.e)===target)return id;
  }
  // مطابقة تقريبية بتشابه الكلمات (Jaccard) بدل "أول تطابق جزئي يفوز" —
  // الطريقة القديمة كانت تُرجع أول تمرين يحتوي اسمه كجزء من الاسم الأطول أو
  // العكس، فكانت كل تمارين الأرجل التي تحتوي كلمة "سكوات" (بلغاري، جامبى،
  // بديل...) تُطابَق فوراً بتمرين "سكوات" العادي بصرف النظر عن باقي الاسم.
  // الآن نقارن كل المرشّحين ونختار الأعلى تطابقاً فعلياً، مع حد أدنى يمنع
  // قبول تطابق كلمة عامة واحدة بين اسمين مختلفين تماماً في الباقي.
  const targetWords=target.split(' ').filter(Boolean);
  const targetSet=new Set(targetWords);
  let bestId=null,bestScore=0;
  for(const id in EX){
    const ex=EX[id];
    for(const cand of[norm(ex.n),norm(ex.e)]){
      if(!cand)continue;
      const candWords=cand.split(' ').filter(Boolean);
      const candSet=new Set(candWords);
      const shared=candWords.filter(w=>targetSet.has(w)).length;
      if(!shared)continue;
      const union=new Set([...targetSet,...candSet]).size;
      const score=shared/union;
      if(score>bestScore){bestScore=score;bestId=id;}
    }
  }
  return bestScore>=0.34?bestId:null;
}
const EX_POSE={
  bench_press:'push_h',db_press:'push_h',pushup:'push_h',incline_pushup:'push_h',dip:'push_h',diamond_pushup:'push_h',cable_fly:'push_h',db_fly:'push_h',
  ohp:'push_v',db_ohp:'push_v',lateral_raise:'push_v',
  deadlift:'hinge',rdl:'hinge',
  hip_thrust:'hip_lift',glute_bridge:'hip_lift',
  pullup:'pull',lat_pulldown:'pull',db_row:'pull',cable_row:'pull',inverted_row:'pull',face_pull:'pull',band_pull_apart:'pull',
  barbell_curl:'curl',db_curl:'curl',hammer_curl:'curl',band_curl:'curl',tricep_pushdown:'curl',skull_crusher:'curl',
  squat:'squat',goblet_squat:'squat',bodyweight_squat:'squat',leg_press:'squat',jump_squat:'squat',leg_curl:'squat',
  lunge:'lunge',
  calf_raise:'calf',
  plank:'core',ab_wheel:'core',leg_raise:'core',crunch:'core',mountain_climber:'core',dead_bug:'core',
  burpee:'cardio',shadowboxing:'cardio',heavy_bag:'cardio',farmers_walk:'cardio'
};
function poseLine(p1,p2){return`<line x1="${p1[0]}" y1="${p1[1]}" x2="${p2[0]}" y2="${p2[1]}"/>`;}
// عندما لا يُطابَق التمرين بقاعدة البيانات (برامج مخصصة حلّلها الذكاء الاصطناعي
// مثلاً)، لا يبقى بلا صورة تعبّر عنه — نخمّن فئة الحركة من اسمه (عربي أو
// إنجليزي) ونعرض رسم الوضعية المناسب لتلك الفئة بدل أيقونة عامة لا تدل عليه.
const POSE_KEYWORDS=[
  [/overhead|shoulder.?press|أوفرهيد|كتف.*(دفع|برس)/i,'push_v'],
  [/press|بنش|ضغط|بوش|push.?up|dip|ديب|فلاي|fly/i,'push_h'],
  [/pulldown|بولداون|pull.?up|بول.?آب|عقلة|row|رو|سحب|شد|face.?pull/i,'pull'],
  [/curl|كيرل|بايسبس|ترايسبس|pushdown|extension|إكستنشن/i,'curl'],
  [/deadlift|ديدليفت|رفعة|رومانيا|rdl|hinge/i,'hinge'],
  [/thrust|bridge|ثراست|بريدج|hip/i,'hip_lift'],
  [/lunge|لنج|لانج/i,'lunge'],
  [/squat|سكوات|قرفصاء/i,'squat'],
  [/calf|كالف|ربلة/i,'calf'],
  [/plank|بلانك|crunch|كرنش|raise|ريز|بطن|core|دراجة|bicycle/i,'core'],
  [/burpee|بربي|cardio|كارديو|jump|قفز|shadow|ملاكمة|boxing|جري|run/i,'cardio'],
];
function guessPoseKey(name){
  if(!name)return null;
  for(const[re,key]of POSE_KEYWORDS){if(re.test(name)&&POSES[key])return key;}
  return null;
}
POSES.bench={A:{head:[19,59],sh:[30,59],el:[37,66],ha:[32,53],hip:[56,59],kn:[80,60],ft:[78,86]},B:{head:[19,59],sh:[30,59],el:[31,47],ha:[31,34],hip:[56,59],kn:[80,60],ft:[78,86]}};
POSES.pushup={A:{head:[15,48],sh:[24,52],el:[24,64],ha:[24,76],hip:[56,64],kn:[72,70],ft:[88,76]},B:{head:[15,63],sh:[24,68],el:[36,67],ha:[24,76],hip:[56,70],kn:[72,73],ft:[88,76]}};
Object.assign(EX_POSE,{bench_press:'bench',db_press:'bench',db_fly:'bench',pushup:'pushup',incline_pushup:'pushup',diamond_pushup:'pushup'});
const BENCH_IDS=new Set(['bench_press','db_press','db_fly']);
const PC={skin:'#F2C9A0',shirt:'#FF8A3D',pants:'#2D3A66',shoe:'#F4F6F8',gear:'#59627A',gear2:'#AEB7CA',bench:'#3B4563'};
const POSE_HOLD={bench_press:['ha',5.2],ohp:['ha',5.2],barbell_curl:['ha',5],deadlift:['ha',5.2],rdl:['ha',5],skull_crusher:['ha',4.6],squat:['sh',5.2],hip_thrust:['hip',5.2],db_press:['ha',3.8],db_ohp:['ha',3.8],db_fly:['ha',3.8],db_curl:['ha',3.8],hammer_curl:['ha',3.8],db_row:['ha',3.8],lateral_raise:['ha',3.8],goblet_squat:['ha',3.8],farmers_walk:['ha',3.8],pullup:['ha',2.6],lat_pulldown:['ha',2.6],cable_row:['ha',2.6],tricep_pushdown:['ha',2.6],cable_fly:['ha',2.6],face_pull:['ha',2.6]};
function pseg(a,b,w,c){return`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="${c}" stroke-width="${w}" stroke-linecap="round"/>`;}
function pdot(a,r,c){return`<circle cx="${a[0]}" cy="${a[1]}" r="${r}" fill="${c}" stroke="none"/>`;}
function poseSVGState(s,cls,exId){
  const C=PC,hold=POSE_HOLD[exId];let p='';
  if(s.shL){
    p+=pseg(s.hip,s.knL||s.ftL,8,C.pants)+pseg(s.hip,s.knR||s.ftR,8,C.pants);
    if(s.knL)p+=pseg(s.knL,s.ftL,6,C.skin)+pseg(s.knR,s.ftR,6,C.skin);
    p+=pdot(s.ftL,3.6,C.shoe)+pdot(s.ftR,3.6,C.shoe);
    p+=pseg(s.shL,s.hip,10,C.shirt)+pseg(s.shR,s.hip,10,C.shirt)+pseg(s.shL,s.shR,10,C.shirt);
    p+=pseg(s.shL,s.elL,5.5,C.skin)+pseg(s.elL,s.haL,4.6,C.skin)+pseg(s.shR,s.elR,5.5,C.skin)+pseg(s.elR,s.haR,4.6,C.skin);
    p+=pdot(s.haL,3,C.skin)+pdot(s.haR,3,C.skin);
    if(hold){const pts=hold[0]==='ha'?[s.haL,s.haR]:[hold[0]==='sh'?[(s.shL[0]+s.shR[0])/2,s.shL[1]]:s.hip];pts.forEach(q=>{p+=pdot(q,hold[1],C.gear)+pdot(q,hold[1]/2.6,C.gear2);});}
  }else{
    if(BENCH_IDS.has(exId))p+=`<rect x="${s.head[0]-6}" y="${s.sh[1]+5}" width="${s.hip[0]-s.head[0]+14}" height="6" rx="3" fill="${C.bench}" stroke="none"/>`+pseg([s.head[0]+4,s.sh[1]+11],[s.head[0]+4,86],3,C.bench)+pseg([s.hip[0]+4,s.sh[1]+11],[s.hip[0]+4,86],3,C.bench);
    p+=pseg(s.hip,s.kn,8.5,C.pants)+pseg(s.kn,s.ft,6.2,C.skin)+pdot(s.ft,3.8,C.shoe);
    p+=pseg(s.sh,s.hip,11,C.shirt);
    p+=pseg(s.sh,s.el,5.8,C.skin)+pseg(s.el,s.ha,4.8,C.skin)+pdot(s.ha,3.1,C.skin);
    if(hold){const q=s[hold[0]];p+=pdot(q,hold[1],C.gear)+pdot(q,hold[1]/2.6,C.gear2);}
  }
  p+=pdot(s.head,7.2,C.skin);
  return`<g class="${cls}">${p}</g>`;
}
let _exi=null;
function exImgs(){if(!_exi){try{_exi=JSON.parse(localStorage.getItem('acfv2_eximg')||'{}');}catch(e){_exi={};}}return _exi;}
function exImgKey(id,fb){return String((EX[id]&&EX[id].e)||fb||id||'').toLowerCase().trim();}
function pickExImg(k){k=String(k||'').toLowerCase().trim();if(!k)return;const i=document.createElement('input');i.type='file';i.accept='image/*';i.onchange=()=>{const f=i.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const sc=Math.min(1,560/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);c.getContext('2d').drawImage(im,0,0,c.width,c.height);try{const o=exImgs();o[k]=c.toDataURL('image/jpeg',.72);localStorage.setItem('acfv2_eximg',JSON.stringify(o));toast('📷 حُفظت صورتك لهذا التمرين');renderAll();}catch(e){toast('تعذّر الحفظ — التخزين ممتلئ','⚠️');}};im.src=r.result;};r.readAsDataURL(f);};i.click();}
function renderPoseSVG(exId,fallbackName){
  const nm=escapeHtml((EX[exId]&&EX[exId].n)||fallbackName||'تمرين'),ci=exImgs()[exImgKey(exId,fallbackName)];
  if(ci)return`<img class="pose-svg" alt="${nm}" src="${ci}" style="width:100%;height:100%;object-fit:cover;border-radius:14px">`;
  const poseKey=EX_POSE[exId]||guessPoseKey(fallbackName);if(!poseKey||!POSES[poseKey])return null;
  const p=POSES[poseKey];
  return`<svg class="pose-svg" viewBox="0 0 200 100" fill="none" role="img" aria-label="${nm}">${poseSVGState(p.A,'pose-s',exId)}<g transform="translate(100,0)">${poseSVGState(p.B,'pose-s',exId)}</g><line x1="100" y1="16" x2="100" y2="84" stroke="rgba(255,255,255,.16)" stroke-width="1" stroke-dasharray="3 4"/></svg>`;
}
function exVisual(exId,ico,extraClass,fallbackName){
  const svg=renderPoseSVG(exId,fallbackName);
  return svg?`<div class="ex-img pose-holder ${extraClass||''}">${svg}</div>`:`<div class="ex-img ${extraClass||''}">${ico}</div>`;
}
// نفتح بحث يوتيوب بدل عرض صورة/فيديو من موقع آخر داخل التطبيق — أسرع طريقة
// لمشاهدة أداء حقيقي للتمرين، وبدون أي مشاكل حقوق نشر لأننا لا نستضيف أو
// نعرض محتوى أي طرف ثالث، فقط نفتح رابط بحث خارجي مثل أي متصفح عادي.
function watchExDemo(engName){
  if(!engName)return;
  window.open('https://www.youtube.com/results?search_query='+encodeURIComponent(engName+' exercise form tutorial'),'_blank','noopener');
}

const EX={
  bench_press:{n:'بنش بريس',e:'Bench Press',mu:'صدر',sec:'كتفين، ترايسبس',eq:['barbell','bench','full_gym'],lv:'int',ico:'🏋️',rpe:8,tempo:'2-0-1',rest:90,lo:5,hi:8,alts:['pushup','db_press','cable_fly'],err:'تقوس الظهر، خفض الكوعين',how:['استلقِ على البنش والقدمان ثابتتان على الأرض، أمسك البار بعرض أوسع من الكتفين قليلاً','أنزل البار ببطء لمنتصف الصدر ثم ادفعه للأعلى بقوة حتى استقامة الذراعين']},
  db_press:{n:'دامبل برس',e:'DB Press',mu:'صدر',sec:'كتفين، ترايسبس',eq:['dumbbells','bench','full_gym'],lv:'beg',ico:'🏋️',rpe:7,tempo:'2-1-1',rest:90,lo:8,hi:12,alts:['pushup','bench_press'],err:'مد الكوعين كثيراً',how:['استلقِ على البنش، دامبل بكل يد عند مستوى الصدر','ادفع الدامبلز للأعلى حتى يلتقيا فوق الصدر، ثم أنزلهما ببطء']},
  pushup:{n:'بوش آب',e:'Push-Up',mu:'صدر',sec:'ترايسبس، كتفين',eq:['bodyweight'],lv:'beg',ico:'💪',rpe:6,tempo:'2-0-1',rest:60,lo:10,hi:20,alts:['incline_pushup','db_press'],err:'سقوط الوسط',how:['ضع يديك بعرض الكتفين والجسم بخط مستقيم من الرأس للكعبين','انزل حتى يقترب صدرك من الأرض ثم ادفع للأعلى دون أن يترهل الوسط']},
  incline_pushup:{n:'إنكلاين بوش آب',e:'Incline Push-Up',mu:'صدر سفلي',sec:'ترايسبس',eq:['bodyweight'],lv:'beg',ico:'⬆️',rpe:4,tempo:'2-0-1',rest:60,lo:12,hi:20,alts:['pushup'],err:'عدم استقامة الجسم',how:['ضع يديك على سطح مرتفع كطاولة أو كرسي، والجسم مستقيم','انزل صدرك نحو السطح ثم ادفع للأعلى محافظاً على استقامة الجسم']},
  dip:{n:'ديبس',e:'Dips',mu:'صدر-ترايسبس',sec:'كتفين',eq:['parallel_bars','full_gym'],lv:'int',ico:'⬇️',rpe:8,tempo:'2-0-1',rest:75,lo:8,hi:15,alts:['pushup','db_press','diamond_pushup'],err:'الميلان المفرط',how:['أمسك المتوازي بذراعين مستقيمتين وارفع جسمك للأعلى','انزل ببطء حتى تصل الكتفان لمستوى الكوعين تقريباً، ثم ادفع للأعلى']},
  diamond_pushup:{n:'دايموند بوش آب',e:'Diamond Push-Up',mu:'ترايسبس',sec:'صدر وسط',eq:['bodyweight'],lv:'int',ico:'💎',rpe:7,tempo:'2-0-1',rest:60,lo:10,hi:20,alts:['tricep_pushdown','skull_crusher'],err:'الكوعين للخارج',how:['ضع يديك تحت الصدر بحيث تشكل الإبهام والسبابة شكل الماسة','انزل ببطء مع إبقاء الكوعين قريبين من الجسم، ثم ادفع للأعلى']},
  cable_fly:{n:'كابل فلاي',e:'Cable Fly',mu:'صدر',sec:'كتف أمامي',eq:['cables','full_gym'],lv:'int',ico:'🦋',rpe:6,tempo:'2-1-2',rest:60,lo:12,hi:15,alts:['db_fly'],err:'تمديد الكوعين كلياً',how:['قف بين البكرتين، ذراعان ممدودتان للجانبين بانحناء بسيط في الكوع','اجمع اليدين أمام الصدر بحركة قوسية، ثم عد ببطء لنقطة البداية']},
  db_fly:{n:'دامبل فلاي',e:'Dumbbell Fly',mu:'صدر',sec:'',eq:['dumbbells','bench','full_gym'],lv:'int',ico:'🔆',rpe:5,tempo:'2-2-1',rest:60,lo:12,hi:15,alts:['cable_fly'],err:'مد الذراعين كلياً',how:['استلقِ على البنش وارفع الدامبلز فوق الصدر بانحناء بسيط في الكوعين','افتح الذراعين للجانبين بحركة قوسية حتى تشعر بتمدد الصدر، ثم عد للأعلى']},
  deadlift:{n:'ديدليفت',e:'Deadlift',mu:'ظهر-أرجل',sec:'مؤخرة، ساعد',eq:['barbell','full_gym'],lv:'adv',ico:'⚡',rpe:9,tempo:'2-0-1',rest:90,lo:3,hi:6,alts:['rdl','hip_thrust'],err:'تقوس الظهر، البار بعيد',how:['قف والبار قريب من ساقيك، أمسكه بعرض الكتفين والظهر مستقيم والصدر مرفوع','ادفع الأرض بقدميك وارفع البار مع تقويم الظهر، وحافظ عليه قريباً من الجسم طوال الحركة']},
  rdl:{n:'RDL رومانيا',e:'Romanian Deadlift',mu:'بطن فخذ',sec:'مؤخرة',eq:['barbell','dumbbells','full_gym'],lv:'int',ico:'🔻',rpe:7,tempo:'3-0-1',rest:75,lo:8,hi:12,alts:['hip_thrust','glute_bridge'],err:'تقوس الظهر',how:['أمسك البار أو الدامبل والركبتان منحنيتان قليلاً، الظهر مستقيم','انحنِ من الورك مع إنزال الوزن قريباً من الساقين حتى تشعر بتمدد خلف الفخذ، ثم عد للأعلى']},
  pullup:{n:'بول آب',e:'Pull-Up',mu:'ظهر عريض',sec:'بايسبس',eq:['pullup_bar','full_gym'],lv:'int',ico:'🙌',rpe:8,tempo:'2-1-2',rest:75,lo:5,hi:12,alts:['lat_pulldown','inverted_row'],err:'التأرجح، عدم الصعود الكامل',how:['أمسك العقلة بعرض أوسع من الكتفين قليلاً، الجسم معلق بذراعين مستقيمتين','اسحب جسمك للأعلى حتى يتجاوز الذقن العقلة، ثم انزل ببطء بشكل كامل']},
  lat_pulldown:{n:'لات بوللداون',e:'Lat Pulldown',mu:'ظهر عريض',sec:'بايسبس',eq:['cables','machines','full_gym'],lv:'beg',ico:'⬇️',rpe:7,tempo:'2-1-2',rest:90,lo:8,hi:12,alts:['pullup','inverted_row'],err:'الميلان للخلف كثيراً',how:['اجلس وأمسك القضيب بعرض أوسع من الكتفين','اسحب القضيب نحو أعلى الصدر مع فتح الصدر، ثم عد ببطء للأعلى']},
  db_row:{n:'دامبل رو',e:'Dumbbell Row',mu:'ظهر وسط',sec:'بايسبس',eq:['dumbbells','full_gym'],lv:'beg',ico:'🚣',rpe:7,tempo:'2-1-1',rest:90,lo:10,hi:15,alts:['cable_row','inverted_row'],err:'تدوير الكتف',how:['ضع ركبة ويداً على البنش، الظهر مستقيم موازٍ للأرض تقريباً','اسحب الدامبل نحو الخصر مع تقريب لوح الكتف، ثم أنزله ببطء']},
  cable_row:{n:'كابل رو',e:'Cable Row',mu:'ظهر وسط',sec:'بايسبس',eq:['cables','full_gym'],lv:'beg',ico:'🔗',rpe:7,tempo:'2-1-2',rest:90,lo:10,hi:12,alts:['db_row'],err:'تقوس الظهر',how:['اجلس أمام الجهاز وأمسك المقبض بذراعين ممدودتين','اسحب المقبض نحو البطن مع تقريب الكتفين للخلف، ثم عد ببطء للأمام']},
  inverted_row:{n:'انفيرتد رو',e:'Inverted Row',mu:'ظهر',sec:'بايسبس',eq:['bodyweight','pullup_bar'],lv:'beg',ico:'↩️',rpe:5,tempo:'2-1-2',rest:75,lo:8,hi:15,alts:['db_row','lat_pulldown'],err:'سقوط الوركين',how:['استلقِ تحت بار منخفض وأمسكه، الجسم مستقيم كالخشبة','اسحب صدرك نحو البار مع إبقاء الجسم مستقيماً، ثم انزل ببطء']},
  face_pull:{n:'فيس بول',e:'Face Pull',mu:'كتف خلفي',sec:'ترابيزيوس',eq:['cables','bands','full_gym'],lv:'beg',ico:'🎯',rpe:5,tempo:'2-2-1',rest:60,lo:15,hi:20,alts:['band_pull_apart'],err:'شد العنق',how:['اربط الحبل بنقطة مرتفعة وأمسك الطرفين بيدين','اسحب الحبل نحو وجهك مع فتح المرفقين للخارج، ثم عد ببطء']},
  band_pull_apart:{n:'باند بول أبارت',e:'Band Pull Apart',mu:'كتف خلفي',sec:'',eq:['bands','bodyweight'],lv:'beg',ico:'🎗️',rpe:4,tempo:'2-1-2',rest:45,lo:15,hi:25,alts:['face_pull'],err:'رفع الكتفين',how:['أمسك الحبل بيدين ممدودتين أمام الصدر','افتح الذراعين للجانبين مع شد الحبل حتى يلمس الصدر تقريباً، ثم عد ببطء']},
  ohp:{n:'أوفرهيد برس',e:'Overhead Press',mu:'كتفين',sec:'ترايسبس',eq:['barbell','dumbbells','full_gym'],lv:'int',ico:'🔝',rpe:8,tempo:'2-0-1',rest:75,lo:6,hi:10,alts:['db_ohp'],err:'قوس الظهر الخطير',how:['أمسك البار عند مستوى الكتفين، القدمان بعرض الورك','ادفع البار للأعلى فوق الرأس حتى استقامة الذراعين، ثم أنزله ببطء لنفس النقطة']},
  db_ohp:{n:'دامبل أوفرهيد',e:'DB Shoulder Press',mu:'كتفين',sec:'ترايسبس',eq:['dumbbells','full_gym'],lv:'beg',ico:'💈',rpe:7,tempo:'2-0-1',rest:90,lo:10,hi:12,alts:['ohp'],err:'رفع الكتفين',how:['أمسك الدامبلز عند الكتفين، الكوعان للأمام قليلاً','ادفع الدامبلز للأعلى حتى يلتقيا فوق الرأس تقريباً، ثم أنزلهما ببطء']},
  lateral_raise:{n:'ليترال ريز',e:'Lateral Raise',mu:'كتف جانبي',sec:'',eq:['dumbbells','cables','bands','full_gym'],lv:'beg',ico:'↔️',rpe:6,tempo:'2-1-2',rest:60,lo:15,hi:20,alts:['band_lateral'],err:'التأرجح',how:['قف وأمسك الدامبلز بجانب الجسم، انحناء بسيط في الكوعين','ارفع الذراعين للجانبين حتى مستوى الكتفين، ثم أنزلهما ببطء دون تأرجح']},
  barbell_curl:{n:'بار كيرل',e:'Barbell Curl',mu:'بايسبس',sec:'ساعد',eq:['barbell','full_gym'],lv:'beg',ico:'💪',rpe:7,tempo:'2-1-2',rest:60,lo:8,hi:12,alts:['db_curl','hammer_curl','band_curl'],err:'تحريك الكوعين',how:['أمسك البار بعرض الكتفين والكوعان ثابتان بجانب الجسم','اثنِ الكوعين وارفع البار نحو الصدر، ثم أنزله ببطء دون تحريك الكوعين']},
  db_curl:{n:'دامبل كيرل',e:'Dumbbell Curl',mu:'بايسبس',sec:'ساعد',eq:['dumbbells','full_gym'],lv:'beg',ico:'💪',rpe:6,tempo:'2-1-2',rest:60,lo:10,hi:15,alts:['barbell_curl','band_curl'],err:'تأرجح الجسم',how:['أمسك الدامبلز بجانب الجسم وراحة اليد للأمام','اثنِ الكوعين وارفع الدامبلز نحو الكتفين، ثم أنزلهما ببطء']},
  hammer_curl:{n:'هامر كيرل',e:'Hammer Curl',mu:'بايسبس-ساعد',sec:'',eq:['dumbbells','full_gym'],lv:'beg',ico:'🔨',rpe:6,tempo:'2-1-2',rest:60,lo:10,hi:15,alts:['db_curl'],err:'مد الكوع كلياً',how:['أمسك الدامبلز بجانب الجسم وراحة اليد للداخل كالمطرقة','اثنِ الكوعين وارفع الدامبلز مع إبقاء راحة اليد للداخل طوال الحركة']},
  band_curl:{n:'باند كيرل',e:'Band Curl',mu:'بايسبس',sec:'',eq:['bands','bodyweight'],lv:'beg',ico:'🎗️',rpe:5,tempo:'2-1-2',rest:45,lo:15,hi:20,alts:['db_curl'],err:'حركة الكوعين',how:['قف على منتصف الحبل وأمسك الطرفين بيديك','اثنِ الكوعين وارفع اليدين نحو الكتفين، ثم أنزلهما ببطء']},
  tricep_pushdown:{n:'ترايسبس بوشداون',e:'Tricep Pushdown',mu:'ترايسبس',sec:'',eq:['cables','full_gym'],lv:'beg',ico:'⬇️',rpe:6,tempo:'2-1-2',rest:60,lo:12,hi:15,alts:['skull_crusher','diamond_pushup'],err:'تحريك الكوعين',how:['أمسك المقبض من الأعلى والكوعان ثابتان بجانب الجسم','ادفع المقبض للأسفل حتى استقامة الذراعين، ثم عد ببطء دون تحريك الكوعين']},
  skull_crusher:{n:'سكال كراشر',e:'Skull Crusher',mu:'ترايسبس',sec:'',eq:['barbell','dumbbells','full_gym'],lv:'int',ico:'💀',rpe:7,tempo:'3-0-1',rest:75,lo:10,hi:12,alts:['tricep_pushdown','diamond_pushup'],err:'مد الكوعين للخارج',how:['استلقِ على البنش وارفع البار أو الدامبلز فوق الوجه بذراعين مستقيمتين','اثنِ الكوعين فقط لإنزال الوزن نحو الجبهة، ثم ادفع للأعلى']},
  squat:{n:'سكوات',e:'Squat',mu:'أرجل',sec:'مؤخرة، ظهر',eq:['barbell','bodyweight','full_gym'],lv:'int',ico:'🦵',rpe:8,tempo:'3-0-1',rest:90,lo:5,hi:10,alts:['goblet_squat','leg_press'],err:'الركبتين للداخل',how:['القدمان بعرض الكتفين، البار على أعلى الظهر أو بدون وزن','انزل كأنك تجلس على كرسي مع إبقاء الركبتين متجهتين للخارج، ثم ادفع للأعلى']},
  goblet_squat:{n:'غوبليت سكوات',e:'Goblet Squat',mu:'أرجل',sec:'مؤخرة',eq:['dumbbells','kettlebell','full_gym'],lv:'beg',ico:'🏺',rpe:6,tempo:'3-0-1',rest:90,lo:10,hi:15,alts:['bodyweight_squat','squat'],err:'الصدر للأمام كثيراً',how:['أمسك الدامبل أو الكيتل بيل أمام الصدر بيدين','انزل بين الفخذين مع إبقاء الصدر مرفوعاً، ثم ادفع للأعلى']},
  bodyweight_squat:{n:'سكوات بدون وزن',e:'Bodyweight Squat',mu:'أرجل',sec:'مؤخرة',eq:['bodyweight'],lv:'beg',ico:'🪑',rpe:4,tempo:'3-0-1',rest:60,lo:15,hi:25,alts:['goblet_squat'],err:'الظهر للخلف',how:['القدمان بعرض الكتفين، الذراعان ممدودتان للأمام للتوازن','انزل كأنك تجلس على كرسي، وحافظ على الصدر مرفوعاً والوزن على الكعبين']},
  leg_press:{n:'ليج برس',e:'Leg Press',mu:'أرجل',sec:'مؤخرة',eq:['machines','full_gym'],lv:'beg',ico:'🦿',rpe:7,tempo:'3-0-1',rest:75,lo:10,hi:15,alts:['squat','goblet_squat'],err:'الركبتين لداخل',how:['اجلس على الجهاز والقدمان بعرض الكتفين على المنصة','ادفع المنصة للأمام حتى استقامة شبه كاملة للركبتين، ثم عد ببطء']},
  lunge:{n:'لانج',e:'Lunge',mu:'أرجل-مؤخرة',sec:'بطن',eq:['bodyweight','dumbbells','full_gym'],lv:'beg',ico:'🚶',rpe:6,tempo:'2-0-1',rest:75,lo:10,hi:15,alts:['split_squat'],err:'الركبة تجاوز الإصبع',how:['قف منتصباً ثم خذ خطوة واسعة للأمام بقدم واحدة','انزل حتى تلامس الركبة الخلفية الأرض تقريباً، ثم ادفع للأعلى والعودة']},
  hip_thrust:{n:'هيب ثراست',e:'Hip Thrust',mu:'مؤخرة',sec:'بطن فخذ',eq:['barbell','dumbbells','bodyweight','full_gym'],lv:'beg',ico:'🍑',rpe:7,tempo:'1-2-1',rest:90,lo:10,hi:20,alts:['glute_bridge'],err:'قوس الظهر',how:['اجلس على الأرض وظهرك العلوي على البنش، الوزن على الحوض','ادفع الحوض للأعلى حتى استقامة الجسم، واضغط على الألوية في القمة']},
  glute_bridge:{n:'غلوت بريدج',e:'Glute Bridge',mu:'مؤخرة',sec:'بطن فخذ',eq:['bodyweight'],lv:'beg',ico:'🌉',rpe:4,tempo:'1-2-1',rest:60,lo:15,hi:25,alts:['hip_thrust'],err:'تقوس الظهر السفلي',how:['استلقِ على ظهرك، الركبتان منحنيتان والقدمان على الأرض','ارفع الحوض للأعلى مع الضغط على الألوية، ثم انزل ببطء']},
  leg_curl:{n:'ليج كيرل',e:'Leg Curl',mu:'بطن فخذ',sec:'',eq:['machines','full_gym'],lv:'beg',ico:'🦵',rpe:6,tempo:'2-2-1',rest:75,lo:10,hi:15,alts:['rdl'],err:'رفع الوركين',how:['استلقِ على الجهاز والوسادة خلف الكاحلين','اثنِ الركبتين لسحب الوزن نحو المؤخرة، ثم عد ببطء']},
  calf_raise:{n:'كاف ريز',e:'Calf Raise',mu:'ساق خلفية',sec:'',eq:['bodyweight','dumbbells','machines','full_gym'],lv:'beg',ico:'🦶',rpe:6,tempo:'1-2-2',rest:60,lo:15,hi:25,alts:['calf_raise'],err:'الحركة السريعة',how:['قف على أرض مستوية أو حافة، القدمان بعرض الورك','ارفع كعبيك للأعلى قدر الإمكان، ثم انزل ببطء حتى تشعر بتمدد الساق']},
  jump_squat:{n:'جامب سكوات',e:'Jump Squat',mu:'أرجل-انفجاري',sec:'مؤخرة',eq:['bodyweight'],lv:'int',ico:'⬆️',rpe:8,tempo:'expl',rest:90,lo:6,hi:12,alts:['squat','box_jump'],err:'الهبوط بكعب القدم',how:['قف بعرض الكتفين ثم انزل لوضع سكوات خفيف','اقفز للأعلى بقوة من وضع السكوات، واهبط بنعومة وكرر مباشرة']},
  burpee:{n:'بيربي',e:'Burpee',mu:'كارديو كامل',sec:'كل العضلات',eq:['bodyweight'],lv:'int',ico:'🌪️',rpe:9,tempo:'fast',rest:90,lo:5,hi:15,alts:['jump_squat','mountain_climber'],err:'الهبوط الصلب',how:['ابدأ واقفاً بشكل منتصب','انزل لوضع بلانك، ثم اقفز بالقدمين للأمام واقفز للأعلى بكلتا اليدين']},
  plank:{n:'بلانك',e:'Plank',mu:'بطن ثبات',sec:'ظهر، كتفين',eq:['bodyweight'],lv:'beg',ico:'🔲',rpe:5,tempo:'hold',rest:60,lo:30,hi:60,alts:['dead_bug'],isTimed:true,err:'سقوط الوسط',how:['استلقِ على بطنك وارفع الجسم على الساعدين وأطراف القدمين','حافظ على الجسم بخط مستقيم من الرأس للكعبين دون رفع أو إنزال الوسط']},
  ab_wheel:{n:'عجلة البطن',e:'Ab Wheel',mu:'بطن',sec:'ظهر سفلي',eq:['bodyweight','full_gym'],lv:'int',ico:'⭕',rpe:8,tempo:'3-0-2',rest:75,lo:8,hi:15,alts:['plank','dead_bug'],err:'قوس الظهر السفلي',how:['اركع على الأرض وأمسك العجلة أمامك بيديك','ادفع العجلة للأمام مع إبقاء الظهر مستقيماً، ثم اسحبها للخلف بعضلات البطن']},
  leg_raise:{n:'ليج ريز',e:'Leg Raise',mu:'بطن سفلي',sec:'',eq:['bodyweight','pullup_bar'],lv:'int',ico:'🦵',rpe:7,tempo:'2-1-2',rest:60,lo:10,hi:20,alts:['crunch','mountain_climber'],err:'تأرجح الجسم',how:['استلقِ على ظهرك أو تعلق على العقلة، الساقان مستقيمتان','ارفع الساقين للأعلى حتى الزاوية القائمة تقريباً، ثم أنزلهما ببطء دون تأرجح']},
  crunch:{n:'كرانش',e:'Crunch',mu:'بطن',sec:'',eq:['bodyweight'],lv:'beg',ico:'🌀',rpe:4,tempo:'1-2-1',rest:45,lo:15,hi:25,alts:['plank'],err:'شد الرقبة',how:['استلقِ على ظهرك، الركبتان منحنيتان والقدمان على الأرض','ارفع أعلى الظهر عن الأرض بشد عضلات البطن دون شد الرقبة، ثم انزل ببطء']},
  mountain_climber:{n:'ماونتن كلايمبر',e:'Mountain Climber',mu:'بطن-كارديو',sec:'كتفين',eq:['bodyweight'],lv:'beg',ico:'🏔️',rpe:6,tempo:'fast',rest:45,lo:20,hi:30,alts:['plank','crunch'],err:'رفع المؤخرة',how:['ابدأ في وضع بلانك على يديك','اجذب ركبة واحدة نحو الصدر ثم بدّل بسرعة بين الساقين وكأنك تجري في مكانك']},
  dead_bug:{n:'ديد باج',e:'Dead Bug',mu:'بطن ثبات',sec:'ظهر سفلي',eq:['bodyweight'],lv:'beg',ico:'🐛',rpe:4,tempo:'slow',rest:45,lo:8,hi:12,alts:['plank'],err:'رفع الظهر عن الأرض',how:['استلقِ على ظهرك، الذراعان للأعلى والركبتان مثنيتان بزاوية 90 درجة','مدّ ذراعاً وساقاً معاكسة ببطء نحو الأرض دون رفع أسفل الظهر، ثم عد وبدّل الجانب']},
  shadowboxing:{n:'شادو بوكسينج',e:'Shadow Boxing',mu:'كارديو-مهارة',sec:'كتفين، بطن',eq:['bodyweight'],lv:'beg',ico:'👊',rpe:6,tempo:'rounds',rest:60,lo:3,hi:5,isTimed:true,unit:'جولة 3د',alts:['heavy_bag'],err:'نسيان الدفاع',how:['قف بوضعية ملاكمة، القبضتان أمام الوجه','ارمِ لكمات في الهواء مع الحركة والتنقل، وتخيل خصماً أمامك للدفاع والهجوم']},
  heavy_bag:{n:'كيس الملاكمة',e:'Heavy Bag',mu:'كارديو-قوة',sec:'كتفين، ساعد',eq:['bodyweight'],lv:'int',ico:'🥊',rpe:8,tempo:'rounds',rest:60,lo:3,hi:6,isTimed:true,unit:'جولة 3د',alts:['shadowboxing'],err:'ضرب بدون توقيت',how:['قف أمام الكيس بوضعية ملاكمة مستقرة','ارمِ لكمات متنوعة بقوة متحكمة، وحافظ على توقيت ثابت بين اللكمات']},
  farmers_walk:{n:'فارمرز ووك',e:"Farmer's Walk",mu:'كل الجسم',sec:'ساعد، ترابيز',eq:['dumbbells','kettlebell','full_gym'],lv:'beg',ico:'🧺',rpe:7,tempo:'walk',rest:90,lo:20,hi:40,unit:'متر',alts:['deadlift'],err:'الإمساك الضعيف',how:['أمسك دامبل أو كيتل بيل ثقيل بكل يد وقف منتصباً','امشِ بخطوات ثابتة مع إبقاء الكتفين للخلف والجذع مشدوداً']},
};

// ══════════════════════════════════════════════════════
// SPORT→EXERCISE MAP
// ══════════════════════════════════════════════════════
const SPORT_EX={
  bodybuilding:{compound:['bench_press','squat','deadlift','ohp','pullup','rdl'],isolation:['db_fly','cable_fly','lateral_raise','db_row','face_pull','leg_press','hip_thrust','leg_curl','calf_raise','barbell_curl','skull_crusher'],core:['plank','crunch','leg_raise']},
  powerlifting:{primary:['squat','bench_press','deadlift'],accessory:['rdl','ohp','db_row','db_press','leg_press','barbell_curl','tricep_pushdown'],core:['plank','dead_bug']},
  calisthenics:{primary:['pullup','dip','pushup','leg_raise'],skill:['inverted_row','ab_wheel','plank','diamond_pushup','incline_pushup'],core:['plank','dead_bug','ab_wheel']},
  crossfit:{primary:['squat','deadlift','ohp','pullup'],metcon:['burpee','jump_squat','mountain_climber'],core:['plank','ab_wheel']},
  boxing:{sport:['shadowboxing','heavy_bag'],strength:['pushup','pullup','squat','jump_squat'],power:['burpee','jump_squat'],core:['plank','mountain_climber','leg_raise'],endurance:['burpee','mountain_climber']},
  wrestling:{primary:['squat','deadlift','hip_thrust'],explosive:['jump_squat','burpee'],grip:['farmers_walk','deadlift','db_row'],core:['plank','ab_wheel','dead_bug']},
  bjj:{primary:['pullup','deadlift','hip_thrust'],grip:['farmers_walk','db_row','inverted_row'],core:['plank','ab_wheel','dead_bug','leg_raise'],mobility:['hip_thrust','glute_bridge','rdl']},
  mma:{primary:['squat','deadlift','pullup','pushup'],power:['jump_squat','burpee','heavy_bag'],core:['plank','ab_wheel','mountain_climber','leg_raise'],endurance:['burpee','mountain_climber']},
  running:{strength:['squat','lunge','rdl','hip_thrust','calf_raise'],core:['plank','dead_bug','glute_bridge'],explosive:['jump_squat']},
  swimming:{primary:['pullup','lat_pulldown','cable_row'],shoulder:['ohp','lateral_raise','face_pull','band_pull_apart'],core:['plank','dead_bug'],endurance:['burpee']},
  football:{primary:['squat','rdl','lunge'],explosive:['jump_squat','burpee'],upper:['bench_press','db_row','ohp'],core:['plank','mountain_climber']},
  basketball:{primary:['squat','lunge','calf_raise'],explosive:['jump_squat'],upper:['ohp','db_row','pushup'],core:['plank','dead_bug']},
  cycling:{primary:['squat','leg_press','rdl','calf_raise'],core:['plank','dead_bug'],upper:['pushup','db_row','face_pull']},
  general:{primary:['pushup','squat','db_row','plank'],full_body:['burpee','goblet_squat','hip_thrust','lunge'],core:['plank','dead_bug','crunch']}
};

// ══════════════════════════════════════════════════════
// SCIENCE ENGINE
// ══════════════════════════════════════════════════════
const calcBMR=(w,h,a,g)=>g==='male'?10*w+6.25*h-5*a+5:10*w+6.25*h-5*a-161;
const calcTDEE=(w,h,a,g,act)=>calcBMR(w,h,a||25,g||'male')*(act||1.375);
const calcCals=(tdee,goal,age,g)=>{let d=({muscle:350,fat_loss:-450,strength:150,endurance:0,recomp:-150,maintain:0}[goal]||0);if(age&&age<18&&d<0)d=0;return Math.round(Math.max(tdee+d,Math.min(tdee,g==='female'?1200:1500)));};
const calcProtein=(w,goal)=>Math.round(w*({muscle:2.0,fat_loss:2.4,strength:2.0,endurance:1.6,recomp:2.2,maintain:1.6}[goal]||1.8));
const calcCarbs=(cal,p,f)=>Math.max(50,Math.round((cal-p*4-f*9)/4));
const getSplit=(days,prim,goal,level)=>{const d=parseInt(days);if(d<=2)return'Full Body 2× (راحة كافية بين الجلستين)';if(d===3)return goal==='strength'?'Strength A/B/A — يوم راحة بين كل جلستين':'Full Body 3× — يوم راحة بين كل جلستين';if(d===4)return['boxing','mma','wrestling','bjj'].includes(prim)?'Sport + Upper/Lower — يومان راحة أسبوعياً':'Upper/Lower 4× — يومان راحة أسبوعياً';if(d===5)return['boxing','mma','wrestling','bjj'].includes(prim)?'Combat PPL 5× — يومان راحة أسبوعياً':'Push/Pull/Legs 5× — يومان راحة أسبوعياً';return'PPL×2 (6 أيام) — يوم راحة واحد إلزامي';};
const getProgression=l=>l==='beginner'?'تدرّج مزدوج: زد التكرارات أولاً، ثم أصغر زيادة وزن عندما تُكمل كل المجموعات بتقنية سليمة مع بقاء 2–3 تكرارات احتياطية.':l==='intermediate'?'تدرّج مزدوج: ارفع التكرارات ضمن النطاق، ثم زد الوزن تدريجياً مع ثبات الأداء والتعافي.':'فترات تدريب مرنة: حجم معتدل ثم زيادة تدريجية بالشدة، مع أسبوع تخفيف عند تراكم التعب لا وفق تقويم جامد.';
const VP={muscle:{sets:3,lo:6,hi:12,rest:120,rir:2},fat_loss:{sets:3,lo:6,hi:12,rest:120,rir:2},strength:{sets:3,lo:3,hi:6,rest:180,rir:3},endurance:{sets:2,lo:12,hi:20,rest:60,rir:2},recomp:{sets:3,lo:6,hi:12,rest:120,rir:2},maintain:{sets:2,lo:8,hi:15,rest:90,rir:2}};

// ══════════════════════════════════════════════════════
// PROGRAM BUILDER — with real rest-day scheduling
// ══════════════════════════════════════════════════════
// WEEKLY_TEMPLATES: maps training-days-per-week to which of the 7 weekdays
// (0=Sun..6=Sat) are training days vs rest days, following NSCA/ACSM
// guidance of never stacking more than 2-3 consecutive training days
// without recovery, and never training the same muscle group <48h apart.
const WEEKLY_TEMPLATES={
  2:[1,4],                 // Mon, Thu — 72h+ between sessions
  3:[1,3,5],                // Mon, Wed, Fri — 48h between each
  4:[1,2,4,5],               // Mon,Tue, rest Wed, Thu,Fri, rest weekend
  5:[0,1,3,4,6],              // Sun-Mon, Wed-Thu, Sat: recovery between blocks
  6:[0,1,2,4,5,6],             // Three days, rest, three days
};
const WD_AR=['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

// نسخة مستقلة من canDo/buildAlts لا تعتمد على closure داخل buildProgram —
// buildProgram الأصلية ترجع buildAlts كدالة JS، لكن save() يحفظ APP عبر
// JSON.stringify الذي يُسقِط أي دالة بصمت؛ فبعد أي إعادة تحميل حقيقية للصفحة
// (إغلاق وفتح التطبيق من جديد) كانت prog.buildAlts تختفي ويكسر أول استدعاء
// لها كامل renderAll() عند الإقلاع — وهذا سبب رئيسي وراء شعور "خطتي لا تُحفَظ".
const INJ_BLOCK={
 shoulder:['ohp','db_ohp','bench_press','db_press','dip','lateral_raise','cable_fly','db_fly','burpee','pushup','incline_pushup','diamond_pushup'],
 knee:['squat','lunge','leg_press','goblet_squat','jump_squat','burpee'],
 back:['deadlift','squat','rdl','jump_squat','burpee','ab_wheel'],
 wrist:['barbell_curl','bench_press','pushup','incline_pushup','diamond_pushup','plank','dip','burpee','db_press','ohp','db_ohp','ab_wheel','deadlift','rdl','farmers_walk'],
 elbow:['skull_crusher','dip','tricep_pushdown','diamond_pushup','bench_press','pushup','incline_pushup']
};
const EQ_ALL={bench_press:['barbell','bench'],db_press:['dumbbells','bench'],db_fly:['dumbbells','bench']};
if(EX.band_curl)EX.band_curl.eq=['bands','full_gym'];
if(EX.band_pull_apart)EX.band_pull_apart.eq=['bands','full_gym'];
if(EX.heavy_bag)EX.heavy_bag.eq=['full_gym'];
if(EX.inverted_row)EX.inverted_row.eq=['pullup_bar','parallel_bars','full_gym'];
Object.values(EX).forEach(e=>{if(e.alts)e.alts=e.alts.filter(a=>EX[a]);});
function hasEquipFor(id,equip){const ex=EX[id];if(!ex)return false;const e=new Set([...(equip||[]),'bodyweight']);if(e.has('full_gym'))return true;const all=EQ_ALL[id];return all?all.every(x=>e.has(x)):ex.eq.some(x=>e.has(x));}
function canDoExercise(id,equipment,limits){if(!EX[id]||!hasEquipFor(id,equipment))return false;return !(limits||[]).some(l=>(INJ_BLOCK[l]||[]).includes(id));}
function getExerciseAlts(id,equipment,limits){
  const ex=EX[id];if(!ex)return[];
  return(ex.alts||[]).filter(altId=>canDoExercise(altId,equipment,limits)).slice(0,4);
}
const PROG_PAT={deadlift:'hinge',rdl:'hinge',squat:'squat',goblet_squat:'squat',bodyweight_squat:'squat',jump_squat:'squat',leg_press:'legpress',lunge:'lunge',hip_thrust:'bridge',glute_bridge:'bridge',leg_curl:'hamcurl',calf_raise:'calf',bench_press:'hpress',db_press:'hpress',pushup:'hpress',incline_pushup:'hpress',diamond_pushup:'hpress',dip:'hpress',cable_fly:'fly',db_fly:'fly',ohp:'vpress',db_ohp:'vpress',lateral_raise:'lateral',tricep_pushdown:'tri',skull_crusher:'tri',pullup:'vpull',lat_pulldown:'vpull',db_row:'row',cable_row:'row',inverted_row:'row',face_pull:'rear',band_pull_apart:'rear',barbell_curl:'curl',db_curl:'curl',hammer_curl:'curl',band_curl:'curl',plank:'core',ab_wheel:'core',leg_raise:'core',crunch:'core',mountain_climber:'core',dead_bug:'core'};
const PROG_CAP={hpress:2,row:2,curl:2,core:2};
const PROG_CORE=new Set(['plank','ab_wheel','leg_raise','crunch','mountain_climber','dead_bug']);
const PROG_MU={legs:['أرجل','مؤخرة','بطن فخذ','ساق','انفجاري','كارديو','كل الجسم'],push:['صدر','كتف','ترايسبس'],pull:['ظهر','بايسبس','كتف خلفي']};
PROG_MU.lower=PROG_MU.legs;PROG_MU.upper=[...PROG_MU.push,...PROG_MU.pull];
const PROG_RANK={squat:1,hinge:2,legpress:3,lunge:4,bridge:5,hamcurl:6,calf:7,core:9};
function buildProgram(u){
  const days=Math.max(2,Math.min(6,parseInt(u.days)||3));
  const goal=u.goal||'muscle', prim=u.primarySport||'general';
  const equip=u.equipment||['bodyweight'], limits=(u.limits||[]).filter(x=>x!=='none');
  const dur=Math.max(20,Math.min(120,parseInt(u.duration)||45));
  const vp={... (VP[goal]||VP.muscle)};
  // Keep sessions realistic: the time limit controls exercise count, not arbitrary muscle coverage.
  const maxEx=dur<=30?4:dur<=45?5:dur<=60?6:7;
  const canDo=id=>canDoExercise(id,equip,limits);
  const unique=list=>[...new Set(list)].filter(id=>canDo(id));
  const choose=(list,n)=>unique(list).slice(0,n);

  // Explicit movement-pattern pools avoid relying on Arabic muscle-name substring matching.
  const pushPool=unique(['bench_press','db_press','pushup','incline_pushup','ohp','db_ohp','lateral_raise','tricep_pushdown','diamond_pushup']);
  const pullPool=unique(['pullup','lat_pulldown','db_row','cable_row','inverted_row','face_pull','band_pull_apart','barbell_curl','db_curl','hammer_curl','band_curl']);
  const legPool=unique(['squat','goblet_squat','bodyweight_squat','deadlift','rdl','lunge','leg_press','hip_thrust','glute_bridge','leg_curl','calf_raise']);
  const corePool=unique(['plank','dead_bug','crunch','leg_raise','mountain_climber']);
  const sportIds=unique(Object.values(SPORT_EX[prim]||SPORT_EX.general).flat());
  const combat=['boxing','mma','wrestling','bjj'].includes(prim);
  const sportSupport=()=>{
    if(['running','football','basketball','cycling'].includes(prim)) return choose([...sportIds.filter(id=>['calf_raise','glute_bridge','dead_bug','plank','jump_squat','lunge'].includes(id)),...corePool],1);
    if(combat) return choose(sportIds.filter(id=>['shadowboxing','heavy_bag','farmers_walk','mountain_climber','jump_squat'].includes(id)),1);
    return [];
  };
  const make=(label,focus,ids,muscle='full',isSport=false)=>({label,focus,exIds:choose(ids,maxEx),muscle,isSport});
  const fullA=()=>make('Full Body A','كامل الجسم — دفع + سحب + حركة أرجل',[pushPool[0],pullPool[0],legPool[0],corePool[0],...pushPool.slice(1),...pullPool.slice(1)]);
  const fullB=()=>make('Full Body B','كامل الجسم — أنماط مختلفة مع تركيز على القوة',[legPool[1],pullPool[1],pushPool[1],corePool[1],...legPool.slice(2),...pullPool.slice(2),...pushPool.slice(2)]);
  const sessions=[];
  if(days===2){
    sessions.push(fullA(),fullB());
  } else if(days===3){
    // Full-body frequency is more forgiving and effective for most beginners/intermediates.
    sessions.push(fullA(),make('Full Body B','كامل الجسم — سحب + مفصل الورك + دفع',[pullPool[1],legPool[1],pushPool[1],corePool[1],...pushPool,...pullPool,...legPool]),fullB());
  } else if(days===4){
    sessions.push(make('Upper A','الجزء العلوي — دفع وسحب متوازن',[pushPool[0],pullPool[0],pushPool[1],pullPool[1],...pushPool,...pullPool],'upper'),
      make('Lower A','الجزء السفلي — سكوات ومؤخرة وبطن',[legPool[0],legPool[1],legPool[2],...legPool,...corePool],'lower'),
      make('Upper B','الجزء العلوي — زوايا وعضلات مساعدة',[pullPool[2],pushPool[2],pullPool[3],pullPool[3],...pullPool,...pushPool],'upper'),
      make('Lower B','الجزء السفلي — مفصل الورك ورجل واحدة',[legPool[3],legPool[4],legPool[5],...legPool.slice().reverse(),...corePool],'lower'));
  } else if(days===5){
    sessions.push(make('Full Body A','كامل الجسم — قوة أساسية',[legPool[0],pushPool[0],pullPool[0],corePool[0],...legPool,...pushPool,...pullPool]),
      make('Upper','الجزء العلوي — دفع وسحب',[pushPool[1],pullPool[1],...pushPool,...pullPool],'upper'),
      make('Lower + Core','أرجل + مؤخرة + بطن',[legPool[1],legPool[2],legPool[3],...legPool,...corePool],'lower'),
      make(combat?'Sport Skills':'Full Body B',combat?'مهارات مساندة للرياضة الأساسية':'كامل الجسم — حجم متوسط',[...sportSupport(),pullPool[2],pushPool[2],legPool[4],...corePool,...pushPool,...pullPool], 'full',combat),
      make('Accessory + Core','عضلات مساعدة + بطن وحركة',[pullPool[4],pushPool[4],legPool[5],...corePool,...pullPool,...pushPool]));
  } else {
    sessions.push(make('Push A','دفع — صدر وكتف وترايسبس',[pushPool[0],pushPool[1],...pushPool],'push'),
      make('Pull A','سحب — ظهر وبايسبس وكتف خلفي',[pullPool[0],pullPool[1],...pullPool],'pull'),
      make('Legs A','أرجل — سكوات ومؤخرة',[legPool[0],legPool[1],...legPool,...corePool],'legs'),
      make('Push B','دفع — حجم معتدل وزوايا مختلفة',[...pushPool.slice(1),...pushPool],'push'),
      make('Pull B','سحب — حجم معتدل وقبضة',[...pullPool.slice(2),...pullPool],'pull'),
      make('Legs B + Core','أرجل + بطن وحركة',[...legPool.slice(2),...legPool,...corePool],'legs'));
  }

  // Never invent fallback exercises that might violate equipment or injury constraints.
  sessions.forEach((s,i)=>{
    s.exIds=unique(s.exIds).slice(0,maxEx);
    if(!s.exIds.length){
      const safePool=unique([...pushPool,...pullPool,...legPool,...corePool]);
      s.exIds=safePool.slice(0,Math.min(3,maxEx));
      s.focus+=' — تم تقليل التمارين بسبب قيود المعدات/الحركة';
    }
    // Keep sessions from becoming repetitive when there are enough valid movements.
    s.exIds=[...new Set(s.exIds)];
  });

  const slots=WEEKLY_TEMPLATES[days]||WEEKLY_TEMPLATES[3], schedule=[];
  for(let wd=0;wd<7;wd++){
    const si=slots.indexOf(wd);
    if(si>=0&&sessions[si]) schedule.push({day:WD_AR[wd],weekday:wd,...sessions[si],isRest:false});
    else schedule.push({day:WD_AR[wd],weekday:wd,label:'راحة',focus:'تعافٍ — مشي خفيف أو حركة مريحة حسب الحاجة',exIds:[],isRest:true});
  }
  const restDayCount=schedule.filter(d=>d.isRest).length;
  return {schedule,vp,sets:vp.sets,splitLabel:getSplit(days,prim,goal,u.level),progression:getProgression(u.level||'beginner'),restDayCount,trainingDays:days};
}


// ══════════════════════════════════════════════════════
// 12-WEEK PLAN
// ══════════════════════════════════════════════════════
function build12WeekPlan(goal,level){
  const plans={
    muscle:{phases:[{weeks:'1-4',name:'Accumulation — تراكم الحجم',sets:'3',reps:'12-15',rir:'3-4',rpe:'6-7',focus:'ضع أساس الحجم التدريبي'},{weeks:'5-8',name:'Intensification — رفع الشدة',sets:'4',reps:'8-10',rir:'2-3',rpe:'7-8',focus:'رفع الأوزان مع الحفاظ على التقنية'},{weeks:'9-11',name:'Peak — الذروة',sets:'4-5',reps:'6-8',rir:'1-2',rpe:'8-9',focus:'أثقل أوزان في الدورة'},{weeks:'12',name:'Deload — التفريغ',sets:'2',reps:'10-12',rir:'4-5',rpe:'5-6',focus:'تعافٍ نشط — خفض 40% من الحجم'}]},
    strength:{phases:[{weeks:'1-3',name:'GPP — تكييف عام',sets:'3',reps:'10-12',rir:'4',rpe:'6',focus:'تهيئة المفاصل والأوتار'},{weeks:'4-7',name:'Strength Block — قوة',sets:'4-5',reps:'4-6',rir:'2-3',rpe:'7-8',focus:'تقدم خطي في السكوات والبنش والديدليفت'},{weeks:'8-11',name:'Peaking — ذروة القوة',sets:'5',reps:'1-3',rir:'1',rpe:'9-10',focus:'الوصول للأرقام القياسية'},{weeks:'12',name:'Deload',sets:'2',reps:'5',rir:'5',rpe:'5',focus:'راحة كاملة تقريباً'}]},
    fat_loss:{phases:[{weeks:'1-3',name:'رفع الكثافة التدريبية',sets:'3',reps:'12-15',rir:'2',rpe:'7-8',focus:'حرق أكبر عبر حجم أعلى'},{weeks:'4-8',name:'Circuit Training',sets:'3',reps:'15-20',rir:'1',rpe:'8',focus:'دوائر مركبة لرفع معدل الحرق'},{weeks:'9-11',name:'HIIT + Strength',sets:'3',reps:'10-15',rir:'2',rpe:'7',focus:'الحفاظ على العضلات مع حرق الدهون'},{weeks:'12',name:'Refeed + Reset',sets:'2',reps:'12',rir:'3',rpe:'6',focus:'استراحة من النقص السعري'}]}
  };
  return plans[goal]||plans.muscle;
}

// ══════════════════════════════════════════════════════
// PREHAB & MOBILITY DATA
// ══════════════════════════════════════════════════════
const PREHAB={
  warmup:[
    {ico:'🚶',name:'مشي خفيف / دراجة ثابتة',eng:'Light Cardio',time:'5 دقائق',color:'rgba(59,130,246,.2)',tip:'ارفع درجة حرارة الجسم تدريجياً'},
    {ico:'⭕',name:'دوران الكتفين',eng:'Shoulder Circles',time:'20 تكرار × 2',color:'rgba(245,158,11,.2)',tip:'دوران كامل للأمام والخلف'},
    {ico:'🦵',name:'دوران الركبتين',eng:'Knee Circles',time:'20 تكرار × 2',color:'rgba(34,197,94,.2)',tip:'دوران خفيف مع ثني طفيف'},
    {ico:'🔄',name:'تدوير الورك',eng:'Hip Circles',time:'15 تكرار × 2',color:'rgba(139,92,246,.2)',tip:'دوران كامل للورك'},
    {ico:'🙌',name:'تمديد الصدر الديناميكي',eng:'Dynamic Chest Stretch',time:'15 تكرار',color:'rgba(200,16,46,.2)',tip:'افتح الذراعين للخلف بسرعة متحكم فيها'},
    {ico:'🦿',name:'هاي نيز',eng:'High Knees',time:'30 ثانية',color:'rgba(249,115,22,.2)',tip:'ارفع الركبتين لمستوى الخصر'},
    {ico:'💃',name:'لانج ووكينج ديناميكي',eng:'Dynamic Lunges',time:'10 تكرار كل جانب',color:'rgba(59,130,246,.2)',tip:'خطوة واسعة مع تدوير الجذع'},
  ],
  mobility:[
    {ico:'🧘',name:'Hip 90/90 Stretch',eng:'Hip 90/90',time:'60 ث × 2 جانب',color:'rgba(139,92,246,.2)',tip:'حافظ على استقامة الظهر — مهم جداً للسكوات'},
    {ico:'🐱',name:'Cat-Cow',eng:'Cat-Cow',time:'10 تكرار',color:'rgba(34,197,94,.2)',tip:'مفيد جداً للعمود الفقري الصدري'},
    {ico:'🦢',name:"World's Greatest Stretch",eng:'WGS',time:'5 تكرار × 2 جانب',color:'rgba(245,158,11,.2)',tip:'يفتح الورك والكتف والصدر دفعة واحدة'},
    {ico:'🔄',name:'Thoracic Rotation',eng:'T-Spine Rotation',time:'10 × 2 جانب',color:'rgba(200,16,46,.2)',tip:'استلقِ جانبياً مع ثني الركبتين'},
    {ico:'🦷',name:'Ankle Circles + Dorsiflexion',eng:'Ankle Mobility',time:'20 تكرار',color:'rgba(59,130,246,.2)',tip:'ضروري لعمق السكوات'},
    {ico:'🤸',name:'Pigeon Pose',eng:'Pigeon Stretch',time:'60 ث × 2 جانب',color:'rgba(249,115,22,.2)',tip:'لفتح الورك الخلفي وبطن الفخذ'},
    {ico:'💪',name:'Shoulder Dislocates (Stick)',eng:'Shoulder Dislocates',time:'10 تكرار',color:'rgba(139,92,246,.2)',tip:'استخدم عصا أو حبلاً بمسافة واسعة'},
  ],
  prehab:[
    {ico:'🔵',name:'Band Pull Aparts',eng:'Band Pull Aparts',time:'3×20',color:'rgba(59,130,246,.2)',tip:'أهم تمرين لصحة الكتف — افعله يومياً'},
    {ico:'🌀',name:'Rotator Cuff External Rotation',eng:'External Rotation',time:'3×15',color:'rgba(34,197,94,.2)',tip:'استخدم حبل مقاومة خفيف'},
    {ico:'🏹',name:'Scapular Push-Ups',eng:'Scapular Push-Up',time:'3×15',color:'rgba(245,158,11,.2)',tip:'يقوي عضلات ثبات لوح الكتف'},
    {ico:'🦵',name:'Terminal Knee Extension (TKE)',eng:'TKE',time:'3×20',color:'rgba(200,16,46,.2)',tip:'يقوي نهاية مدى حركة الركبة — مهم للرياضيين'},
    {ico:'🌉',name:'Glute Bridge March',eng:'Glute Bridge March',time:'3×10 كل جانب',color:'rgba(139,92,246,.2)',tip:'يفعّل الألوية ويثبت الحوض'},
    {ico:'🐛',name:'Dead Bug Progressions',eng:'Dead Bug',time:'3×8 كل جانب',color:'rgba(249,115,22,.2)',tip:'أساسي لثبات الجذع وحماية الظهر'},
    {ico:'🧱',name:'Copenhagen Adductor',eng:'Copenhagen Plank',time:'3×20 ث كل جانب',color:'rgba(59,130,246,.2)',tip:'يقوي العضلة الجامعة — يقلل إصابات الفخذ'},
  ],
  cooldown:[
    {ico:'😮‍💨',name:'تنفس البطن العميق',eng:'Diaphragmatic Breathing',time:'5 دقائق',color:'rgba(34,197,94,.2)',tip:'4 ثانية شهيق، 6 ثانية زفير — يخفض الكورتيزول'},
    {ico:'🦎',name:'Child\'s Pose',eng:"Child's Pose",time:'60 ثانية',color:'rgba(139,92,246,.2)',tip:'يمدد الظهر والوركين'},
    {ico:'🧎',name:'Hip Flexor Stretch',eng:'Hip Flexor Stretch',time:'60 ث × 2 جانب',color:'rgba(245,158,11,.2)',tip:'مهم بعد الجلوس الطويل والسكوات'},
    {ico:'📏',name:'Hamstring Stretch',eng:'Hamstring Stretch',time:'45 ث × 2 جانب',color:'rgba(200,16,46,.2)',tip:'أمسك 30-45 ثانية للتأثير الفعلي'},
    {ico:'🔙',name:'Pec Doorway Stretch',eng:'Pec Stretch',time:'45 ث × 2 جانب',color:'rgba(59,130,246,.2)',tip:'مهم بعد تمارين الصدر والكتفين'},
    {ico:'🌡️',name:'Foam Rolling',eng:'Foam Roll',time:'5-10 دقائق',color:'rgba(249,115,22,.2)',tip:'تحرك ببطء — 30-60 ثانية على كل منطقة'},
  ]
};

// ══════════════════════════════════════════════════════
// CALISTHENICS PROGRESSIONS
// ══════════════════════════════════════════════════════
const CALIS_PROG={
  pushup:{name:'Push-Up Progression',ico:'💪',levels:[
    {name:'Wall Push-Up',cond:'مبتدئ تماماً',sets:'3×15'},
    {name:'Incline Push-Up',cond:'Wall Push-Up 3×20',sets:'3×15'},
    {name:'Knee Push-Up',cond:'Incline 3×15',sets:'3×15'},
    {name:'Full Push-Up',cond:'Knee Push-Up 3×15',sets:'4×20'},
    {name:'Wide Push-Up',cond:'Full Push-Up 4×20',sets:'4×20'},
    {name:'Diamond Push-Up',cond:'Full Push-Up 4×15',sets:'4×15'},
    {name:'Archer Push-Up',cond:'Diamond Push-Up 3×10',sets:'3×10 كل جانب'},
    {name:'Pseudo Planche',cond:'Archer Push-Up 3×10',sets:'3×10'},
    {name:'One Arm Push-Up',cond:'Pseudo Planche 3×10',sets:'3×5 كل جانب'},
  ]},
  pullup:{name:'Pull-Up Progression',ico:'🙌',levels:[
    {name:'Dead Hang',cond:'مبتدئ',sets:'3×30ث'},
    {name:'Inverted Row',cond:'Dead Hang 3×30ث',sets:'3×12'},
    {name:'Band Assisted Pull-Up',cond:'Inverted Row 3×12',sets:'3×8'},
    {name:'Negative Pull-Up',cond:'Band Assisted 3×8',sets:'3×5 (4ث نزول)'},
    {name:'Full Pull-Up',cond:'Negative 3×5',sets:'4×5'},
    {name:'Chin-Up',cond:'Pull-Up 3×8',sets:'4×8'},
    {name:'L-Sit Pull-Up',cond:'Pull-Up 4×10',sets:'3×8'},
    {name:'Wide Grip Pull-Up',cond:'Pull-Up 4×10',sets:'4×8'},
    {name:'Weighted Pull-Up',cond:'Pull-Up 4×12',sets:'4×6 (+وزن)'},
    {name:'Muscle-Up (Kipping)',cond:'Pull-Up 4×10',sets:'3×5'},
    {name:'Strict Muscle-Up',cond:'Muscle-Up 3×5',sets:'3×3'},
  ]},
  plank:{name:'Plank Progression',ico:'🔲',levels:[
    {name:'Knee Plank',cond:'مبتدئ',sets:'3×20ث'},
    {name:'Full Plank',cond:'Knee Plank 3×30ث',sets:'3×30ث'},
    {name:'RKC Plank',cond:'Full Plank 3×45ث',sets:'3×20ث'},
    {name:'Plank + Shoulder Tap',cond:'Full Plank 3×60ث',sets:'3×10 كل جانب'},
    {name:'Plank to Down Dog',cond:'Plank + Tap 3×20',sets:'3×10'},
    {name:'Plank Row',cond:'Plank Tap 3×20',sets:'3×8 كل جانب'},
    {name:'Weighted Plank',cond:'Full Plank 3×90ث',sets:'3×45ث (+وزن)'},
    {name:'Ab Wheel (Knees)',cond:'Plank 3×90ث',sets:'3×10'},
    {name:'Ab Wheel (Standing)',cond:'Ab Wheel Knees 3×15',sets:'3×8'},
  ]}
};

// ══════════════════════════════════════════════════════
// ACHIEVEMENTS
// ══════════════════════════════════════════════════════
const ACHIEVEMENTS=[
  {id:'first_workout',ico:'🥇',name:'أول تمرين',desc:'أكملت تمرينك الأول',cond:u=>u.workouts?.length>=1},
  {id:'week_streak',ico:'🔥',name:'أسبوع متواصل',desc:'7 أيام تدريب متتالية',cond:u=>calcStreak(u.workouts)>=7},
  {id:'month_warrior',ico:'🏆',name:'محارب الشهر',desc:'20 تمرين في شهر واحد',cond:u=>{const now=new Date();return(u.workouts||[]).filter(w=>{const d=new Date(w.date);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear();}).length>=20;}},
  {id:'hundred_sets',ico:'💪',name:'100 مجموعة',desc:'أكملت 100 مجموعة تراكمياً',cond:u=>(u.workouts||[]).reduce((s,w)=>s+(w.totalSets||0),0)>=100},
  {id:'weight_tracker',ico:'⚖️',name:'متتبع الوزن',desc:'سجلت وزنك 10 مرات',cond:u=>(u.weights||[]).length>=10},
  {id:'water_champ',ico:'💧',name:'بطل الترطيب',desc:'شربت 8 أكواب يوماً كاملاً',cond:u=>Object.values(u.water||{}).some(v=>v>=8)},
  {id:'chal_complete',ico:'🎯',name:'منجز التحديات',desc:'أكملت تحدياً كاملاً',cond:u=>Object.values(u.challenges||{}).filter((v,k)=>k!=='active'&&typeof v==='number').some((v,i,a)=>{const chal=CHALLENGES[i];return chal&&v>=chal.days;})},
  {id:'ai_user',ico:'🤖',name:'صديق الذكاء',desc:'أرسلت 20 رسالة للمدرب الذكي',cond:u=>(u.aiMsgs||0)>=20},
  {id:'prehab_pro',ico:'🧘',name:'محترف Prehab',desc:'أكملت 10 جلسات Prehab',cond:u=>(u.prehabSessions||0)>=10},
];

// ══════════════════════════════════════════════════════
// ONBOARDING LOGIC
// ══════════════════════════════════════════════════════
let OB={name:'',age:25,gender:'male',country:'',weight:0,height:0,targetWeight:0,activity:1.375,goal:null,level:'beginner',primarySport:null,supportSports:[],equipment:['bodyweight'],days:3,duration:45,limits:[],step:0};

function obGo(step){
  const cur=OB.step;
  if(cur===0){OB.name=document.getElementById('ob-name').value.trim();OB.age=parseInt(document.getElementById('ob-age').value);OB.gender=document.getElementById('ob-gender').value;OB.country=document.getElementById('ob-country')?.value.trim()||'';OB.name=cleanStr(OB.name);if(!OB.name){shake('obs0');return toast('أدخل اسمك ✋','⚠️');}if(!(OB.age>=13&&OB.age<=100)){shake('obs0');return toast('أدخل عمراً صحيحاً (13–100) — التطبيق غير مخصّص لمن هم دون 13','⚠️');}if(!healthConsent(()=>obGo(step)))return;}
  if(cur===1){OB.weight=parseFloat(document.getElementById('ob-wt').value)||0;OB.height=parseFloat(document.getElementById('ob-ht').value)||0;OB.targetWeight=parseFloat(document.getElementById('ob-twt')?.value)||0;OB.activity=parseFloat(document.getElementById('ob-act').value)||1.375;if(!(OB.weight>=30&&OB.weight<=300&&OB.height>=100&&OB.height<=250)){shake('obs1');return toast('أدخل وزناً (30–300 كغ) وطولاً (100–250 سم) صحيحين ✋','⚠️');}}
  if(cur===2&&!OB.goal){shake('obs2');return toast('اختر هدفك 🎯','⚠️');}
  if(cur===4&&!OB.primarySport){shake('obs4');return toast('اختر رياضتك الأساسية ⭐','⚠️');}
  if(step===7)obSummary();
  document.getElementById('obs'+cur).classList.remove('on');
  OB.step=step;
  document.getElementById('obs'+step)?.classList.add('on');
  document.querySelectorAll('#ob-dots .dot').forEach((d,i)=>d.classList.toggle('on',i===step));
  document.getElementById('ob-slbl').textContent=`الخطوة ${step+1} من 8`;
  document.getElementById('ob').scrollTop=0;
}

function obBMI(){
  const w=parseFloat(document.getElementById('ob-wt').value);
  const h=parseFloat(document.getElementById('ob-ht').value)/100;
  if(!w||!h)return;
  const bmi=w/(h*h),act=parseFloat(document.getElementById('ob-act').value)||1.375;
  const tdee=calcTDEE(w,h*100,OB.age,OB.gender,act);
  document.getElementById('bmi-box').style.display='block';
  document.getElementById('bmi-val').textContent=bmi.toFixed(1);
  document.getElementById('bmi-lbl').textContent=(OB.age&&OB.age<18)?'للمراهقين يُفسَّر BMI بمنحنيات النمو — استشر طبيباً':(bmi<18.5?'نقص في الوزن ⚠️':bmi<25?'وزن طبيعي ✅':bmi<30?'زيادة بسيطة ⚠️':'BMI مرتفع (قد لا يعكس الرياضيين ذوي الكتلة العضلية)');
  document.getElementById('tdee-val').textContent=Math.round(tdee);
  document.getElementById('bmi-dot').style.right=Math.min(97,Math.max(3,((bmi-15)/25)*100))+'%';
}

function obGoal(g,el){OB.goal=g;document.querySelectorAll('#goal-grid .sport-card').forEach(c=>c.classList.remove('primary'));el.classList.add('primary');}
function obLevel(l,el){OB.level=l;document.querySelectorAll('.lv-opt').forEach(c=>c.classList.remove('on'));el.classList.add('on');}

function buildSportGrids(){
  const p4=document.getElementById('primary-sport-grid'),p5=document.getElementById('support-sport-grid');
  if(!p4||!p5)return;p4.innerHTML='';p5.innerHTML='';
  SPORTS.forEach(sp=>{
    const mk=(forP)=>{
      const d=document.createElement('div');d.className='sport-card';d.dataset.spid=sp.id;
      d.innerHTML=`<div class="sp-ico">${sp.ico}</div><div class="sp-name">${sp.name}</div><div class="sp-eng">${sp.eng}</div>`;
      if(forP){d.onclick=()=>{document.querySelectorAll('#primary-sport-grid .sport-card').forEach(c=>{c.classList.remove('primary');c.querySelector('.sp-badge')?.remove();});OB.primarySport=sp.id;d.classList.add('primary');d.insertAdjacentHTML('beforeend','<div class="sp-badge sp-pri">⭐ أساسية</div>');OB.supportSports=OB.supportSports.filter(s=>s!==sp.id);document.querySelectorAll(`#support-sport-grid .sport-card[data-spid="${sp.id}"]`).forEach(c=>{c.classList.remove('support');c.querySelector('.sp-badge')?.remove();});};}
      else{d.onclick=()=>{if(OB.primarySport===sp.id)return toast('هذه رياضتك الأساسية ⭐','⚠️');const idx=OB.supportSports.indexOf(sp.id);if(idx>-1){OB.supportSports.splice(idx,1);d.classList.remove('support');d.querySelector('.sp-badge')?.remove();}else{if(OB.supportSports.length>=3)return toast('الحد الأقصى 3 رياضات','⚠️');OB.supportSports.push(sp.id);d.classList.add('support');d.insertAdjacentHTML('beforeend','<div class="sp-badge sp-sup">🔴 داعمة</div>');}};}
      return d;
    };
    p4.appendChild(mk(true));p5.appendChild(mk(false));
  });
}

function initEquipCards(){
  document.querySelectorAll('#eq-grid .eq-card').forEach(c=>{
    c.onclick=()=>{
      if(c.dataset.eq==='full_gym'){const all=['bodyweight','dumbbells','barbell','bench','pullup_bar','parallel_bars','bands','kettlebell','cables','machines','full_gym','cardio_machine'];const on=c.classList.contains('on');document.querySelectorAll('#eq-grid .eq-card').forEach(cc=>cc.classList.toggle('on',!on));OB.equipment=on?['bodyweight']:all;return;}
      c.classList.toggle('on');OB.equipment=[...document.querySelectorAll('#eq-grid .eq-card.on')].map(cc=>cc.dataset.eq);if(!OB.equipment.length)OB.equipment=['bodyweight'];
    };
  });
}

function chipOne(el,id){document.querySelectorAll('#'+id+' .chip').forEach(c=>c.classList.remove('on'));el.classList.add('on');}

function obSummary(){
  OB.days=parseInt(document.querySelector('#days-chips .chip.on')?.textContent)||3;
  OB.duration=parseInt(document.querySelector('#dur-chips .chip.on')?.textContent)||45;
  OB.limits=[...document.querySelectorAll('.inj-card.on')].map(c=>c.dataset.inj).filter(Boolean);
  const GOAL_AR={muscle:'بناء العضلات 💪',fat_loss:'خسارة الدهون 🔥',strength:'زيادة القوة ⚡',endurance:'تحسين التحمل 🏃',recomp:'تحسين التناسق ⚖️',maintain:'المحافظة 🛡'};
  const LV_AR={beginner:'مبتدئ 🌱',intermediate:'متوسط 🔥',advanced:'متقدم ⚡'};
  const primSp=SPORTS.find(s=>s.id===OB.primarySport);
  const suppSps=OB.supportSports.map(id=>SPORTS.find(s=>s.id===id)?.name).filter(Boolean);
  const tdee=calcTDEE(OB.weight,OB.height,OB.age,OB.gender,OB.activity);
  const cals=calcCals(tdee,OB.goal,OB.age,OB.gender),prot=calcProtein(OB.weight,OB.goal);
  document.getElementById('ob-sum').innerHTML=`
<div>🎯 الهدف: <b style="color:var(--red)">${GOAL_AR[OB.goal]||OB.goal}</b></div>
<div>📊 المستوى: <b>${LV_AR[OB.level]}</b></div>
<div>⭐ الرياضة الأساسية: <b style="color:var(--y)">${primSp?.name||'--'} ${primSp?.ico||''}</b></div>
${suppSps.length?`<div>🔴 الرياضات الداعمة: <b>${suppSps.join(' + ')}</b></div>`:''}
<div>⚖️ الوزن: <b>${OB.weight} كغ</b> | الطول: <b>${OB.height} سم</b></div>
<div>🔥 TDEE: <b style="color:var(--y)">${Math.round(tdee)}</b> → هدف: <b style="color:var(--g)">${cals} سعرة/يوم</b></div>
<div>🥩 البروتين: <b>${prot} غ/يوم</b> | الجدول: <b>${getSplit(OB.days,OB.primarySport,OB.goal,OB.level)}</b></div>
${OB.limits.filter(l=>l!=='none').length?`<div>⚠️ قيود: <b style="color:var(--y)">${OB.limits.filter(l=>l!=='none').join('، ')}</b></div>`:''}`;
}

async function obFinish(){
  OB.days=parseInt(document.querySelector('#days-chips .chip.on')?.textContent)||3;
  OB.duration=parseInt(document.querySelector('#dur-chips .chip.on')?.textContent)||45;
  OB.limits=[...document.querySelectorAll('.inj-card.on')].map(c=>c.dataset.inj).filter(Boolean);
  OB.equipment=[...document.querySelectorAll('#eq-grid .eq-card.on')].map(c=>c.dataset.eq);
  if(!OB.equipment.length)OB.equipment=['bodyweight'];
  if(!OB.primarySport)OB.primarySport='general';
  const obKey=(document.getElementById('ob-gemini-key')?.value||'').trim();
  if(obKey)setGeminiKey(obKey);
  document.getElementById('obs7').classList.remove('on');
  document.getElementById('obs-gen').classList.add('on');
  const gs=['gs1','gs2','gs3','gs4','gs5','gs6','gs7'];
  for(let i=0;i<gs.length;i++){await new Promise(r=>setTimeout(r,360));if(i>0)document.getElementById(gs[i-1]).className='gen-step done';document.getElementById(gs[i]).className='gen-step active';}
  await new Promise(r=>setTimeout(r,360));document.getElementById(gs[gs.length-1]).className='gen-step done';await new Promise(r=>setTimeout(r,280));
  const program=buildProgram(OB);
  const tdee=calcTDEE(OB.weight,OB.height,OB.age,OB.gender,OB.activity);
  const calories=calcCals(tdee,OB.goal,OB.age,OB.gender),protein=Math.min(calcProtein(OB.weight,OB.goal),Math.round(calories*0.35/4)),fat=Math.round(Math.min(OB.weight*1.0,calories*0.30/9)),carbs=calcCarbs(calories,protein,fat);
  const bmi=(OB.weight/((OB.height/100)**2)).toFixed(1);
  APP.user={name:OB.name,age:OB.age,gender:OB.gender,country:OB.country,goal:OB.goal,level:OB.level,primarySport:OB.primarySport,supportSports:OB.supportSports,equipment:OB.equipment,days:OB.days,duration:OB.duration,limits:OB.limits,activity:OB.activity,weight:OB.weight,height:OB.height,targetWeight:OB.targetWeight,tdee:Math.round(tdee),calories,protein,fat,carbs,bmi,joinDate:new Date().toISOString(),program};
  if(OB.weight)APP.weights.push({value:OB.weight,date:new Date().toISOString(),note:'وزن البداية'});
  save();document.getElementById('ob').style.display='none';showProgResult(APP.user);
  // الخطة الجاهزة أعلاه تعمل فوراً بلا انتظار وتبقى كضمانة دائمة. إذا أضاف
  // المستخدم مفتاح Gemini، نبني نسخة ذكية مخصصة في الخلفية بدون حجب الواجهة —
  // بمجرد جهوزيتها تصبح تلقائياً ما يُشغّله "ابدأ التمرين" من الرئيسية.
  if(getGeminiKey())generateAiInitialPlan();
}
// ══════════════════════════════════════════════════════
// AI-GENERATED INITIAL PLAN — يُستدعى فقط إذا كان هناك مفتاح Gemini. يبني خطة
// من الصفر بناءً على بيانات التسجيل (وليس تحليل نص جاهز)، بنفس بنية JSON التي
// يستخدمها تحليل البرنامج المخصص أصلاً — فيُعاد استخدام كل البنية التحتية
// المُختبرة (العرض، بدء التمرين) بلا حاجة لمسار جديد منفصل وهش.
// فشل الاتصال هنا لا يؤثر على شيء ظاهر للمستخدم: الخطة الجاهزة أعلاه تعمل
// بالفعل، فهذه فقط تحسين إضافي صامت إن نجح.
// ══════════════════════════════════════════════════════
async function generateAiInitialPlan(){
  const u=APP.user;if(!u)return;
  const GOAL_AR={muscle:'بناء العضلات',fat_loss:'خسارة الدهون',strength:'زيادة القوة',endurance:'تحسين التحمل',recomp:'تحسين التناسق',maintain:'المحافظة'};
  const LEVEL_AR={beginner:'مبتدئ',intermediate:'متوسط',advanced:'متقدم'};
  const equipAr=(u.equipment||[]).join('، ')||'وزن الجسم فقط';
  const limitsAr=(u.limits||[]).filter(l=>l&&l!=='none').join('، ')||'لا يوجد';
  const sys=`أنت مدرب رياضي محترف مبني على معايير NSCA · ACSM · ISSN. مهمتك بناء خطة تدريب أسبوعية مخصصة بالكامل من الصفر بناءً على بيانات المستخدم أدناه (وليس تحليل نص موجود مسبقاً).

بيانات المستخدم:
- الهدف: ${GOAL_AR[u.goal]||u.goal||'لياقة عامة'}
- المستوى: ${LEVEL_AR[u.level]||u.level||'مبتدئ'}
- أيام التدريب أسبوعياً: ${u.days||3}
- مدة الجلسة: ${u.duration||45} دقيقة
- المعدات المتوفرة: ${equipAr}
- إصابات/قيود: ${limitsAr}

القواعد:
- أرجع JSON فقط، بدون أي نص قبله أو بعده، بدون Markdown fences.
- بنية الإخراج المطلوبة (نفس البنية تماماً):
{"days":[{"dayKey":"ithnin","isRest":false,"title":"صدر + كتفين","exercises":[
  {"name":"دوران الكتفين","nameEn":"Shoulder Circles","phase":"warmup","sets":1,"repsLo":15,"repsHi":15,"restSeconds":0,"notes":"إحماء ديناميكي","isPrimary":false},
  {"name":"بنش بريس","nameEn":"Bench Press","phase":"main","sets":4,"repsLo":6,"repsHi":10,"restSeconds":120,"notes":"","isPrimary":true},
  {"name":"تمديد الصدر","nameEn":"Pec Stretch","phase":"cooldown","sets":1,"repsLo":45,"repsHi":45,"restSeconds":0,"notes":"إطالة ثابتة بعد التمرين","isPrimary":false}
]}],"summary":{"totalTrainingDays":${u.days||3},"totalRestDays":${7-(u.days||3)},"warnings":[],"recommendations":["توصيتان أو ثلاث قصيرة لبدء البرنامج بأمان"]}}
- استخدم مفاتيح dayKey بالضبط بهذا الترتيب للأسبوع: ahad, ithnin, thulatha, arbaa, khamis, jumua, sabt — أرجع الأيام السبعة كلها.
- وزّع ${u.days||3} أيام تدريب فقط على الأسبوع بذكاء بحيث لا تتكرر نفس المجموعة العضلية يومين متتاليين، والباقي isRest:true وexercises:[].
- اختر فقط تمارين ممكنة بالمعدات المذكورة أعلاه، وتجنّب أي تمرين يتعارض مع القيود المذكورة (مثلاً: قيد "كتف" يعني تجنّب أوفرهيد برس وبنش بريس الثقيل).
- كل تمرين يحمل حقل "phase" إلزامياً: "warmup" (إحماء ديناميكي) أو "main" (تمرين القوة الأساسي) أو "cooldown" (إطالة ثابتة).
- لكل يوم تدريب: ابدأ بـ 2-3 تمارين "warmup" مرتبطة تحديداً بالعضلات التي سيعمل عليها اليوم (لا إحماء عام فقط) — بلا وزن أو راحة (sets:1، ضع مدة التكرار بالثواني أو عدد التكرارات في repsLo/repsHi، restSeconds:0)، ثم 4-6 تمارين "main" حسب مدة الجلسة (${u.duration||45} دقيقة)، ثم 2 تمارين "cooldown" (إطالات ثابتة للعضلات المستهدفة، sets:1، مدة الإطالة بالثواني في repsLo/repsHi، restSeconds:0).
- المجموعات والتكرارات لتمارين phase:"main" حسب الهدف: بناء عضلات=3-4 مجموعات×8-12 تكرار، قوة=3-5×3-6، خسارة دهون=3×10-15، تحمل=2-3×15-20.
- ضع "isPrimary":true لتمرين واحد فقط من تمارين phase:"main" لكل يوم تدريب (التمرين المركّب الأساسي) — لا تضعها أبداً على الإحماء أو الإطالة.
- تذكير أخير حاسم: ردّك بالكامل يجب أن يكون JSON صالحاً فقط — أول حرف فيه { وآخر حرف }. لا مقدمة ولا خاتمة ولا Markdown.`;
  try{
    const data=await callAI(sys,[{role:'user',content:'ابنِ خطتي التدريبية الأسبوعية الآن حسب بياناتي والتعليمات أعلاه.'}],16000);
    if(data?.error)throw new Error(data.error.message);
    const raw=extractApiText(data);
    const parsed=parseAiProgramJson(raw);
    (APP.plans=APP.plans||[]).forEach(p=>{p.isPrimary=false;});
    APP.plans.push({id:genPlanId(),type:'ai-onboarding',name:'خطتك الذكية 🤖',text:'',parsed,isPrimary:true,createdAt:new Date().toISOString()});
    save();
    renderCustomBanner();renderHome();
    toast('🤖 خطتك الذكية من Gemini جاهزة الآن!');
  }catch(e){
    console.error('AI initial plan generation failed:',e);
  }
}

// ══════════════════════════════════════════════════════
// PROGRAM RESULT
// ══════════════════════════════════════════════════════
function showProgResult(u){
  const primSp=SPORTS.find(s=>s.id===u.primarySport),suppSps=(u.supportSports||[]).map(id=>SPORTS.find(s=>s.id===id)).filter(Boolean),prog=u.program;
  const MEAL={muscle:'وجبة بروتينية كل 3-4 ساعات. 25-40 غ بروتين بعد التمرين مباشرة.',fat_loss:'3 وجبات. بروتين عالٍ يقلل الجوع ويحمي العضلة.',strength:'كارب قبل التمرين بساعتين. بروتين + كارب بعده.',endurance:'كارب محيط بالتمرين. ترطيب 3+ لترات يومياً.',recomp:'كارب حول التمرين فقط. دهون معتدلة.',maintain:'تناول TDEE بدقة. راقب الوزن أسبوعياً.'};
  let h=`<div style="text-align:center;padding:16px 0 12px"><div style="font-size:42px;margin-bottom:7px">🎉</div><div style="font-size:19px;font-weight:900">برنامجك جاهز، ${escapeHtml(u.name)}!</div><div style="font-size:11px;color:var(--w40);margin-top:2px">NSCA · ACSM · ISSN</div></div>`;
  h+=`<div style="background:linear-gradient(135deg,#1a0f00,#2d1e00);border:1px solid rgba(245,158,11,.28);border-radius:13px;padding:13px;margin-bottom:10px"><div style="font-size:12px;font-weight:800;color:var(--y);margin-bottom:8px">⭐ هيكل الرياضات</div><div style="display:flex;align-items:center;gap:9px;padding:9px;background:rgba(245,158,11,.07);border-radius:9px;margin-bottom:7px"><span style="font-size:28px">${primSp?.ico||'🌟'}</span><div><div style="font-size:13px;font-weight:800">${primSp?.name||'لياقة عامة'}</div><div style="font-size:11px;color:var(--y)">⭐ الرياضة الأساسية — البرنامج يخدمها أولاً</div></div></div>${suppSps.length?`<div style="font-size:11px;color:var(--w40);margin-bottom:5px">🔴 الرياضات الداعمة:</div><div style="display:flex;gap:6px;flex-wrap:wrap">${suppSps.map(sp=>`<span style="background:rgba(200,16,46,.14);border:1px solid rgba(200,16,46,.24);border-radius:7px;padding:4px 9px;font-size:11px">${sp.ico} ${sp.name}</span>`).join('')}</div>`:''}</div>`;
  h+=`<div style="background:linear-gradient(135deg,#071505,#0a1f07);border:1px solid rgba(34,197,94,.26);border-radius:13px;padding:13px;margin-bottom:10px"><div style="font-size:12px;font-weight:800;color:var(--g);margin-bottom:9px">🍽️ خطتك الغذائية اليومية</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:8px"><div style="background:rgba(0,0,0,.3);border-radius:9px;padding:9px;text-align:center"><div style="font-size:20px;font-weight:900;color:var(--g)">${u.calories}</div><div style="font-size:11px;color:var(--w40)">سعرة / يوم</div></div><div style="background:rgba(0,0,0,.3);border-radius:9px;padding:9px;text-align:center"><div style="font-size:20px;font-weight:900;color:var(--b)">${u.protein}غ</div><div style="font-size:11px;color:var(--w40)">بروتين</div></div><div style="background:rgba(0,0,0,.3);border-radius:9px;padding:9px;text-align:center"><div style="font-size:20px;font-weight:900;color:var(--y)">${u.carbs}غ</div><div style="font-size:11px;color:var(--w40)">كربوهيدرات</div></div><div style="background:rgba(0,0,0,.3);border-radius:9px;padding:9px;text-align:center"><div style="font-size:20px;font-weight:900;color:#F87171">${u.fat}غ</div><div style="font-size:11px;color:var(--w40)">دهون</div></div></div><div style="font-size:11px;color:var(--w60);background:rgba(0,0,0,.2);border-radius:8px;padding:9px;line-height:1.75">💡 ${MEAL[u.goal]||''}</div><div style="font-size:11px;color:var(--w40);text-align:center;margin-top:6px">TDEE: ${u.tdee} | BMI: ${u.bmi}</div></div>`;
  h+=`<div style="background:linear-gradient(135deg,#1a0008,#2d0012);border:1px solid rgba(200,16,46,.26);border-radius:13px;padding:13px;margin-bottom:10px"><div style="font-size:12px;font-weight:800;color:var(--red);margin-bottom:8px">🏋️ ${prog.splitLabel}</div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:8px"><div style="text-align:center;background:rgba(0,0,0,.3);border-radius:8px;padding:7px"><div style="font-size:16px;font-weight:900;color:var(--red)">${u.days}</div><div style="font-size:11px;color:var(--w40)">أيام/أسبوع</div></div><div style="text-align:center;background:rgba(0,0,0,.3);border-radius:8px;padding:7px"><div style="font-size:16px;font-weight:900;color:var(--y)">${prog.sets}</div><div style="font-size:11px;color:var(--w40)">مجموعات</div></div><div style="text-align:center;background:rgba(0,0,0,.3);border-radius:8px;padding:7px"><div style="font-size:13px;font-weight:900;color:var(--b)">${prog.vp.lo}-${prog.vp.hi}</div><div style="font-size:11px;color:var(--w40)">تكرار</div></div></div><div style="font-size:11px;color:rgba(var(--wa),.72);background:rgba(0,0,0,.2);border-radius:8px;padding:9px;line-height:1.9">📈 ${prog.progression}<br>⏱ راحة ${prog.vp.rest} ثانية | 🎯 RIR: ${prog.vp.rir}</div></div>`;
  h+=`<div style="display:flex;align-items:center;gap:8px;margin-bottom:9px"><div style="font-size:14px;font-weight:800">📅 جدولك الأسبوعي</div><span style="font-size:11px;background:rgba(34,197,94,.16);color:var(--g);padding:3px 9px;border-radius:10px;font-weight:700">😴 ${prog.restDayCount||0} أيام راحة مجدولة</span></div>`;
  h+=renderPhaseCard('warmup')+renderPhaseCard('cooldown');
  const bgC=['#1a0508','#0a1205','#0a0a1a','#1a0f00','#100F26','#1a1500'];
  prog.schedule.forEach((day,di)=>{
    if(day.isRest){h+=`<div style="background:rgba(34,197,94,.05);border:1px dashed rgba(34,197,94,.28);border-radius:12px;margin-bottom:8px;padding:11px 13px;display:flex;align-items:center;gap:10px"><span style="font-size:20px">😴</span><div><div style="font-size:12px;font-weight:800;color:var(--g)">${day.day} — راحة</div><div style="font-size:11px;color:var(--w60);margin-top:1px">${day.focus}</div></div></div>`;return;}
    h+=`<div style="background:${bgC[di%6]};border:1px solid rgba(var(--wa),.07);border-radius:12px;margin-bottom:8px;overflow:hidden"><div style="padding:10px 13px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(var(--wa),.05)"><div><div style="font-size:12px;font-weight:800;color:${day.isSport?'var(--y)':'var(--red)'}">${day.isSport?'⭐ ':''}${day.day} — ${day.label}</div><div style="font-size:11px;color:var(--w60);margin-top:2px">${day.focus}</div></div><div style="font-size:11px;color:var(--w40)">${(day.exIds||[]).length} تمرين</div></div><div style="padding:10px 13px">${(day.exIds||[]).map((id)=>{const ex=EX[id];if(!ex)return'';const rep=ex.isTimed?`${ex.lo||30}-${ex.hi||60} ث`:ex.unit||`${ex.lo||8}-${ex.hi||12} تكرار`;const alts=getExerciseAlts(id,u.equipment,u.limits);const imgClass=ex.isTimed?'timed-ex':'';return`<div class="ex-list-item" onclick="showExDetail('${id}')" style="margin-bottom:7px;background:rgba(var(--wa),.03)">${exVisual(id,ex.ico,imgClass)}<div class="ex-details"><div class="ex-name-ar">${ex.n}</div><div class="ex-name-en">${ex.e}</div><div class="ex-pills"><span class="pill pill-red">${prog.sets}×${rep}</span><span class="pill pill-b">${ex.rest}ث</span></div></div>${ex.e?`<button onclick="event.stopPropagation();watchExDemo('${ex.e.replace(/'/g,"\\'")}')" style="background:rgba(200,16,46,.14);border:none;color:var(--red);border-radius:8px;padding:6px 9px;font-size:12px;cursor:pointer;flex-shrink:0">🎥</button>`:''}${alts.length?`<button onclick="event.stopPropagation();showAlts('${id}')" style="background:rgba(59,130,246,.14);border:1px solid rgba(59,130,246,.28);color:var(--b);border-radius:8px;padding:6px 9px;font-size:11px;cursor:pointer;font-family:inherit;flex-shrink:0">بدائل</button>`:''}</div>`;}).join('')}</div></div>`;
  });
  h+=`<div style="background:var(--b3);border:1px solid rgba(var(--wa),.05);border-radius:12px;padding:12px"><div style="font-size:11px;font-weight:800;color:var(--w40);margin-bottom:6px">📚 المراجع العلمية</div><div style="font-size:11px;color:var(--w40);line-height:2.1">• Schoenfeld BJ (2010) — Mechanisms of Muscle Hypertrophy (NSCA)<br>• Krieger JW (2010) — Single vs Multiple Sets Meta-Analysis<br>• Israetel M (2019) — MEV/MAV Volume Landmarks (RP Strength)<br>• Mifflin-St Jeor (1990) — BMR Equation (ACSM Endorsed)<br>• Stokes T et al (2018) — Protein for Hypertrophy — J Sports Sci<br>• ISSN Position Stand (2017) — Nutrition & Exercise Performance<br>• NSCA (2016) — Essentials of Strength Training & Conditioning</div></div>`;
  document.getElementById('prog-body').innerHTML=h;
  document.getElementById('prog-screen').classList.add('on');
}

function launchApp(){document.getElementById('prog-screen').classList.remove('on');showAppShell();toast('🎉 أهلاً بك، '+(APP.user?.name||'')+'!');renderAll();showPg('home');}
function showMyProgram(){if(APP.user?.program)showProgResult(APP.user);else toast('أكمل الإعداد أولاً','⚠️');}
function copyProgram(){const u=APP.user;if(!u?.program)return;const prog=u.program;const primSp=SPORTS.find(s=>s.id===u.primarySport);let t=`🏋️ AC Fitness V2 — برنامج ${u.name}\n⭐ الرياضة الأساسية: ${primSp?.name||'لياقة عامة'}\n📅 ${prog.splitLabel}\n📈 ${prog.progression}\n😴 ${prog.restDayCount||0} أيام راحة أسبوعياً\n\n🍽️ التغذية: ${u.calories} سعرة | بروتين ${u.protein}غ | كارب ${u.carbs}غ\n\n━━━━━━━━━━━━━━━━━\n`;prog.schedule.forEach(d=>{if(d.isRest){t+=`\n${d.day} — 😴 راحة\n`;return;}t+=`\n${d.day} — ${d.label}\n${d.focus}\n`;(d.exIds||[]).forEach(id=>{const ex=EX[id];if(ex){const rep=ex.isTimed?`${ex.lo}-${ex.hi}ث`:ex.unit||`${ex.lo}-${ex.hi} تكرار`;t+=`• ${ex.n}: ${prog.sets}×${rep} | راحة ${ex.rest}ث\n`;}});});t+=`\n━━━━━━━━━━━━━━━━━\nمصدر: AC Fitness V2 | NSCA · ACSM · ISSN`;fallbackCopy(t);toast('✅ تم نسخ البرنامج كاملاً!');}

// ══════════════════════════════════════════════════════
// EXERCISE DETAIL + ALTERNATIVES
// ══════════════════════════════════════════════════════
function showExDetail(id){
  const ex=EX[id];if(!ex)return;
  document.getElementById('ex-dt').textContent=ex.ico+' '+ex.n;
  const alts=getExerciseAlts(id,APP.user?.equipment,APP.user?.limits);
  const bigPose=renderPoseSVG(id);
  document.getElementById('ex-db').innerHTML=`
  ${bigPose?`<div style="text-align:center;margin-bottom:13px"><div class="pose-lg">${bigPose}</div><div style="font-size:11px;color:var(--w40)">توضيح حركة التمرين</div></div>`:''}
  <div class="sg" style="margin-bottom:11px">
    <div class="sc"><div class="sc-l">العضلة الأساسية</div><div class="sc-v" style="font-size:12px">${ex.mu}</div></div>
    <div class="sc"><div class="sc-l">المستوى</div><div class="sc-v" style="font-size:12px">${ex.lv==='beg'?'مبتدئ':ex.lv==='int'?'متوسط':'متقدم'}</div></div>
    <div class="sc r"><div class="sc-l">RPE</div><div class="sc-v">${ex.rpe||7}</div></div>
    <div class="sc b"><div class="sc-l">Tempo</div><div class="sc-v" style="font-size:12px">${ex.tempo||'2-0-1'}</div></div>
  </div>
  ${ex.sec?`<div class="card-dark card" style="padding:10px;margin-bottom:8px"><div style="font-size:11px;color:var(--w40)">العضلات المساعدة</div><div style="font-size:12px;margin-top:2px">${ex.sec}</div></div>`:''}
  <div class="card" style="padding:10px;margin-bottom:8px"><div style="font-size:11px;font-weight:700;color:var(--red);margin-bottom:5px">📋 طريقة الأداء</div><div style="font-size:11px;line-height:1.85;color:var(--w60)">${(ex.how&&ex.how.length)?ex.how.map((c,i)=>`${i+1}. ${c}`).join('<br>'):'• أدِّ الحركة ببطء ووعي كامل<br>• تنفس بانتظام — زفير في مرحلة الجهد<br>• حافظ على العمود الفقري محايداً<br>• حركة كاملة المدى (Full ROM)'}</div></div>
  ${ex.lo&&ex.hi?`<div style="background:rgba(142,124,255,.07);border:1px solid rgba(142,124,255,.18);border-radius:10px;padding:10px;margin-bottom:8px;display:flex;align-items:center;gap:8px"><span style="font-size:15px">🎯</span><span style="font-size:11px;color:var(--w60)">نطاق التكرار المقترح: <b style="color:var(--g)">${ex.lo}-${ex.hi}</b></span></div>`:''}
  <div style="background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.18);border-radius:10px;padding:10px;margin-bottom:8px"><div style="font-size:11px;font-weight:700;color:var(--y);margin-bottom:4px">⚠️ الأخطاء الشائعة</div><div style="font-size:11px;color:var(--w60)">${ex.err||'—'}</div></div>
  ${alts.length?`<div style="font-size:11px;font-weight:700;color:var(--b);margin-bottom:7px">🔄 البدائل المتاحة</div>${alts.map(id=>{const a=EX[id];return a?`<div class="ex-list-item" onclick="hideMo('mo-ex-detail');showExDetail('${id}')">${exVisual(id,a.ico,a.isTimed?'timed-ex':'')}<div class="ex-details"><div class="ex-name-ar">${a.n}</div><div class="ex-name-en">${a.e} · ${a.mu}</div></div><span class="pill ${a.lv==='beg'?'pill-g':a.lv==='int'?'pill-y':'pill-red'}" style="flex-shrink:0">${a.lv==='beg'?'مبتدئ':a.lv==='int'?'متوسط':'متقدم'}</span></div>`:''}).join('')}`:''}
  <button class="btn btn-p" style="margin-top:10px" onclick="addExToWorkout('${id}');hideMo('mo-ex-detail')">+ إضافة للتمرين الحالي</button>`;
  showMo('mo-ex-detail');
}
function showAlts(id){const ex=EX[id];if(!ex)return;const alts=getExerciseAlts(id,APP.user?.equipment,APP.user?.limits);document.getElementById('ex-dt').textContent='🔄 بدائل: '+ex.n;document.getElementById('ex-db').innerHTML=alts.length?alts.map(i=>{const a=EX[i];return a?`<div class="ex-list-item" onclick="showExDetail('${i}')">${exVisual(i,a.ico,a.isTimed?'timed-ex':'')}<div class="ex-details"><div class="ex-name-ar">${a.n}</div><div class="ex-name-en">${a.e} · ${a.mu}</div></div><span class="pill ${a.lv==='beg'?'pill-g':a.lv==='int'?'pill-y':'pill-red'}" style="flex-shrink:0">${a.lv==='beg'?'مبتدئ':a.lv==='int'?'متوسط':'متقدم'}</span></div>`:''}).join(''):'<div class="empty"><div class="empty-ico">🔍</div><div class="empty-t">لا توجد بدائل بمعداتك</div></div>';showMo('mo-ex-detail');}

// ══════════════════════════════════════════════════════
// PROGRAMS PAGE
// ══════════════════════════════════════════════════════
function renderPrograms(){
  const u=APP.user;
  if(!u?.program){document.getElementById('my-prog-content').innerHTML='<div class="empty"><div class="empty-ico">📋</div><div class="empty-t">لا يوجد برنامج</div><div class="empty-s">أكمل الإعداد لتوليد برنامجك</div></div>';renderCustomBanner();return;}
  const prog=u.program,primSp=SPORTS.find(s=>s.id===u.primarySport),suppSps=(u.supportSports||[]).map(id=>SPORTS.find(s=>s.id===id)).filter(Boolean);
  const activePlan=getPrimaryPlan();
  let h=`<div class="card" style="padding:12px;margin-bottom:10px"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px"><div style="display:flex;align-items:center;gap:8px"><span style="font-size:26px">${primSp?.ico||'🌟'}</span><div><div style="font-size:13px;font-weight:800">${primSp?.name||'لياقة عامة'}</div><div style="font-size:11px;color:var(--y)">⭐ رياضتك الأساسية</div></div></div><button onclick="deleteGeneratedProgram()" style="background:rgba(200,16,46,.12);border:1px solid rgba(200,16,46,.22);color:var(--red);border-radius:8px;padding:5px 9px;font-size:11px;cursor:pointer;font-family:inherit;flex-shrink:0">🗑 حذف</button></div>${activePlan?`<div style="background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-radius:9px;padding:8px 9px;margin-bottom:8px;font-size:11px;color:var(--b);line-height:1.7">🔵 خطتك "${escapeHtml(activePlan.name)}" هي النشطة الآن — هذا البرنامج الجاهز غير مُستخدَم حالياً، وهو معروض هنا فقط كمرجع/احتياط.</div>`:''}${suppSps.length?`<div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px">${suppSps.map(sp=>`<span style="background:rgba(200,16,46,.14);border:1px solid rgba(200,16,46,.22);border-radius:7px;padding:3px 8px;font-size:11px">${sp.ico} ${sp.name}</span>`).join('')}</div>`:''}<div class="div"></div><div style="font-size:11px;color:var(--w60);line-height:1.75"><b>${prog.splitLabel}</b><br>${prog.progression}</div><div style="margin-top:8px"><span style="font-size:11px;background:rgba(34,197,94,.16);color:var(--g);padding:3px 9px;border-radius:10px;font-weight:700">😴 ${prog.restDayCount||0} أيام راحة أسبوعياً</span></div></div>`;
  h+=renderPhaseCard('warmup')+renderPhaseCard('cooldown');
  const bgC=['#1a0508','#0a1205','#0a0a1a','#1a0f00','#100F26','#1a1500'];
  prog.schedule.forEach((day,di)=>{
    if(day.isRest){h+=`<div style="background:rgba(34,197,94,.05);border:1px dashed rgba(34,197,94,.26);border-radius:13px;margin-bottom:8px;padding:11px 13px;display:flex;align-items:center;gap:10px"><span style="font-size:19px">😴</span><div><div style="font-size:12px;font-weight:800;color:var(--g)">${day.day} — راحة</div><div style="font-size:11px;color:var(--w60);margin-top:1px">${day.focus}</div></div></div>`;return;}
    h+=`<div class="day-card" style="background:${bgC[di%6]}">
      <div class="day-hdr" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'block':'none'">
        <div><div class="day-name" style="color:${day.isSport?'var(--y)':'var(--red)'}">${day.isSport?'⭐ ':''}${day.day} — ${day.label}</div><div class="day-focus">${day.focus}</div></div>
        <div style="text-align:center"><div style="font-size:11px;color:var(--w40)">${(day.exIds||[]).length} تمرين</div><button class="btn btn-p btn-sm" style="margin-top:4px;padding:4px 10px;font-size:11px" onclick="event.stopPropagation();startDayWk(${day.weekday})">▶ ابدأ</button></div>
      </div>
      <div class="day-body">${(day.exIds||[]).map(id=>{
        const ex=EX[id];if(!ex)return'';
        const rep=ex.isTimed?`${ex.lo||30}-${ex.hi||60}ث`:ex.unit||`${ex.lo||8}-${ex.hi||12}`;
        const alts=getExerciseAlts(id,u.equipment,u.limits);
        const imgClass=ex.isTimed?'timed-ex':'';
        return`<div class="ex-list-item" onclick="showExDetail('${id}')" style="margin-bottom:7px">
          ${exVisual(id,ex.ico,imgClass)}
          <div class="ex-details">
            <div class="ex-name-ar">${ex.n}</div>
            <div class="ex-name-en">${ex.e}</div>
            <div class="ex-pills"><span class="pill pill-red">${prog.sets}×${rep}</span><span class="pill pill-b">${ex.rest}ث راحة</span></div>
          </div>
          ${ex.e?`<button onclick="event.stopPropagation();watchExDemo('${ex.e.replace(/'/g,"\\'")}')" style="background:rgba(200,16,46,.14);border:none;color:var(--red);border-radius:8px;padding:6px 9px;font-size:12px;cursor:pointer;flex-shrink:0">🎥</button>`:''}
          ${alts.length?`<button onclick="event.stopPropagation();showAlts('${id}')" style="background:rgba(59,130,246,.14);border:1px solid rgba(59,130,246,.26);color:var(--b);border-radius:8px;padding:6px 10px;font-size:11px;cursor:pointer;font-family:inherit;flex-shrink:0">بدائل</button>`:''}
        </div>`;
      }).join('')}</div>
    </div>`;
  });
  document.getElementById('my-prog-content').innerHTML=h;
  document.getElementById('copy-gen-btn').style.display='block';
  renderCustomBanner();
}

// ══════════════════════════════════════════════════════
// TRACKER
// ══════════════════════════════════════════════════════
function startTodayWorkout(){
  if(APP.activeWorkout){showPg('tracker');return;}
  const di=new Date().getDay();
  const primary=getPrimaryPlan();
  if(primary){
    const cdi=primary.parsed.days.findIndex(d=>d.dayKey===CUSTOM_DAY_KEYS[di]);
    if(cdi>-1){
      if(primary.parsed.days[cdi].isRest){toast('😴 اليوم يوم راحة — استرح جيداً!','💤');return;}
      startCustomDayWk(primary.id,cdi);return;
    }
  }else{
    // خطة معلَّمة كأساسية لكن بلا بيانات محلَّلة بعد — كانت تُتجاهَل بصمت،
    // فيبدو الأمر وكأن الخطة "لم تُحفَظ". الآن نوضّح السبب صراحةً.
    const unanalyzedPrimary=(APP.plans||[]).find(p=>p.isPrimary&&!p.parsed);
    if(unanalyzedPrimary){toast('⚠️ خطتك الأساسية تحتاج "🤖 حلّل" أولاً — سنستخدم برنامجك الجاهز مؤقتاً','⚠️');}
  }
  const prog=APP.user?.program;
  if(prog?.schedule?.length){const today=prog.schedule[di];if(today&&today.isRest){toast('😴 اليوم يوم راحة — استرح جيداً!','💤');return;}startDayWk(di);}
  else startQuickWk();
}
function startDayWk(di){const prog=APP.user?.program;if(!prog?.schedule?.[di]||prog.schedule[di].isRest||!prog.schedule[di].exIds?.length)return startQuickWk();const day=prog.schedule[di];APP.activeWorkout={id:Date.now(),name:day.focus,startTime:Date.now(),date:new Date().toISOString(),exercises:day.exIds.filter(id=>EX[id]).map(id=>{const ex=EX[id];const sets=ex.isTimed?Array.from({length:prog.sets||3},()=>({duration:ex.lo||30,remaining:null,done:false,running:false})):Array.from({length:prog.sets||3},()=>({weight:'',reps:ex.lo||10,rest:ex.rest||90,done:false}));return{id,sciId:id,name:ex.n,sets};})};save();showPg('tracker');renderTracker();startWtTimer();toast('🏋️ '+day.focus);}
function startQuickWk(){APP.activeWorkout={id:Date.now(),name:'تمرين سريع '+new Date().toLocaleDateString('ar-u-ca-gregory'),startTime:Date.now(),date:new Date().toISOString(),exercises:[]};save();renderTracker();startWtTimer();toast('🏋️ بدأ التمرين!');}
let _wtStart=null;
let _wtPausedAccum=0; // total ms accumulated while paused segments are excluded
let _wtPauseStartedAt=null; // timestamp when current pause began, null if running
function startWtTimer(){
  clearInterval(APP._wtTimer);
  _wtStart=APP.activeWorkout?.startTime||Date.now();
  _wtPausedAccum=APP.activeWorkout?.pausedMs||0;
  _wtPauseStartedAt=APP.activeWorkout?.pausedAt||null;
  updateWtTimerDisplay();
  APP._wtTimer=setInterval(updateWtTimerDisplay,1000);
}
function updateWtTimerDisplay(){
  const el=document.getElementById('aw-timer');
  if(!el)return;
  let elapsedMs=Date.now()-_wtStart-_wtPausedAccum;
  if(_wtPauseStartedAt)elapsedMs-=(Date.now()-_wtPauseStartedAt);
  const s=Math.max(0,Math.floor(elapsedMs/1000));
  el.textContent=pad(Math.floor(s/60))+':'+pad(s%60);
}
function toggleWorkoutPause(){
  const aw=APP.activeWorkout;if(!aw)return;
  const btn=document.getElementById('aw-pause-btn');
  const lbl=document.getElementById('aw-status-lbl');
  if(_wtPauseStartedAt){
    // Currently paused -> resume
    _wtPausedAccum+=(Date.now()-_wtPauseStartedAt);
    _wtPauseStartedAt=null;
    aw.pausedMs=_wtPausedAccum;
    aw.pausedAt=null;
    save();
    clearInterval(APP._wtTimer);
    APP._wtTimer=setInterval(updateWtTimerDisplay,1000);
    if(btn){btn.innerHTML='⏸ إيقاف مؤقت للتمرين';btn.style.background='rgba(255,255,255,.14)';}
    if(lbl)lbl.textContent='🏋️ جاري التمرين';
    toast('▶ استُؤنف التمرين');
  } else {
    // Currently running -> pause
    _wtPauseStartedAt=Date.now();
    aw.pausedAt=_wtPauseStartedAt;
    aw.pausedMs=_wtPausedAccum;
    save();
    clearInterval(APP._wtTimer);
    if(btn){btn.innerHTML='▶ استئناف التمرين';btn.style.background='rgba(34,197,94,.25)';}
    if(lbl)lbl.textContent='⏸ التمرين متوقف مؤقتاً';
    toast('⏸ تم إيقاف التمرين مؤقتاً');
  }
}
const pad=n=>String(n).padStart(2,'0');
function renderTracker(){
  const aw=APP.activeWorkout;
  document.getElementById('active-wk').style.display=aw?'block':'none';
  document.getElementById('no-wk').style.display=aw?'none':'block';
  document.getElementById('tracker-date').textContent=new Date().toLocaleDateString('ar-u-ca-gregory');
  if(aw){
    document.getElementById('aw-name').textContent=aw.name;
    renderTrackerExs();
    startWtTimer();
    const btn=document.getElementById('aw-pause-btn');
    const lbl=document.getElementById('aw-status-lbl');
    if(aw.pausedAt){
      if(btn){btn.innerHTML='▶ استئناف التمرين';btn.style.background='rgba(34,197,94,.25)';}
      if(lbl)lbl.textContent='⏸ التمرين متوقف مؤقتاً';
    } else {
      if(btn){btn.innerHTML='⏸ إيقاف مؤقت للتمرين';btn.style.background='rgba(255,255,255,.14)';}
      if(lbl)lbl.textContent='🏋️ جاري التمرين';
    }
  }
  renderWkHist();
}
// ══════════════════════════════════════════════════════
// وضع التركيز — شاشة كاملة لتمرين واحد في كل مرة (اسم، صورة، طريقة الأداء،
// وزن/تكرار أو مؤقت، وزر إنجاز)، بدل القائمة الطويلة. تعمل فوق نفس بيانات
// APP.activeWorkout — أي تغيير هنا يظهر فوراً في القائمة العادية والعكس، فلا
// حاجة لأي نموذج بيانات منفصل ولا خطر تعارض بين الشاشتين.
// ══════════════════════════════════════════════════════
let FOCUS_STATE=null;
function openFocusMode(){
  const aw=APP.activeWorkout;
  if(!aw||!aw.exercises.length){toast('أضف تمارين أولاً','⚠️');return;}
  let exIdx=aw.exercises.findIndex(ex=>ex.sets.some(s=>!s.done));
  if(exIdx===-1)exIdx=0;
  let setIdx=aw.exercises[exIdx].sets.findIndex(s=>!s.done);
  if(setIdx===-1)setIdx=0;
  FOCUS_STATE={exIdx,setIdx,restTicker:null};
  showMo('mo-focus');
  renderFocusMode();
  FOCUS_STATE.restTicker=setInterval(updateFocusRestDisplay,1000);
}
function closeFocusMode(){
  if(FOCUS_STATE?.restTicker)clearInterval(FOCUS_STATE.restTicker);
  FOCUS_STATE=null;
  hideMo('mo-focus');
  renderTrackerExs();
}
function focusNav(dir){
  const aw=APP.activeWorkout;if(!aw||!FOCUS_STATE)return;
  let idx=FOCUS_STATE.exIdx+dir;
  if(idx<0)idx=aw.exercises.length-1;
  if(idx>=aw.exercises.length)idx=0;
  FOCUS_STATE.exIdx=idx;
  const nextEx=aw.exercises[idx];
  const firstUndone=nextEx.sets.findIndex(s=>!s.done);
  FOCUS_STATE.setIdx=firstUndone===-1?0:firstUndone;
  renderFocusMode();
}
function focusMarkDone(ei,si){
  const aw=APP.activeWorkout;if(!aw)return;
  const s=aw.exercises[ei].sets[si];
  s.done=!s.done;
  save();
  if(s.done){
    const restLen=s.rest||(EX[aw.exercises[ei].sciId||aw.exercises[ei].id]?.rest)||90;
    startRestTimer(restLen);
    vibrateSafe(80);
    if(si<aw.exercises[ei].sets.length-1){FOCUS_STATE.setIdx=si+1;}
    else{focusNav(1);renderTrackerExs();return;}
  }
  renderFocusMode();
  renderTrackerExs();
}
function renderFocusSetControls(ei,si,ex,d,isTimed){
  const s=ex.sets[si];
  if(isTimed){
    const dv=s.remaining??s.duration??30;
    return`<div style="text-align:center;font-size:46px;font-weight:900;font-variant-numeric:tabular-nums;margin-bottom:14px;color:${s.running?'var(--sky)':'#fff'}" id="tex-${ei}-${si}">${pad(Math.floor(dv/60))}:${pad(dv%60)}</div>
      <div style="display:flex;gap:8px">
        ${s.done?`<div style="flex:1;text-align:center;color:var(--g);font-weight:800;padding:13px">✅ أُنجزت</div>`
          :s.running
            ?`<button onclick="stopTimedSet(${ei},${si});renderFocusMode()" style="flex:1;background:var(--w8);border:1px solid rgba(var(--wa),.1);color:var(--w);border-radius:12px;padding:13px;font-size:14px;font-weight:800;cursor:pointer;font-family:inherit">⏸ إيقاف</button>`
            :`<button onclick="startTimedSet(${ei},${si});renderFocusMode()" style="flex:1;background:linear-gradient(135deg,var(--rd),var(--red));border:none;color:var(--w);border-radius:12px;padding:13px;font-size:14px;font-weight:800;cursor:pointer;font-family:inherit">▶ ابدأ</button>`}
      </div>`;
  }
  return`<div style="display:flex;gap:10px;margin-bottom:14px">
      <div style="flex:1;text-align:center">
        <input type="number" value="${s.weight||''}" placeholder="0" onchange="updSet(${ei},${si},'weight',this.value)" style="width:100%;background:var(--b2);border:1px solid rgba(var(--wa),.1);border-radius:12px;padding:14px 8px;font-size:26px;font-weight:900;color:var(--w);text-align:center;font-family:inherit">
        <div style="font-size:11px;color:var(--w40);margin-top:5px">كغ</div>
      </div>
      <div style="flex:1;text-align:center">
        <input type="number" value="${s.reps||''}" placeholder="0" onchange="updSet(${ei},${si},'reps',this.value)" style="width:100%;background:var(--b2);border:1px solid rgba(var(--wa),.1);border-radius:12px;padding:14px 8px;font-size:26px;font-weight:900;color:var(--w);text-align:center;font-family:inherit">
        <div style="font-size:11px;color:var(--w40);margin-top:5px">تكرار</div>
      </div>
    </div>
    <button onclick="focusMarkDone(${ei},${si})" style="width:100%;background:${s.done?'rgba(34,197,94,.16)':'linear-gradient(135deg,var(--rd),var(--red))'};border:${s.done?'1px solid rgba(34,197,94,.3)':'none'};color:${s.done?'var(--g)':'#fff'};border-radius:12px;padding:14px;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit">${s.done?'✅ أُنجزت — اضغط للتراجع':'✓ تم — التالي'}</button>`;
}
function renderFocusMode(){
  const aw=APP.activeWorkout;
  if(!aw||!FOCUS_STATE){closeFocusMode();return;}
  const{exIdx,setIdx}=FOCUS_STATE;
  const ex=aw.exercises[exIdx];
  if(!ex){closeFocusMode();return;}
  const d=EX[ex.sciId||ex.id]||{ico:'🏋️',n:ex.name||'تمرين',mu:'',rpe:7,isTimed:false};
  const engName=d.e||ex.nameEn||'';
  const totalSets=ex.sets.length;
  const safeSetIdx=Math.min(setIdx,totalSets-1);
  const isTimed=ex.sets[safeSetIdx]?.duration!==undefined;
  const doneCount=ex.sets.filter(x=>x.done).length;
  const phase=ex.phase||'main';
  const phaseTag=phase!=='main'?PHASE_LABELS[phase]:null;
  document.getElementById('focus-body').innerHTML=`
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <button onclick="closeFocusMode()" style="background:var(--w8);border:none;color:var(--w60);border-radius:10px;width:36px;height:36px;font-size:16px;cursor:pointer;flex-shrink:0">✕</button>
      <div style="font-size:11px;color:var(--w40);font-weight:700">تمرين ${exIdx+1} من ${aw.exercises.length}</div>
      <div style="width:36px"></div>
    </div>
    ${phaseTag?`<div style="text-align:center;margin-bottom:8px"><span style="font-size:11px;font-weight:800;color:${phaseTag.color};background:rgba(var(--wa),.05);padding:4px 12px;border-radius:20px">${phaseTag.label}</span></div>`:''}
    <div style="margin-bottom:14px">${exVisual(ex.sciId||ex.id,d.ico,'focus-img',ex.name||ex.nameEn)}</div>
    <div style="text-align:center;margin-bottom:6px">
      <div style="font-size:19px;font-weight:900">${d.n||ex.name}${ex.isPrimary?' <span style="color:var(--y);font-size:11px">⭐</span>':''}</div>
      ${engName?`<div style="font-size:12px;color:var(--w40);margin-top:2px" dir="ltr">${engName}</div>`:''}
    </div>
    ${engName?`<div style="text-align:center;margin-bottom:14px"><button onclick="watchExDemo('${engName.replace(/'/g,"\\'")}')" style="background:rgba(200,16,46,.14);border:1px solid rgba(200,16,46,.24);color:var(--red);border-radius:20px;padding:7px 16px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">🎥 شاهد الأداء الصحيح</button> <button onclick="pickExImg(this.dataset.k)" data-k="${escapeHtml(engName)}" style="background:var(--mint-glow);border:1px solid var(--w12);color:var(--mint-lt);border-radius:20px;padding:7px 16px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;margin-inline-start:6px">📷 صورتي</button></div>`:''}
    <div style="background:var(--b3);border-radius:16px;padding:16px;margin-bottom:14px">
      <div style="text-align:center;font-size:11px;color:var(--w40);margin-bottom:10px;font-weight:700">المجموعة ${safeSetIdx+1} من ${totalSets}${doneCount?` · أُنجز ${doneCount}`:''}</div>
      ${renderFocusSetControls(exIdx,safeSetIdx,ex,d,isTimed)}
    </div>
    ${d.how&&d.how.length?`<div style="background:rgba(59,130,246,.06);border:1px solid rgba(59,130,246,.16);border-radius:13px;padding:12px;margin-bottom:14px">
      <div style="font-size:11px;font-weight:800;color:var(--b);margin-bottom:7px">📋 كيف تؤديه</div>
      <div style="font-size:12px;color:var(--w70);line-height:1.85">${d.how.map((c,i)=>`${i+1}. ${c}`).join('<br>')}</div>
      ${d.err?`<div style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(var(--wa),.06);font-size:11px;color:var(--y)">⚠️ خطأ شائع: ${d.err}</div>`:''}
    </div>`:(ex.notes?`<div style="background:rgba(var(--wa),.04);border-radius:13px;padding:12px;margin-bottom:14px;font-size:12px;color:var(--w70);line-height:1.8">${ex.notes}</div>`:'')}
    <div id="focus-rest-display"></div>
    <div style="flex:1"></div>
    <div style="display:flex;gap:8px;margin-top:10px">
      <button onclick="focusNav(-1)" style="flex:1;background:var(--w8);border:1px solid rgba(var(--wa),.1);color:var(--w);border-radius:12px;padding:13px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">‹ السابق</button>
      <button onclick="focusNav(1)" style="flex:1;background:var(--w8);border:1px solid rgba(var(--wa),.1);color:var(--w);border-radius:12px;padding:13px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit">التالي ›</button>
    </div>`;
  updateFocusRestDisplay();
}
function updateFocusRestDisplay(){
  const el=document.getElementById('focus-rest-display');
  if(!el)return;
  if(APP._restEndAt){
    const remaining=Math.max(0,Math.round((APP._restEndAt-Date.now())/1000));
    if(remaining<=0){el.innerHTML='';return;}
    el.innerHTML=`<div style="text-align:center;background:rgba(255,176,32,.08);border:1px solid rgba(255,176,32,.22);border-radius:13px;padding:10px;margin-bottom:14px"><div style="font-size:11px;color:var(--y);font-weight:700;margin-bottom:3px">⏸ راحة</div><div style="font-size:24px;font-weight:900;color:var(--y);font-variant-numeric:tabular-nums">${pad(Math.floor(remaining/60))}:${pad(remaining%60)}</div></div>`;
  }else{
    el.innerHTML='';
  }
}
// Exercises using this equipment need an external, quantifiable weight —
// bodyweight/band/pullup-bar-only movements don't, since "how much can you
// lift" doesn't map cleanly onto them.
const WEIGHTED_EQUIPMENT=['barbell','dumbbells','kettlebell','machines','cables'];
function isWeightedExercise(d){return !!(d.eq&&d.eq.some(e=>WEIGHTED_EQUIPMENT.includes(e)));}
function hasLoggedWeightBefore(sciId){
  if(!sciId)return false;
  return APP.workouts.some(w=>(w.exercises||[]).some(ex=>(ex.sciId===sciId)&&(ex.sets||[]).some(s=>s.done&&parseFloat(s.weight)>0)));
}
// آخر أداء فعلي لهذا التمرين — يظهر كمرجع سريع ("آخر مرة: X كغ") بدل أن يبدأ
// المستخدم كل جلسة من فراغ ويحاول يتذكر الوزن الذي استخدمه سابقاً.
function getLastPerformance(sciId){
  if(!sciId)return null;
  for(let i=APP.workouts.length-1;i>=0;i--){
    const ex=(APP.workouts[i].exercises||[]).find(e=>e.sciId===sciId);
    if(!ex)continue;
    const doneSets=(ex.sets||[]).filter(s=>s.done&&parseFloat(s.weight)>0);
    if(doneSets.length)return doneSets[doneSets.length-1];
  }
  return null;
}
function suggestedReps(d){return d.lo&&d.hi?Math.round((d.lo+d.hi)/2):(d.lo||10);}

function renderTrackerExs(){
  const aw=APP.activeWorkout;if(!aw)return;
  const wkHasPhaseTags=aw.exercises.some(e=>e.phase&&e.phase!=='main');
  const exsHtml=aw.exercises.map((ex,ei)=>{
    const d=EX[ex.sciId||ex.id]||{ico:'🏋️',n:ex.name||'تمرين',mu:'',rpe:7,isTimed:false};
    const alts=(d.alts||[]).filter(id=>EX[id]).slice(0,3);
    const knownEx=!!(ex.sciId||ex.id);
    const isTimed=d.isTimed||ex.isTimed||false;
    const borderStyle=ex.isPrimary?'border-color:rgba(245,158,11,.4)':'';
    const imgClass=(ex.isPrimary?'primary-ex ':'')+(isTimed?'timed-ex':'');
    // اسم إنجليزي: من قاعدة البيانات إن كان التمرين معروفاً، وإلا من nameEn الذي
    // يوفره تحليل الذكاء الاصطناعي للبرامج المخصصة — كان يُفقَد سابقاً هنا فقط.
    const engName=d.e||ex.nameEn||'';
    // عنوان قسم (إحماء/أساسي/تبريد) — يظهر فقط للخطط التي تحمل تصنيف phase
    // فعلياً (خطط الذكاء الاصطناعي)، وعند تغيّر المرحلة عن التمرين السابق.
    const curPhase=ex.phase||'main';
    const prevPhase=ei>0?(aw.exercises[ei-1].phase||'main'):null;
    const hasPhaseTags=aw.exercises.some(e=>e.phase&&e.phase!=='main');
    const phaseHeader=(hasPhaseTags&&curPhase!==prevPhase)?`<div style="display:flex;align-items:center;gap:8px;margin:${ei>0?'20px':'0'} 0 11px;padding-bottom:7px;border-bottom:1px solid rgba(var(--wa),.09)">
      <span style="font-size:13px;font-weight:800;color:${PHASE_LABELS[curPhase].color}">${PHASE_LABELS[curPhase].label}</span>
      <span style="font-size:11px;color:var(--w40)">${PHASE_LABELS[curPhase].desc}</span>
    </div>`:'';
    const header=`<div style="display:flex;align-items:center;gap:11px;margin-bottom:11px">
      ${exVisual(ex.sciId||ex.id,d.ico,imgClass,ex.name||ex.nameEn)}
      <div style="flex:1">
        <div style="font-size:13px;font-weight:800">${d.n||ex.name}</div>
        ${engName?`<div style="font-size:11px;color:var(--w40);margin-top:1px" dir="ltr">${engName}</div>`:''}
        <div style="font-size:11px;color:var(--w40);margin-top:1px">${d.mu||''}</div>
        <div class="ex-pills" style="margin-top:5px">
          ${ex.isPrimary?'<span class="pill pill-y">⭐ أساسي</span>':''}
          ${isTimed?'<span class="pill pill-b">⏱ مؤقت</span>':''}
        </div>
      </div>
      ${engName?`<button onclick="watchExDemo('${engName.replace(/'/g,"\\'")}')" title="شاهد الأداء الصحيح" style="background:rgba(200,16,46,.14);border:none;color:var(--red);border-radius:8px;padding:6px 9px;font-size:13px;cursor:pointer;flex-shrink:0">🎥</button>`:''}
      ${knownEx?`<button onclick="showExDetail('${ex.sciId||ex.id}')" style="background:var(--w8);border:none;color:var(--w60);border-radius:8px;padding:6px 10px;font-size:11px;cursor:pointer;font-family:inherit;flex-shrink:0">تفاصيل</button>`:''}
      <button onclick="rmEx(${ei})" style="background:rgba(200,16,46,.14);border:none;color:var(--red);border-radius:8px;padding:6px 9px;font-size:13px;cursor:pointer;flex-shrink:0">🗑</button>
    </div>`;
    // ── Always-visible beginner guidance: how to perform + common mistake ──
    // (This used to be hidden behind a "تفاصيل" tap — now it's right in the
    // card, since someone who doesn't know the exercise needs it immediately,
    // not after an extra step.)
    const guidance=(d.how&&d.how.length)||d.err?`<div style="background:rgba(63,193,255,.06);border:1px solid rgba(63,193,255,.16);border-radius:12px;padding:10px 12px;margin-bottom:10px">
      ${d.how&&d.how.length?`<div style="font-size:11px;font-weight:800;color:var(--b);margin-bottom:5px">📋 كيف تؤديه</div><div style="font-size:11px;color:var(--w60);line-height:1.85;margin-bottom:${d.err?'8px':'0'}">${d.how.map((c,i)=>`${i+1}. ${c}`).join('<br>')}</div>`:''}
      ${d.err?`<div style="font-size:11px;font-weight:800;color:var(--y);margin-bottom:3px">⚠️ تجنب</div><div style="font-size:11px;color:var(--w60);line-height:1.6">${d.err}</div>`:''}
    </div>`:'';
    if(isTimed){
      const sets=ex.sets.map((s,si)=>{
        const totalSecs=s.duration||d.lo||30;
        // Show remaining time if the timer has been started (running, or was
        // running and got a value via the last tick/visibility resync);
        // otherwise show the full configured duration since it hasn't begun.
        const displaySecs=(s.remaining!=null)?s.remaining:totalSecs;
        const tidStr='tex-'+ei+'-'+si;
        return`<div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid rgba(var(--wa),.05)">
          <div style="width:22px;text-align:center;font-size:11px;color:var(--w40);font-weight:700">${si+1}</div>
          <div style="flex:1;text-align:center">
            <div id="${tidStr}" style="font-size:28px;font-weight:900;color:${s.done?'var(--g)':'var(--red)'};font-variant-numeric:tabular-nums;line-height:1">${s.done?'✓':pad(Math.floor(displaySecs/60))+':'+pad(displaySecs%60)}</div>
            <div style="font-size:11px;color:var(--w40);margin-top:1px">${totalSecs} ثانية</div>
          </div>
          <div style="display:flex;gap:5px;align-items:center">
            <button onclick="adjTimedSet(${ei},${si},-5)" style="background:var(--b4);border:none;color:var(--w60);border-radius:6px;padding:5px 8px;font-size:11px;cursor:pointer;font-family:inherit">-5s</button>
            <button onclick="adjTimedSet(${ei},${si},5)" style="background:var(--b4);border:none;color:var(--w60);border-radius:6px;padding:5px 8px;font-size:11px;cursor:pointer;font-family:inherit">+5s</button>
            ${s.running
              ? `<button onclick="stopTimedSet(${ei},${si})" style="background:var(--y);border:none;color:#000;border-radius:6px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">إيقاف ⏸</button>`
              : s.done
                ? `<div class="set-done ok" style="width:32px;height:32px;border-radius:6px">✓</div>`
                : `<button onclick="startTimedSet(${ei},${si})" style="background:var(--red);border:none;color:var(--w);border-radius:6px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">▶ ابدأ</button>`
            }
          </div>
        </div>`;
      }).join('');
      return`${phaseHeader}<div class="card" style="margin-bottom:10px;border-radius:16px;${borderStyle}">
        ${header}${guidance}${sets}
        <div style="display:flex;gap:6px;margin-top:9px">
          <button class="btn btn-g btn-sm" style="flex:1;border-radius:10px" onclick="addTimedSet(${ei})">+ جولة</button>
          ${alts.length?`<button class="btn btn-g btn-sm" style="flex:1;border-radius:10px" onclick="showAlts('${ex.sciId||ex.id}')">بدائل 🔄</button>`:''}
        </div>
      </div>`;
    }
    // ── Suggested rep range banner (always shown for non-timed exercises) ──
    const repBanner=d.lo&&d.hi?`<div style="display:flex;align-items:center;gap:7px;background:rgba(142,124,255,.07);border:1px solid rgba(142,124,255,.18);border-radius:10px;padding:8px 11px;margin-bottom:10px"><span style="font-size:14px">🎯</span><span style="font-size:11px;color:var(--w60)">المقترح: <b style="color:var(--g)">${d.lo}-${d.hi} تكرار</b>${d.rpe?` · شدة RPE ${d.rpe}/10`:''}</span></div>`:'';
    // ── First-time capable-weight question ──
    const weighted=isWeightedExercise(d);
    const alreadyHasWeight=ex.sets.some(s=>parseFloat(s.weight)>0);
    const loggedBefore=hasLoggedWeightBefore(ex.sciId||ex.id);
    const showWeightPrompt=weighted&&!alreadyHasWeight&&!loggedBefore;
    const weightPrompt=showWeightPrompt?`<div style="background:rgba(255,176,32,.08);border:1px solid rgba(255,176,32,.22);border-radius:12px;padding:11px;margin-bottom:10px">
      <div style="font-size:11px;font-weight:800;color:var(--y);margin-bottom:7px">🏋️ كم كغ تستطيع رفعه في هذا التمرين؟</div>
      <div style="display:flex;gap:7px">
        <input type="number" class="set-inp" id="wprompt-${ei}" placeholder="مثال: 20" style="flex:1">
        <button onclick="applyCapableWeight(${ei})" style="background:linear-gradient(135deg,var(--rd),var(--red));border:none;color:var(--w);border-radius:8px;padding:0 16px;font-size:11px;font-weight:800;cursor:pointer;font-family:inherit;white-space:nowrap">استخدم هذا الوزن</button>
      </div>
      <div style="font-size:11px;color:var(--w40);margin-top:6px">إن لم تكن متأكداً، ابدأ بوزن خفيف تستطيع التحكم به بسهولة — يمكنك تعديله في أي مجموعة لاحقاً</div>
    </div>`:'';
    // ── Last-session reference: shows what you actually lifted last time,
    // with a one-tap fill so you're not retyping the same numbers mid-workout
    // for every set while your hands are full/sweaty. ──
    const lastPerf=knownEx?getLastPerformance(ex.sciId||ex.id):null;
    const lastPerfBanner=(lastPerf&&!alreadyHasWeight)?`<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;background:rgba(63,193,255,.07);border:1px solid rgba(63,193,255,.18);border-radius:10px;padding:8px 11px;margin-bottom:10px">
      <span style="font-size:11px;color:var(--w60)">📊 آخر مرة: <b style="color:var(--b)">${lastPerf.weight} كغ × ${lastPerf.reps}</b></span>
      <button onclick="fillLastPerf(${ei})" style="background:rgba(63,193,255,.16);border:none;color:var(--b);border-radius:7px;padding:5px 10px;font-size:11px;font-weight:800;cursor:pointer;font-family:inherit;white-space:nowrap">⚡ املأ الكل</button>
    </div>`:'';
    return`${phaseHeader}<div class="card" style="margin-bottom:10px;border-radius:16px;${borderStyle}">
      ${header}${guidance}${repBanner}${weightPrompt}${lastPerfBanner}
      <div class="set-hdrs"><div class="set-hdr">#</div><div class="set-hdr">الوزن كغ</div><div class="set-hdr">التكرار</div><div class="set-hdr">الراحة</div><div class="set-hdr"></div></div>
      ${ex.sets.map((s,si)=>`<div class="set-row">
        <div class="set-num">${si+1}</div>
        <input type="number" class="set-inp" value="${s.weight||''}" placeholder="${lastPerf?lastPerf.weight:'كغ'}" onchange="updSet(${ei},${si},'weight',this.value)">
        <input type="number" class="set-inp" value="${s.reps||suggestedReps(d)}" placeholder="تكرار" onchange="updSet(${ei},${si},'reps',this.value)">
        <select class="set-inp" onchange="updSet(${ei},${si},'rest',this.value)">
          <option value="45" ${s.rest==45?'selected':''}>45ث</option>
          <option value="60" ${s.rest==60?'selected':''}>1د</option>
          <option value="90" ${s.rest==90?'selected':''}>1.5د</option>
          <option value="120" ${s.rest==120?'selected':''}>2د</option>
          <option value="180" ${s.rest==180?'selected':''}>3د</option>
        </select>
        <div class="set-done ${s.done?'ok':''}" onclick="toggleSet(${ei},${si})">${s.done?'✓':'○'}</div>
      </div>`).join('')}
      <div style="display:flex;gap:6px;margin-top:9px">
        <button class="btn btn-g btn-sm" style="flex:1;border-radius:10px" onclick="addSet(${ei})">+ مجموعة</button>
        ${alts.length?`<button class="btn btn-g btn-sm" style="flex:1;border-radius:10px" onclick="showAlts('${ex.sciId||ex.id}')">بدائل 🔄</button>`:''}
      </div>
    </div>`;
  }).join('')||'<div style="text-align:center;color:var(--w40);padding:14px;font-size:12px">أضف تمارين للبدء</div>';
  // خطط الذكاء الاصطناعي تُظهر إحماء/تبريد بين التمارين نفسها (phaseHeader
  // أعلاه). البرامج الجاهزة (بدون تصنيف لكل تمرين) تحصل بدلاً من ذلك على
  // بطاقة إحماء/تبريد عامة من محتوى Prehab الجاهز، بدل ألا يظهر لها شيء إطلاقاً.
  const showGenericPhaseCards=!wkHasPhaseTags&&aw.exercises.length>0;
  document.getElementById('tracker-exs').innerHTML=
    (showGenericPhaseCards?renderPhaseCard('warmup'):'')+
    exsHtml+
    (showGenericPhaseCards?renderPhaseCard('cooldown'):'');
}
function applyCapableWeight(ei){
  const aw=APP.activeWorkout;if(!aw)return;
  const inp=document.getElementById('wprompt-'+ei);
  const val=parseFloat(inp?.value);
  if(!val||val<=0){toast('أدخل وزناً صحيحاً أولاً','⚠️');return;}
  aw.exercises[ei].sets.forEach(s=>{s.weight=val;});
  save();renderTrackerExs();toast('✓ تم تطبيق الوزن على كل المجموعات');
}
function fillLastPerf(ei){
  const aw=APP.activeWorkout;if(!aw)return;
  const ex=aw.exercises[ei];
  const lastPerf=getLastPerformance(ex.sciId||ex.id);
  if(!lastPerf)return;
  ex.sets.forEach(s=>{if(!s.done){s.weight=lastPerf.weight;s.reps=lastPerf.reps;}});
  save();renderTrackerExs();toast('⚡ تم ملء المجموعات بآخر أداء');
}

// ── Timed exercise set functions ──
function vibrateSafe(pattern){try{if(navigator.vibrate)navigator.vibrate(pattern);}catch(e){}}
function startTimedSet(ei,si){
  const aw=APP.activeWorkout;if(!aw)return;
  const ex=aw.exercises[ei];
  const s=ex.sets[si];
  if(s.running)return;
  // Stop any other running timer first
  aw.exercises.forEach((e,xi)=>e.sets.forEach((st,yi)=>{if(st.running)stopTimedSet(xi,yi);}));
  const d=EX[ex.sciId||ex.id]||{};
  const total=s.duration||(d.lo||30);
  const remainingNow=s.remaining||total;
  s.running=true;
  // Store the real-world END TIMESTAMP rather than just counting down ticks.
  // This makes the timer immune to setInterval throttling when the phone
  // screen locks or the tab is backgrounded — whenever a tick DOES fire
  // (or the page becomes visible again), we recompute remaining time from
  // Date.now(), so it's always accurate regardless of how many ticks were
  // missed while backgrounded.
  s.endAt=Date.now()+remainingNow*1000;
  save();renderTrackerExs();
  const tid='tex-'+ei+'-'+si;
  const tick=()=>{
    const cur=APP.activeWorkout?.exercises?.[ei]?.sets?.[si];
    if(!cur||!cur.running){clearInterval(APP._timedInterval);return;}
    const remaining=Math.max(0,Math.round((cur.endAt-Date.now())/1000));
    cur.remaining=remaining;
    const el=document.getElementById(tid);
    if(el)el.textContent=pad(Math.floor(remaining/60))+':'+pad(remaining%60);
    if(remaining<=0){
      clearInterval(APP._timedInterval);
      cur.done=true;cur.running=false;cur.endAt=null;
      save();renderTrackerExs();
      startRestTimer(EX[ex.sciId||ex.id]?.rest||60);
      vibrateSafe([200,80,200]);
      playRestBell();
      toast('✅ انتهى الوقت!','⏰');
    }
  };
  APP._timedInterval=setInterval(tick,1000);
  tick(); // sync immediately instead of waiting a full second for the first paint
}
function stopTimedSet(ei,si){
  clearInterval(APP._timedInterval);
  const s=APP.activeWorkout?.exercises?.[ei]?.sets?.[si];
  if(s){
    if(s.endAt)s.remaining=Math.max(0,Math.round((s.endAt-Date.now())/1000));
    s.running=false;s.endAt=null;
  }
  save();renderTrackerExs();
}
function adjTimedSet(ei,si,delta){
  const s=APP.activeWorkout?.exercises?.[ei]?.sets?.[si];
  if(!s)return;
  const d=EX[APP.activeWorkout.exercises[ei].sciId||APP.activeWorkout.exercises[ei].id]||{};
  const base=s.duration||(d.lo||30);
  s.duration=Math.max(5,base+delta);
  s.remaining=s.duration;
  s.done=false;s.running=false;s.endAt=null;
  save();renderTrackerExs();
}
function addTimedSet(ei){
  const aw=APP.activeWorkout;if(!aw)return;
  const ex=aw.exercises[ei];
  const d=EX[ex.sciId||ex.id]||{};
  const last=ex.sets[ex.sets.length-1];
  ex.sets.push({duration:last?.duration||(d.lo||30),remaining:null,done:false,running:false});
  save();renderTrackerExs();
}
function updSet(ei,si,f,v){if(!APP.activeWorkout)return;APP.activeWorkout.exercises[ei].sets[si][f]=Math.min(Math.max(parseFloat(v)||0,0),f==='weight'?1000:999);save();}
function addSet(ei){if(!APP.activeWorkout)return;APP.activeWorkout.exercises[ei].sets.push({weight:'',reps:10,rest:60,done:false});save();renderTrackerExs();}
function rmEx(ei){if(!APP.activeWorkout)return;APP.activeWorkout.exercises.splice(ei,1);save();renderTrackerExs();}
function toggleSet(ei,si){if(!APP.activeWorkout)return;if(APP.activeWorkout.pausedAt){toast('⏸ استأنف التمرين أولاً','⚠️');return;}const s=APP.activeWorkout.exercises[ei].sets[si];s.done=!s.done;if(s.done)startRestTimer(s.rest||60);save();renderTrackerExs();}
function addExToWorkout(id){if(!APP.activeWorkout)startQuickWk();const ex=EX[id];if(!ex)return;const sets=ex.isTimed?[{duration:ex.lo||30,remaining:null,done:false,running:false}]:[{weight:'',reps:ex.lo||10,rest:ex.rest||90,done:false}];APP.activeWorkout.exercises.push({id,sciId:id,name:ex.n,sets});save();renderTrackerExs();toast('✓ تمت الإضافة');}
function filterAddEx(q){const list=Object.entries(EX).filter(([id,ex])=>!q||ex.n.includes(q)||ex.e.toLowerCase().includes(q.toLowerCase())||ex.mu.includes(q));document.getElementById('add-ex-list').innerHTML=list.map(([id,ex])=>`<div class="ex-list-item" onclick="addExToWorkout('${id}');hideMo('mo-add-ex')">${exVisual(id,ex.ico,ex.isTimed?'timed-ex':'')}<div class="ex-details"><div class="ex-name-ar">${ex.n}</div><div class="ex-name-en">${ex.e} · ${ex.mu}</div></div><span class="pill ${ex.lv==='beg'?'pill-g':ex.lv==='int'?'pill-y':'pill-red'}" style="flex-shrink:0">${ex.lv==='beg'?'مبتدئ':ex.lv==='int'?'متوسط':'متقدم'}</span></div>`).join('');}
function startRestTimer(s){
  clearInterval(APP._restTimer);
  APP._restEndAt=Date.now()+s*1000;
  document.getElementById('rest-box').style.display='block';
  const tick=()=>{
    const remaining=Math.max(0,Math.round((APP._restEndAt-Date.now())/1000));
    APP._restSecs=remaining;
    updRest();
    if(remaining<=0){
      clearInterval(APP._restTimer);
      document.getElementById('rest-box').style.display='none';
      vibrateSafe(150);
      playRestBell();
      toast('⏰ انتهت الراحة!');
    }
  };
  APP._restTimer=setInterval(tick,1000);
  tick();
}
// جرس نهاية الراحة — نغمتان مُصنَّعتان مباشرة بالمتصفح (Web Audio API) فلا
// حاجة لملف صوتي خارجي، ويعمل حتى بلا اتصال إنترنت.
function playRestBell(){
  try{
    const ctx=new(window.AudioContext||window.webkitAudioContext)();
    const now=ctx.currentTime;
    [[880,0],[1318.5,0.16]].forEach(([freq,delay])=>{
      const osc=ctx.createOscillator(),gain=ctx.createGain();
      osc.type='sine';osc.frequency.value=freq;
      gain.gain.setValueAtTime(0.0001,now+delay);
      gain.gain.exponentialRampToValueAtTime(0.35,now+delay+0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001,now+delay+0.9);
      osc.connect(gain);gain.connect(ctx.destination);
      osc.start(now+delay);osc.stop(now+delay+0.9);
    });
    setTimeout(()=>ctx.close().catch(()=>{}),1300);
  }catch(e){ /* الصوت غير متاح على هذا الجهاز — الاهتزاز والتنبيه المرئي يبقيان كافيين */ }
}
function updRest(){const el=document.getElementById('rest-num');if(el)el.textContent=pad(Math.floor(APP._restSecs/60))+':'+pad(APP._restSecs%60);}
function skipRest(){clearInterval(APP._restTimer);APP._restEndAt=null;document.getElementById('rest-box').style.display='none';}
function adjRest(d){
  APP._restSecs=Math.max(0,APP._restSecs+d);
  APP._restEndAt=Date.now()+APP._restSecs*1000;
  updRest();
}
function finishWorkout(){
  if(!APP.activeWorkout)return;clearInterval(APP._wtTimer);
  let pausedMs=APP.activeWorkout.pausedMs||0;
  if(APP.activeWorkout.pausedAt)pausedMs+=(Date.now()-APP.activeWorkout.pausedAt);
  const dur=Math.max(0,Math.floor((Date.now()-APP.activeWorkout.startTime-pausedMs)/60000));
  let sets=0,vol=0;APP.activeWorkout.exercises.forEach(ex=>ex.sets.filter(s=>s.done).forEach(s=>{sets++;vol+=(parseFloat(s.weight)||0)*(parseInt(s.reps)||0);}));
  const bw=parseFloat((APP.weights.length?APP.weights[APP.weights.length-1].value:0)||(APP.user&&APP.user.weight))||70,met=Math.min(7,Math.max(3.5,3.5+3*(sets/Math.max(1,dur)))),cals=Math.round(met*bw*(dur/60));
  const w={...APP.activeWorkout,duration:dur,totalSets:sets,totalVolume:Math.round(vol),calories:cals,endTime:Date.now()};
  delete w.pausedMs;delete w.pausedAt;
  APP.workouts.push(w);APP.activeWorkout=null;_wtPauseStartedAt=null;_wtPausedAccum=0;save();
  document.getElementById('wk-sum-b').innerHTML=`<div style="text-align:center;margin-bottom:15px"><div style="font-size:48px;margin-bottom:6px">🏆</div><div style="font-size:17px;font-weight:900">${w.name}</div></div><div class="sg" style="margin-bottom:12px"><div class="sc r"><div class="sc-l">المدة</div><div class="sc-v">${dur}</div><div class="sc-u">دقيقة</div></div><div class="sc g"><div class="sc-l">السعرات</div><div class="sc-v">${cals}</div><div class="sc-u">محروقة</div></div><div class="sc b"><div class="sc-l">المجموعات</div><div class="sc-v">${sets}</div></div><div class="sc y"><div class="sc-l">الحجم</div><div class="sc-v">${Math.round(vol).toLocaleString('en')}</div><div class="sc-u">كغ</div></div></div><div class="card-green card" style="text-align:center;font-size:12px;font-weight:700">${['💪 قدرتك لا حدود لها!','🔥 تمرين استثنائي!','⚡ كل يوم أقوى!','🏆 تتفوق على نفسك!'][Math.floor(Math.random()*4)]}</div><button class="btn btn-p" style="margin-top:10px" onclick="hideMo('mo-wk-sum');renderTracker();renderHome()">رائع ✓</button>`;
  {const _b=document.getElementById('wk-sum-b'),_btn=_b.querySelector('button');if(_btn)_btn.insertAdjacentHTML('beforebegin',wkBreakdown(w));else _b.insertAdjacentHTML('beforeend',wkBreakdown(w));}showMo('mo-wk-sum');renderTracker();renderHome();checkAchievements();
}
function renderWkHist(){const el=document.getElementById('wk-hist');const list=[...APP.workouts].reverse().slice(0,8);if(!list.length){el.innerHTML='<div class="empty"><div class="empty-ico">📝</div><div class="empty-t">لا يوجد سجل</div></div>';return;}el.innerHTML=list.map(w=>`<div class="card" style="margin-bottom:6px;padding:11px"><div style="display:flex;justify-content:space-between;align-items:center"><div><div style="font-size:12px;font-weight:700">${w.name}</div><div style="font-size:11px;color:var(--w40)">${new Date(w.date).toLocaleDateString('ar-u-ca-gregory')} · ${w.duration||0} د</div></div><div style="text-align:center"><div style="font-size:17px;font-weight:900;color:var(--red)">${w.totalSets||0}</div><div style="font-size:11px;color:var(--w40)">مجموعة</div></div></div></div>`).join('');}

// ══════════════════════════════════════════════════════
// HOME
// ══════════════════════════════════════════════════════
function renderHome(){
  const u=APP.user||{};
  document.getElementById('h-name').textContent=(u.name||'المحارب')+' 💪';
  const lw=APP.weights.length?APP.weights[APP.weights.length-1].value:'--';
  document.getElementById('h-wt').textContent=lw;
  const streak=calcStreak(APP.workouts);
  document.getElementById('h-str').textContent=streak;
  const now=new Date();
  const monW=APP.workouts.filter(w=>{const d=new Date(w.date);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear();}).length;
  document.getElementById('h-mon').textContent=monW;
  const ws=new Date();ws.setDate(ws.getDate()-ws.getDay());
  const ww=APP.workouts.filter(w=>new Date(w.date)>=ws);
  document.getElementById('h-sw').textContent=ww.length;document.getElementById('h-sc').textContent=ww.reduce((s,w)=>s+(w.calories||0),0);
  document.getElementById('h-sm').textContent=ww.reduce((s,w)=>s+(w.duration||0),0);
  const weeklySets=ww.reduce((s,w)=>s+(w.totalSets||0),0);
  document.getElementById('h-ss').textContent=weeklySets;
  const ssMiniEl=document.getElementById('h-ss-mini');if(ssMiniEl)ssMiniEl.textContent=weeklySets;
  // بطاقة "آخر إنجاز" — تظهر فقط إن وُجد إنجاز مُحقَّق فعلاً، الأحدث زمنياً.
  const achWrap=document.getElementById('h-last-ach-wrap');
  if(achWrap){
    const earned=APP.earnedAch||{};
    const earnedIds=Object.keys(earned).sort((a,b)=>new Date(earned[b])-new Date(earned[a]));
    const lastAch=earnedIds.length?ACHIEVEMENTS.find(a=>a.id===earnedIds[0]):null;
    if(lastAch){
      achWrap.style.display='flex';
      const icoEl=document.getElementById('h-last-ach-ico');if(icoEl)icoEl.textContent=lastAch.ico;
      const nameEl=document.getElementById('h-last-ach-name');if(nameEl)nameEl.textContent=lastAch.name;
    }else achWrap.style.display='none';
  }
  const targetDays=parseInt(u.days)||3;
  const ringPct=Math.min(100,Math.round((ww.length/targetDays)*100));
  const ringCirc=169.6;
  const ringFill=document.getElementById('home-ring-fill');
  const ringTxt=document.getElementById('home-ring-txt');
  if(ringFill)ringFill.style.strokeDashoffset=(ringCirc-(ringCirc*ringPct/100));
  if(ringTxt)ringTxt.textContent=ringPct+'%';
  if(u.calories){const n=document.getElementById('h-nut');n.style.display='flex';document.getElementById('h-cal').textContent=u.calories;document.getElementById('h-pro').textContent=u.protein+'غ';}
  const prog=u.program;
  const primary=getPrimaryPlan();
  const di=now.getDay();
  const todayKey=CUSTOM_DAY_KEYS[di];
  if(primary){
    const td=primary.parsed.days.find(d=>d.dayKey===todayKey);
    if(td){
      document.getElementById('nwc-name').textContent=td.isRest?'😴 يوم راحة':(td.title||'تمرين اليوم');
      document.getElementById('nwc-excount').textContent=td.isRest?'راحة نشطة':`${td.exercises?.length||0} تمارين`;
      document.getElementById('nwc-dur').textContent=td.isRest?'استرح جيداً':(primary.type==='ai-onboarding'?'خطتك الذكية 🤖':primary.name);
    }
  } else if(prog?.schedule?.length){
    const td=prog.schedule[di];
    if(td){
      document.getElementById('nwc-name').textContent=td.isRest?'😴 يوم راحة':td.focus;
      document.getElementById('nwc-excount').textContent=td.isRest?'راحة نشطة':`${td.exIds?.length||0} تمارين`;
      document.getElementById('nwc-dur').textContent=td.isRest?'استرح جيداً':`${u.duration||45} دقيقة`;
    }
  }
  renderWater();drawWtChart();
}
function calcStreak(workouts){if(!(workouts?.length))return 0;const dates=[...new Set(workouts.map(w=>localDay(w.date)))].sort().reverse();let s=0,chk=new Date();chk.setHours(0,0,0,0);for(const d of dates){const wd=new Date(d+'T00:00:00');const diff=(chk-wd)/86400000;if(diff<=1){s++;chk=wd;}else break;}return s;}
function setFatigue(level,el){document.querySelectorAll('.fat-btn').forEach(b=>b.classList.remove('on'));el.classList.add('on');const t=todayKey();APP.fatigue[t]=level;save();const adv=document.getElementById('fat-advice');adv.style.display='block';adv.textContent=level==='great'?'💪 ممتاز! تمرين اليوم بشدة عالية — ارفع الأوزان':level==='normal'?'😐 جيد — تمرين بشدة متوسطة وتركيز على التقنية':'😫 أنت متعب — فكر في Deload أو يوم راحة نشط (مشي خفيف + تمدد)';}
function saveWeight(){const v=parseFloat(document.getElementById('inp-wt').value);if(!v)return toast('أدخل وزنك','⚠️');APP.weights.push({value:v,date:new Date().toISOString(),note:document.getElementById('inp-wt-note').value});save();hideMo('mo-wt');toast('✓ تم تسجيل '+v+' كغ');renderHome();}
function saveCardioLog(){
  const chip=document.querySelector('#cardio-type-chips .chip.on');
  const type=chip?.dataset.type||'running';
  const met=parseFloat(chip?.dataset.met)||9.8;
  const typeLabels={running:'جري',walking:'مشي',cycling:'دراجة',swimming:'سباحة'};
  const dur=parseInt(document.getElementById('cardio-dur').value);
  const dist=parseFloat(document.getElementById('cardio-dist').value)||0;
  const steps=parseInt(document.getElementById('cardio-steps').value)||0;
  if(!dur||dur<=0){toast('أدخل مدة النشاط بالدقائق','⚠️');return;}
  const weight=APP.weights.length?APP.weights[APP.weights.length-1].value:(APP.user?.weight||70);
  // MET formula: calories = MET × weight(kg) × duration(hours) — standard
  // ACSM metabolic equivalent estimation method.
  const cals=Math.round(met*weight*(dur/60));
  const w={
    id:Date.now(),
    name:'🏃 '+typeLabels[type]+(dist?` — ${dist} كم`:''),
    startTime:Date.now()-dur*60000,
    date:new Date().toISOString(),
    exercises:[],
    duration:dur,
    totalSets:0,
    totalVolume:0,
    calories:cals,
    cardioType:type,
    distance:dist||null,
    steps:steps||null,
    endTime:Date.now()
  };
  APP.workouts.push(w);
  save();
  hideMo('mo-cardio-log');
  document.getElementById('cardio-dur').value='';
  document.getElementById('cardio-dist').value='';
  document.getElementById('cardio-steps').value='';
  toast('✅ تم تسجيل النشاط — '+cals+' سعرة محروقة');
  renderTracker();renderHome();checkAchievements();
}

// ══════════════════════════════════════════════════════
// LIVE STEP COUNTER — foreground accelerometer pedometer.
// Three real fixes vs. the old version:
//  1) Adaptive peak detection (moving baseline + hysteresis "arm/re-arm")
//     instead of a single flat threshold, so it tolerates sensor jitter
//     and different carrying positions instead of mis-firing near a cutoff.
//  2) Screen Wake Lock while counting, so the screen doesn't auto-lock
//     mid-walk and kill the sensor — the #1 real-world cause of "it just
//     stopped."
//  3) Autosave + recovery, so a tab reload (e.g. iOS Safari discarding a
//     long-backgrounded tab) doesn't silently wipe the count.
// PLATFORM LIMIT that no code change can remove: once the screen is off or
// another app is in front, no website can run JS or read motion sensors —
// that needs a native pedometer API (iOS CoreMotion / Android Sensor API),
// only reachable from a native or Capacitor-wrapped app. This stays
// foreground-only by platform design, and the UI says so honestly.
// ══════════════════════════════════════════════════════
const STEP_STATE={count:0,active:false,lastStepAt:0,startedAt:null,smoothed:9.8,baseline:9.8,armed:true,wakeLock:null};
const STEP_MIN_INTERVAL_MS=280,STRIDE_METERS=0.75;
const STEP_SMOOTH_ALPHA=0.35;   // light smoothing — removes single-sample sensor noise
const STEP_BASELINE_ALPHA=0.03; // slow-moving baseline — adapts to phone orientation/carry position
const STEP_ARM_MARGIN=0.55;     // signal must dip this far below baseline to "re-arm" for the next step
const STEP_PEAK_MARGIN=1.3;     // signal must rise this far above baseline to count as a step peak
const STEP_SESSION_KEY='acfv2_stepSession';

function handleDeviceMotionForSteps(e){
  const acc=e.accelerationIncludingGravity;
  if(!acc||acc.x==null)return;
  const mag=Math.sqrt(acc.x*acc.x+acc.y*acc.y+acc.z*acc.z);
  // Smooth the raw signal, then track a slow-moving baseline (~1g, but it
  // adapts instead of assuming one fixed phone orientation).
  STEP_STATE.smoothed+=STEP_SMOOTH_ALPHA*(mag-STEP_STATE.smoothed);
  STEP_STATE.baseline+=STEP_BASELINE_ALPHA*(STEP_STATE.smoothed-STEP_STATE.baseline);
  const now=Date.now(),s=STEP_STATE.smoothed,b=STEP_STATE.baseline;
  // Hysteresis peak detection: a step only counts on a genuine rise above
  // baseline+margin, and only re-arms once the signal has actually dropped
  // back down — so one footstep's noisy shoulder can't trigger twice the
  // way a single flat threshold would.
  if(!STEP_STATE.armed&&s<b-STEP_ARM_MARGIN)STEP_STATE.armed=true;
  if(STEP_STATE.armed&&s>b+STEP_PEAK_MARGIN&&(now-STEP_STATE.lastStepAt)>STEP_MIN_INTERVAL_MS){
    STEP_STATE.count++;
    STEP_STATE.lastStepAt=now;
    STEP_STATE.armed=false;
    updateStepDisplay();
    if(STEP_STATE.count%5===0)autosaveStepSession();
  }
}
function updateStepDisplay(){
  const c=document.getElementById('step-count-display');
  if(c)c.textContent=STEP_STATE.count;
  const d=document.getElementById('step-dist-display');
  if(d)d.textContent='≈ '+((STEP_STATE.count*STRIDE_METERS)/1000).toFixed(2)+' كم تقديراً';
}
// Keeps the screen from auto-locking while counting. Locking freezes every
// website's JS, so this removes the most common real-world cause of the
// counter appearing to "stop working" on its own.
async function acquireWakeLock(){
  try{
    if('wakeLock' in navigator){
      STEP_STATE.wakeLock=await navigator.wakeLock.request('screen');
      STEP_STATE.wakeLock.addEventListener('release',()=>{STEP_STATE.wakeLock=null;});
    }
  }catch(e){ /* not fatal — counting still works, the screen just may sleep on its own */ }
}
function releaseWakeLock(){
  if(STEP_STATE.wakeLock){STEP_STATE.wakeLock.release().catch(()=>{});STEP_STATE.wakeLock=null;}
}
function autosaveStepSession(){
  try{localStorage.setItem(STEP_SESSION_KEY,JSON.stringify({count:STEP_STATE.count,startedAt:STEP_STATE.startedAt,savedAt:Date.now()}));}catch(e){}
}
function clearStepSession(){try{localStorage.removeItem(STEP_SESSION_KEY);}catch(e){}}
// Runs once at app boot. If the tab was reloaded mid-walk (e.g. iOS Safari
// discarding a long-backgrounded tab), this restores the count instead of
// silently losing it — but only within the last 3 hours, so a stale
// session from days ago can't reappear unexpectedly.
function restoreStepSessionIfAny(){
  try{
    const raw=localStorage.getItem(STEP_SESSION_KEY);
    if(!raw)return;
    const s=JSON.parse(raw);
    if(s&&s.count>0&&s.savedAt&&(Date.now()-s.savedAt)<3*3600*1000){
      STEP_STATE.count=s.count;
      STEP_STATE.startedAt=s.startedAt||Date.now();
      updateStepDisplay();
      toast('👣 تم استرجاع '+s.count+' خطوة من جلسة سابقة');
    }else clearStepSession();
  }catch(e){}
}
async function toggleStepCounter(){
  const btn=document.getElementById('step-start-btn');
  if(STEP_STATE.active){stopStepCounter();return;}
  // iOS 13+ requires an explicit, user-gesture-triggered permission request
  // before DeviceMotion data is available at all; Android generally doesn't.
  if(typeof DeviceMotionEvent!=='undefined'&&typeof DeviceMotionEvent.requestPermission==='function'){
    try{
      const result=await DeviceMotionEvent.requestPermission();
      if(result!=='granted'){
        const msg=document.getElementById('step-permission-msg');
        if(msg){msg.style.display='block';msg.textContent='⚠️ لم يُمنح إذن الحركة — لا يمكن العد بدونه. تحقق من إعدادات الخصوصية.';}
        return;
      }
    }catch(e){
      toast('⚠️ تعذّر طلب إذن الحركة على هذا الجهاز','⚠️');
      return;
    }
  }
  if(typeof DeviceMotionEvent==='undefined'){
    toast('⚠️ جهازك/متصفحك لا يدعم مستشعر الحركة','⚠️');
    return;
  }
  STEP_STATE.active=true;
  STEP_STATE.startedAt=STEP_STATE.startedAt||Date.now();
  STEP_STATE.smoothed=9.8;STEP_STATE.baseline=9.8;STEP_STATE.armed=true;
  window.addEventListener('devicemotion',handleDeviceMotionForSteps);
  acquireWakeLock();
  const msg=document.getElementById('step-permission-msg');
  if(msg){msg.style.display='none';delete msg.dataset.paused;}
  if(btn)btn.textContent='⏸ إيقاف العد';
  toast('👣 بدأ العد — نُبقي الشاشة مضاءة تلقائياً أثناء العد');
}
function stopStepCounter(){
  STEP_STATE.active=false;
  window.removeEventListener('devicemotion',handleDeviceMotionForSteps);
  releaseWakeLock();
  const btn=document.getElementById('step-start-btn');
  if(btn)btn.textContent='▶ ابدأ العد';
}
function resetStepCounter(){
  STEP_STATE.count=0;STEP_STATE.startedAt=STEP_STATE.active?Date.now():null;
  STEP_STATE.smoothed=9.8;STEP_STATE.baseline=9.8;STEP_STATE.armed=true;
  clearStepSession();
  updateStepDisplay();
}
function saveStepCounterActivity(){
  if(STEP_STATE.count<=0){toast('لا توجد خطوات مسجَّلة بعد','⚠️');return;}
  stopStepCounter();
  const elapsedMin=STEP_STATE.startedAt?Math.max(1,Math.round((Date.now()-STEP_STATE.startedAt)/60000)):Math.max(1,Math.round(STEP_STATE.count/100));
  const distKm=(STEP_STATE.count*STRIDE_METERS)/1000;
  const weight=APP.weights.length?APP.weights[APP.weights.length-1].value:(APP.user?.weight||70);
  const met=9.8; // treat as running-equivalent pace; user can log manually via the other form for a different activity type
  const cals=Math.round(met*weight*(elapsedMin/60));
  const w={
    id:Date.now(),
    name:'👣 جري/مشي (عداد خطوات) — '+STEP_STATE.count+' خطوة',
    startTime:Date.now()-elapsedMin*60000,
    date:new Date().toISOString(),
    exercises:[],
    duration:elapsedMin,
    totalSets:0,
    totalVolume:0,
    calories:cals,
    cardioType:'running',
    distance:Math.round(distKm*100)/100,
    steps:STEP_STATE.count,
    endTime:Date.now()
  };
  APP.workouts.push(w);
  save();
  clearStepSession();
  hideMo('mo-step-counter');
  toast('✅ تم حفظ '+STEP_STATE.count+' خطوة — '+cals+' سعرة');
  STEP_STATE.count=0;STEP_STATE.startedAt=null;
  renderTracker();renderHome();checkAchievements();
}
// Wake Lock is auto-released by the browser the instant the tab is hidden
// (screen lock, app switch, etc). We can't count steps while hidden — no
// website can — but we CAN give honest feedback instead of a silent freeze,
// and reacquire the lock automatically the moment the user comes back.
document.addEventListener('visibilitychange',()=>{
  if(!STEP_STATE.active)return;
  const msg=document.getElementById('step-permission-msg');
  if(document.visibilityState==='visible'){
    acquireWakeLock();
    if(msg&&msg.dataset.paused){msg.style.display='none';msg.textContent='';delete msg.dataset.paused;}
  }else{
    if(msg){msg.style.display='block';msg.dataset.paused='1';msg.textContent='⏸ توقف العدّ مؤقتاً لأن التطبيق في الخلفية — عد لهذه الشاشة لمتابعة العد.';}
    autosaveStepSession();
  }
});
function getWater(){return APP.water[todayKey()]||0;}
function chgWater(d){const t=todayKey();APP.water[t]=Math.max(0,Math.min(8,(APP.water[t]||0)+d));save();renderWater();}
function renderWater(){const c=getWater();const el=document.getElementById('water-num');if(el)el.textContent=c;const bar=document.getElementById('water-bar');if(bar)bar.style.width=(c/8*100)+'%';const cups=document.getElementById('water-cups');const t=todayKey();if(cups)cups.innerHTML=Array.from({length:8},(_,i)=>`<span class="cup ${i<c?'full':''}" onclick="APP.water['${t}']=Math.max(0,${i<c?i:i+1});save();renderWater()">💧</span>`).join('');const lbl=document.getElementById('water-lbl');if(lbl)lbl.textContent=c+' / 8 أكواب';}
function drawWtChart(){const canvas=document.getElementById('wt-chart');if(!canvas)return;const ctx=canvas.getContext('2d');canvas.width=canvas.offsetWidth*2;canvas.height=240;ctx.scale(2,2);const cw=canvas.offsetWidth/2,ch=120;const data=APP.weights.slice(-10);ctx.clearRect(0,0,cw,ch);if(data.length<2){ctx.fillStyle=wc(.2);ctx.font='12px Segoe UI';ctx.textAlign='center';ctx.fillText('سجّل وزنك لرؤية الرسم',cw/2,ch/2);return;}const vals=data.map(d=>d.value);const mn=Math.min(...vals)-2,mx=Math.max(...vals)+2;const p={t:8,b:24,l:7,r:7},gw=cw-p.l-p.r,gh=ch-p.t-p.b;const xf=i=>p.l+(i/(data.length-1))*gw,yf=v=>p.t+gh-((v-mn)/(mx-mn))*gh;const g=ctx.createLinearGradient(0,p.t,0,ch-p.b);g.addColorStop(0,'rgba(200,16,46,.28)');g.addColorStop(1,'rgba(200,16,46,0)');ctx.beginPath();ctx.moveTo(xf(0),yf(vals[0]));vals.forEach((v,i)=>{if(i)ctx.lineTo(xf(i),yf(v));});ctx.lineTo(xf(data.length-1),ch-p.b);ctx.lineTo(xf(0),ch-p.b);ctx.closePath();ctx.fillStyle=g;ctx.fill();ctx.beginPath();ctx.strokeStyle='#C8102E';ctx.lineWidth=2.5;ctx.lineJoin='round';ctx.moveTo(xf(0),yf(vals[0]));vals.forEach((v,i)=>{if(i)ctx.lineTo(xf(i),yf(v));});ctx.stroke();vals.forEach((v,i)=>{ctx.beginPath();ctx.arc(xf(i),yf(v),3,0,Math.PI*2);ctx.fillStyle='#C8102E';ctx.fill();ctx.beginPath();ctx.arc(xf(i),yf(v),1.5,0,Math.PI*2);ctx.fillStyle=wtxt();ctx.fill();});}

// ══════════════════════════════════════════════════════
// MEASUREMENTS
// ══════════════════════════════════════════════════════
function saveMeas(){const m={date:new Date().toISOString(),waist:parseFloat(document.getElementById('m-waist').value)||0,chest:parseFloat(document.getElementById('m-chest').value)||0,arm:parseFloat(document.getElementById('m-arm').value)||0,thigh:parseFloat(document.getElementById('m-thigh').value)||0};APP.measurements.push(m);save();hideMo('mo-meas');toast('✓ تم الحفظ');renderMeas();}
function renderMeas(){const lat=APP.measurements.length?APP.measurements[APP.measurements.length-1]:null;const prev=APP.measurements.length>1?APP.measurements[APP.measurements.length-2]:null;const defs=[{k:'waist',l:'الخصر',ico:'📏',less:true},{k:'chest',l:'الصدر',ico:'🫁',less:false},{k:'arm',l:'الذراع',ico:'💪',less:false},{k:'thigh',l:'الفخذ',ico:'🦵',less:null}];document.getElementById('meas-display').innerHTML=defs.map(d=>{const v=lat?.[d.k]||'--';const pv=prev?.[d.k];const diff=pv&&lat?.[d.k]?(lat[d.k]-pv).toFixed(1):null;const good=diff&&d.less!==null?(d.less?parseFloat(diff)<0:parseFloat(diff)>0):null;return`<div class="sc"><div class="sc-l">${d.ico} ${d.l}</div><div class="sc-v" style="font-size:17px">${v}</div><div class="sc-u">سم</div>${diff?`<div style="font-size:11px;margin-top:2px;color:${good?'var(--g)':'var(--red)'}">${parseFloat(diff)>0?'+':''}${diff}</div>`:''}</div>`;}).join('');const h=document.getElementById('meas-hist');if(!APP.measurements.length){h.innerHTML='<div class="empty"><div class="empty-ico">📏</div><div class="empty-t">لا توجد قياسات</div></div>';return;}h.innerHTML=[...APP.measurements].reverse().slice(0,5).map(m=>`<div class="card" style="margin-bottom:6px;padding:10px"><div style="font-size:11px;color:var(--w40);margin-bottom:6px">${new Date(m.date).toLocaleDateString('ar-u-ca-gregory')}</div><div style="display:flex;gap:12px;flex-wrap:wrap">${m.waist?`<span style="font-size:11px">خصر: <b>${m.waist}</b></span>`:''}${m.chest?`<span style="font-size:11px">صدر: <b>${m.chest}</b></span>`:''}${m.arm?`<span style="font-size:11px">ذراع: <b>${m.arm}</b></span>`:''}${m.thigh?`<span style="font-size:11px">فخذ: <b>${m.thigh}</b></span>`:''}</div></div>`).join('');drawMeasChart('waist');}
function showMeasChart(k,btn){document.querySelectorAll('#pg-measurements .tab').forEach(b=>b.classList.remove('on'));if(btn)btn.classList.add('on');drawMeasChart(k);}
function drawMeasChart(k){const canvas=document.getElementById('meas-chart');if(!canvas)return;const ctx=canvas.getContext('2d');canvas.width=canvas.offsetWidth*2;canvas.height=220;ctx.scale(2,2);const cw=canvas.offsetWidth/2,ch=110;const data=APP.measurements.slice(-8).filter(m=>m[k]);ctx.clearRect(0,0,cw,ch);if(data.length<2){ctx.fillStyle=wc(.2);ctx.font='11px Segoe UI';ctx.textAlign='center';ctx.fillText('سجّل قياسات لرؤية التطور',cw/2,ch/2);return;}const vals=data.map(d=>d[k]);const mn=Math.min(...vals)-2,mx=Math.max(...vals)+2;const p={t:8,b:16,l:4,r:4},gw=cw-p.l-p.r,gh=ch-p.t-p.b;const xf=i=>p.l+(i/(data.length-1))*gw,yf=v=>p.t+gh-((v-mn)/(mx-mn))*gh;const g=ctx.createLinearGradient(0,p.t,0,ch);g.addColorStop(0,'rgba(59,130,246,.28)');g.addColorStop(1,'rgba(59,130,246,0)');ctx.beginPath();ctx.moveTo(xf(0),yf(vals[0]));vals.forEach((v,i)=>{if(i)ctx.lineTo(xf(i),yf(v));});ctx.lineTo(xf(data.length-1),ch-p.b);ctx.lineTo(xf(0),ch-p.b);ctx.closePath();ctx.fillStyle=g;ctx.fill();ctx.beginPath();ctx.strokeStyle='#3B82F6';ctx.lineWidth=2.5;ctx.lineJoin='round';ctx.moveTo(xf(0),yf(vals[0]));vals.forEach((v,i)=>{if(i)ctx.lineTo(xf(i),yf(v));});ctx.stroke();vals.forEach((v,i)=>{ctx.beginPath();ctx.arc(xf(i),yf(v),3,0,Math.PI*2);ctx.fillStyle='#3B82F6';ctx.fill();ctx.fillStyle=wtxt();ctx.font='8px Segoe UI';ctx.textAlign='center';ctx.fillText(v,xf(i),yf(v)-6);});}

// ══════════════════════════════════════════════════════
// CHALLENGES
// ══════════════════════════════════════════════════════
const CHALLENGES=[
 {id:'c1',n:'تحدي الضغط',ico:'💪',days:30,unit:'تكرار',from:10,to:100,step:5,goals:['muscle','strength','recomp','maintain'],desc:'ارفع الضغط تدريجياً من 10 إلى 100 يومياً'},
 {id:'c2',n:'تحدي البلانك',ico:'🔲',days:30,unit:'ثانية',from:20,to:300,step:10,goals:['strength','muscle','recomp','maintain','fat_loss'],desc:'من 20 ثانية إلى 5 دقائق'},
 {id:'c3',n:'تحدي خسارة الدهون',ico:'🔥',days:21,unit:'',from:1,to:1,step:1,check:true,goals:['fat_loss','recomp'],desc:'21 يوم تدريب — سجّل كل يوم تدرّبت فيه'},
 {id:'c4',n:'تحدي السكوات',ico:'🦵',days:30,unit:'تكرار',from:20,to:150,step:5,goals:['muscle','fat_loss','strength','recomp'],desc:'سكوات بوزن الجسم من 20 إلى 150 يومياً'},
 {id:'c5',n:'تحدي القتال',ico:'🥊',days:14,unit:'دقيقة',from:15,to:45,step:5,goals:['endurance','strength','fat_loss'],desc:'ظل أو حقيبة ملاكمة من 15 إلى 45 دقيقة'},
 {id:'c6',n:'تحدي المشي',ico:'🚶',days:30,unit:'خطوة',from:5000,to:10000,step:500,steps:true,goals:['fat_loss','endurance','recomp','maintain'],desc:'من 5,000 إلى 10,000 خطوة — الأنسب لخسارة الوزن'},
 {id:'c7',n:'تحدي الكارديو',ico:'🏃',days:21,unit:'دقيقة',from:10,to:45,step:5,goals:['fat_loss','endurance'],desc:'كارديو متوسط الشدة من 10 إلى 45 دقيقة'},
 {id:'c8',n:'تحدي العقلة',ico:'🧗',days:30,unit:'تكرار',from:1,to:15,step:1,goals:['muscle','strength'],desc:'اجمع عقلات يومياً حتى 15 (مع مساعدة إن لزم)'},
 {id:'c9',n:'تحدي الإطالة',ico:'🧘',days:21,unit:'دقيقة',from:5,to:15,step:1,goals:['muscle','strength','fat_loss','recomp','maintain','endurance'],desc:'مرونة وتعافٍ يومياً من 5 إلى 15 دقيقة'}
];
function chalL(c){return (APP.chalLog&&APP.chalLog[c.id])||{};}
function chalDays(c){const L=chalL(c);return Object.keys(L).filter(k=>L[k].v>=L[k].t).length;}
function chalTarget(c){const e=chalL(c)[todayKey()];if(e)return e.t;if(c.check)return 1;const f0=chalFrom(c),k=Math.min(c.days,chalDays(c)+1),v=f0+(c.to-f0)*(k-1)/Math.max(1,c.days-1);return Math.min(c.to,Math.max(f0,Math.round(v/c.step)*c.step));}
function todaySteps(){return (APP.workouts||[]).filter(w=>localDay(w.date)===todayKey()).reduce((a,w)=>a+(w.steps||0),0)+((typeof STEP_STATE==='object'&&STEP_STATE.count)||0);}
function chalCard(c){
  const goal=APP.user&&APP.user.goal,st=!!(APP.chalStart&&APP.chalStart[c.id]),done=chalDays(c),pct=Math.min(100,Math.round(done/c.days*100)),fin=done>=c.days;
  const tg=chalTarget(c),e=chalL(c)[todayKey()],tv=e?e.v:0,hit=tv>=tg,num=n=>Number(n).toLocaleString('en');
  const badge=fin?'<span class="ch2-b ok">مكتمل 🎉</span>':st?'<span class="ch2-b act">نشط</span>':c.goals.includes(goal)?'<span class="ch2-b">مناسب لهدفك</span>':'';
  let body='';
  if(st&&!fin){
    const wk=[...Array(7)].map((_,i)=>{const d=new Date();d.setDate(d.getDate()-(6-i));const x=chalL(c)[localDay(d)];return`<span class="ch2-d ${x?(x.v>=x.t?'on':'half'):''}">${x?(x.v>=x.t?'✓':'•'):''}</span>`;}).join('');
    const qv=c.steps?[1000,2000,3000]:[...new Set([.25,.5,1].map(m=>Math.max(c.step,Math.round(tg*m/c.step)*c.step)))];
    body=`<div class="ch2-today"><div><div class="ch2-lbl">هدف اليوم</div><div class="ch2-big">${c.check?'تمرين اليوم':num(tg)+' <small>'+c.unit+'</small>'}</div></div><div style="text-align:left"><div class="ch2-lbl">سجّلت اليوم</div><div class="ch2-big ${hit?'ok':''}">${c.check?(tv?'✓':'—'):num(tv)}</div></div></div><div class="ch2-wk">${wk}</div>`
    +(c.check?`<button class="btn btn-p btn-sm" style="width:100%" onclick="chalAdd('${c.id}',1)">✓ تدرّبت اليوم</button>`
    :`<div class="ch2-row">${qv.map(v=>`<button class="ch2-q" onclick="chalAdd('${c.id}',${v})">+${num(v)}</button>`).join('')}</div><div class="ch2-lbl" style="margin:4px 0 6px">كم أنجزت بالضبط؟ (${c.unit})</div><div class="ch2-row"><input class="ch2-in" id="ci-${c.id}" type="number" inputmode="numeric" min="0" max="100000" placeholder="اكتب الرقم هنا"></div><div class="ch2-row"><button class="btn btn-p btn-sm" onclick="chalAddInput('${c.id}')">➕ أضف للعدد</button><button class="btn btn-g btn-sm" onclick="chalSetInput('${c.id}')">ضبط إجمالي اليوم</button></div>`
    +(c.steps?`<button class="btn btn-g btn-sm" style="width:100%;margin-bottom:6px" onclick="chalUseSteps('${c.id}')">👣 استخدم خطوات اليوم من العداد (${num(todaySteps())})</button>`:''))
    +`<div class="ch2-row" style="margin-top:6px"><button class="btn btn-g btn-sm" style="flex:1" onclick="chalUndo('${c.id}')">تصفير اليوم</button><button class="btn btn-g btn-sm" style="flex:1" onclick="stopChal('${c.id}')">إيقاف التحدي</button></div>`;
  }else body=`<button class="btn ${fin?'btn-g':'btn-p'} btn-sm" style="width:100%" onclick="startChal('${c.id}')">${fin?'إعادة التحدي':'ابدأ التحدي'}</button>`;
  return`<div class="chal-card ch2 ${st&&!fin?'act':''}"><div class="ch2-h"><div class="ch2-ico">${c.ico}</div><div style="flex:1"><div class="ch2-t">${c.n}</div><div class="ch2-s">${c.days} يوم · ${c.desc}</div></div>${badge}</div><div class="ch2-pr"><span>${done}/${c.days} يوم</span><span>${pct}%</span></div><div class="pb" style="margin-bottom:10px"><div class="pf" style="width:${pct}%"></div></div>${body}</div>`;
}
function renderChallenges(){
  const goal=APP.user&&APP.user.goal,G={muscle:'بناء العضلات',fat_loss:'خسارة الدهون',strength:'القوة',endurance:'التحمل',recomp:'إعادة التركيب',maintain:'الحفاظ على اللياقة'};
  const b=document.getElementById('act-chal');if(b)b.style.display='none';
  const on=c=>(APP.chalStart&&APP.chalStart[c.id]&&chalDays(c)<c.days)?1:0,rec=c=>c.goals.includes(goal)?1:0;
  const list=[...CHALLENGES].sort((a,b)=>(on(b)-on(a))||(rec(b)-rec(a)));
  document.getElementById('chals-list').innerHTML=(G[goal]?`<div class="ch2-hint">🎯 التحديات التي تحمل علامة «مناسب لهدفك» اختيرت لهدفك: <b>${G[goal]}</b></div>`:'')+list.map(chalCard).join('')+'<div style="height:20px"></div>';
}
function startChal(id){APP.chalStart=APP.chalStart||{};APP.chalLog=APP.chalLog||{};APP.chalStart[id]=todayKey();APP.chalLog[id]={};APP.challenges[id]=0;save();renderChallenges();toast('🏆 بدأت التحدي!');}
function stopChal(id){if(APP.chalStart)delete APP.chalStart[id];save();renderChallenges();}
function chalAdd(id,v){const c=CHALLENGES.find(x=>x.id===id);if(!c||!(v>0))return;v=Math.min(Math.round(v),100000);APP.chalLog=APP.chalLog||{};const L=APP.chalLog[id]=APP.chalLog[id]||{},k=todayKey();if(c.check&&L[k]){toast('✓ سجّلت اليوم بالفعل','⚠️');return;}const before=L[k]&&L[k].v>=L[k].t,e=L[k]||(L[k]={v:0,t:chalTarget(c)});e.v=Math.min(e.v+v,1000000);APP.challenges[id]=chalDays(c);if(chalDays(c)>=c.days)toast('🎉 أكملت التحدي!');else if(e.v>=e.t&&!before)toast('🎯 حققت هدف اليوم!');else toast('✓ تم تسجيل '+v.toLocaleString('en')+' '+c.unit);save();renderChallenges();}
function chalAddInput(id){const el=document.getElementById('ci-'+id),v=parseFloat(el&&el.value);if(!(v>0)){toast('أدخل رقماً صحيحاً','⚠️');return;}chalAdd(id,v);}
function chalUseSteps(id){const c=CHALLENGES.find(x=>x.id===id),n=todaySteps();if(!c||n<=0){toast('لا توجد خطوات مسجّلة اليوم','⚠️');return;}const L=(APP.chalLog=APP.chalLog||{})[id]=APP.chalLog[id]||{},k=todayKey();if(L[k])L[k].v=0;chalAdd(id,n);}
function chalUndo(id){const c=CHALLENGES.find(x=>x.id===id);if(!c||!APP.chalLog||!APP.chalLog[id])return;delete APP.chalLog[id][todayKey()];APP.challenges[id]=chalDays(c);save();renderChallenges();}

// ══════════════════════════════════════════════════════
// PREHAB PAGE
// ══════════════════════════════════════════════════════
function renderPrehab(){showPrehTab('warmup',null);}
function showPrehTab(tab,btn){['warmup','mobility','prehab','cooldown'].forEach(t=>{const el=document.getElementById('preh-'+t);if(el)el.style.display=t===tab?'block':'none';});document.querySelectorAll('#pg-prehab .tab').forEach(b=>b.classList.remove('on'));if(btn)btn.classList.add('on');const data=PREHAB[tab]||[];document.getElementById('preh-'+tab).innerHTML=`<div style="background:rgba(59,130,246,.07);border:1px solid rgba(59,130,246,.2);border-radius:10px;padding:10px;margin-bottom:12px;font-size:11px;color:var(--b);line-height:1.75">ℹ️ ${tab==='warmup'?'الإحماء الديناميكي يرفع درجة حرارة العضلات ويقلل الإصابات — 5-10 دقائق':tab==='mobility'?'Mobility يحسن مدى الحركة ويقلل الألم المزمن — افعله يومياً':tab==='prehab'?'Prehab يقوي العضلات المستقرة ويمنع الإصابات قبل حدوثها':'التبريد يخفض الكورتيزول ويسرع التعافي — لا تتجاهله'}</div>${data.map(item=>`<div class="mob-item"><div class="mob-ico" style="background:${item.color}">${item.ico}</div><div style="flex:1"><div style="font-size:12px;font-weight:700">${item.name}</div><div style="font-size:11px;color:var(--b);margin-top:1px">${item.eng}</div><div style="font-size:11px;color:var(--w40);margin-top:1px">${item.time}</div></div><div style="font-size:11px;color:var(--w60);max-width:120px;text-align:left;line-height:1.5">${item.tip}</div></div>`).join('')}<button class="btn btn-p" style="margin-top:10px" onclick="APP.prehabSessions=(APP.prehabSessions||0)+1;save();toast('✅ جلسة '+tab+' مكتملة!');checkAchievements()">✓ أكملت هذا القسم</button>`;}

// ══════════════════════════════════════════════════════
// PROGRESS PAGE
// ══════════════════════════════════════════════════════
function renderProgress(){showProgTab('plan12',null);}
function showProgTab(tab,btn){['plan12','deload','autoReg','calis'].forEach(t=>{const el=document.getElementById('prog-'+t);if(el)el.style.display=t===tab?'block':'none';});document.querySelectorAll('#pg-progress .tab').forEach(b=>b.classList.remove('on'));if(btn)btn.classList.add('on');if(tab==='plan12')renderPlan12();if(tab==='deload')renderDeload();if(tab==='autoReg')renderAutoReg();if(tab==='calis')renderCalis();}
function renderPlan12(){const u=APP.user;const plan=build12WeekPlan(u?.goal||'muscle',u?.level||'beginner');document.getElementById('prog-plan12').innerHTML=`<div style="background:rgba(200,16,46,.07);border:1px solid rgba(200,16,46,.2);border-radius:10px;padding:10px;margin-bottom:12px;font-size:11px;color:var(--danger);line-height:1.75">📖 مبني على نموذج Block Periodization من NSCA Essentials (2016)</div>${plan.phases.map((ph,i)=>`<div class="card" style="margin-bottom:9px"><div style="display:flex;align-items:center;gap:9px;margin-bottom:9px"><div style="width:36px;height:36px;border-radius:10px;background:rgba(200,16,46,.18);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">${['📦','⚡','🏆','😴'][i]||'📋'}</div><div><div style="font-size:13px;font-weight:800">الأسابيع ${ph.weeks}: ${ph.name}</div><div style="font-size:11px;color:var(--w60);margin-top:2px">${ph.focus}</div></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div style="background:var(--b3);border-radius:8px;padding:8px;text-align:center"><div style="font-size:11px;color:var(--w40)">المجموعات</div><div style="font-size:16px;font-weight:900;color:var(--red)">${ph.sets}</div></div><div style="background:var(--b3);border-radius:8px;padding:8px;text-align:center"><div style="font-size:11px;color:var(--w40)">التكرارات</div><div style="font-size:16px;font-weight:900;color:var(--b)">${ph.reps}</div></div><div style="background:var(--b3);border-radius:8px;padding:8px;text-align:center"><div style="font-size:11px;color:var(--w40)">RIR</div><div style="font-size:16px;font-weight:900;color:var(--g)">${ph.rir}</div></div><div style="background:var(--b3);border-radius:8px;padding:8px;text-align:center"><div style="font-size:11px;color:var(--w40)">RPE</div><div style="font-size:16px;font-weight:900;color:var(--y)">${ph.rpe}</div></div></div></div>`).join('')}`;}
function renderDeload(){document.getElementById('prog-deload').innerHTML=`<div style="background:rgba(34,197,94,.07);border:1px solid rgba(34,197,94,.2);border-radius:10px;padding:10px;margin-bottom:12px;font-size:11px;color:rgba(100,220,150,1);line-height:1.75">🔬 الدراسات تُظهر أن Deload كل 4-8 أسابيع يُحسن الأداء طويل الأمد (Bartolomei et al., 2017)</div><div class="card" style="margin-bottom:9px"><div style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--g)">🕐 متى تفعل Deload؟</div><div style="font-size:11px;color:var(--w60);line-height:2">• الأداء انخفض رغم التغذية الجيدة<br>• ألم في المفاصل أكثر من المعتاد<br>• النوم ثقيل والإرهاق مزمن<br>• بعد 4-8 أسابيع من التدريب الشديد</div></div><div class="card"><div style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--y)">⚙️ كيف تفعل Deload؟</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div style="background:var(--b3);border-radius:8px;padding:9px;text-align:center"><div style="font-size:11px;color:var(--w40)">الوزن</div><div style="font-size:14px;font-weight:900;color:var(--red)">-40%</div></div><div style="background:var(--b3);border-radius:8px;padding:9px;text-align:center"><div style="font-size:11px;color:var(--w40)">المجموعات</div><div style="font-size:14px;font-weight:900;color:var(--b)">-40%</div></div><div style="background:var(--b3);border-radius:8px;padding:9px;text-align:center"><div style="font-size:11px;color:var(--w40)">التكرارات</div><div style="font-size:14px;font-weight:900;color:var(--g)">نفس</div></div><div style="background:var(--b3);border-radius:8px;padding:9px;text-align:center"><div style="font-size:11px;color:var(--w40)">التقنية</div><div style="font-size:14px;font-weight:900;color:var(--y)">مثالية</div></div></div><div style="font-size:11px;color:var(--w60);line-height:1.85;margin-top:10px">✅ حافظ على الأيام<br>✅ ركز على التقنية<br>✅ نم 8-9 ساعات<br>✅ ارفع البروتين<br>❌ لا تضيف حجماً جديداً</div></div>`;}
function renderAutoReg(){document.getElementById('prog-autoReg').innerHTML=`<div style="background:rgba(59,130,246,.07);border:1px solid rgba(59,130,246,.2);border-radius:10px;padding:10px;margin-bottom:12px;font-size:11px;color:rgba(120,180,255,1);line-height:1.75">📊 Auto-Regulation يعني تعديل شدة اليوم بناءً على حالتك الفعلية — أثبت فاعليته مقارنة بالبرامج الثابتة (Zourdos et al., 2016)</div><div class="card" style="margin-bottom:9px"><div style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--b)">🎯 مقياس RPE (Rate of Perceived Exertion)</div><div style="font-size:11px;color:var(--w60);line-height:2.2">• RPE 10 = فشل عضلي كامل<br>• RPE 9 = تكرار واحد متبقٍ<br>• RPE 8 = تكراران متبقيان<br>• RPE 7 = ثلاثة تكرارات متبقية<br>• RPE 6-5 = إحماء وتفريغ</div></div><div class="card"><div style="font-size:13px;font-weight:800;margin-bottom:8px;color:var(--g)">📈 Double Progression (للمتوسط)</div><div style="font-size:11px;color:var(--w60);line-height:1.9">1️⃣ ابدأ بنطاق 8-12 تكرار<br>2️⃣ عندما تصل لـ 12 في كل المجموعات → زد الوزن 2.5 كغ<br>3️⃣ ابدأ من جديد بـ 8 تكرارات<br>🔄 هذا أفضل من زيادة أسبوعية ثابتة</div></div>`;}
function renderCalis(){document.getElementById('prog-calis').innerHTML=Object.values(CALIS_PROG).map(prog=>`<div class="card" style="margin-bottom:10px"><div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><span style="font-size:24px">${prog.ico}</span><div style="font-size:13px;font-weight:800">${prog.name}</div></div>${prog.levels.map((lv,i)=>`<div style="display:flex;gap:8px;align-items:center;padding:7px 0;border-bottom:1px solid rgba(var(--wa),.04)"><div style="width:22px;height:22px;border-radius:50%;background:rgba(200,16,46,.2);color:var(--red);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0">${i+1}</div><div style="flex:1"><div style="font-size:11px;font-weight:700">${lv.name}</div><div style="font-size:11px;color:var(--y)">🔓 شرط: ${lv.cond}</div></div><div style="font-size:11px;color:var(--b);font-weight:600">${lv.sets}</div></div>`).join('')}</div>`).join('');}

// ══════════════════════════════════════════════════════
// ACHIEVEMENTS
// ══════════════════════════════════════════════════════
function checkAchievements(){const state={workouts:APP.workouts,weights:APP.weights,water:APP.water,challenges:APP.challenges,aiMsgs:APP.aiMsgs||0,prehabSessions:APP.prehabSessions||0};ACHIEVEMENTS.forEach(a=>{const unlocked=a.cond(state);if(unlocked&&!(APP.earnedAch||{})[a.id]){APP.earnedAch=APP.earnedAch||{};APP.earnedAch[a.id]=new Date().toISOString();save();toast(a.ico+' إنجاز جديد: '+a.name,'🏅');}});}
function renderAchievements(){const earned=APP.earnedAch||{};document.getElementById('ach-list').innerHTML=ACHIEVEMENTS.map(a=>`<div class="ach-card ${earned[a.id]?'':'ach-locked'}"><div class="ach-ico">${a.ico}</div><div style="flex:1"><div style="font-size:12px;font-weight:800">${a.name}</div><div style="font-size:11px;color:var(--w40)">${a.desc}</div>${earned[a.id]?`<div style="font-size:11px;color:var(--g);margin-top:2px">✅ ${new Date(earned[a.id]).toLocaleDateString('ar-u-ca-gregory')}</div>`:''}</div>${earned[a.id]?'<span style="font-size:11px;background:rgba(34,197,94,.18);color:var(--g);padding:2px 7px;border-radius:8px;font-weight:700">مفتوح</span>':'<span style="font-size:11px;color:var(--w40);padding:2px 7px;border-radius:8px;background:var(--b3)">مقفل</span>'}</div>`).join('');}

// ══════════════════════════════════════════════════════
// STATS
// ══════════════════════════════════════════════════════
function renderStats(){const tCal=APP.workouts.reduce((s,w)=>s+(w.calories||0),0);const tMin=APP.workouts.reduce((s,w)=>s+(w.duration||0),0);document.getElementById('stat-overview').innerHTML=`<div class="sg" style="margin-bottom:10px"><div class="sc r"><div class="sc-l">إجمالي التمارين</div><div class="sc-v">${APP.workouts.length}</div></div><div class="sc g"><div class="sc-l">السعرات المحروقة</div><div class="sc-v">${tCal}</div></div><div class="sc b"><div class="sc-l">ساعات التدريب</div><div class="sc-v">${Math.round(tMin/60*10)/10}</div></div><div class="sc y"><div class="sc-l">أطول سلسلة</div><div class="sc-v">${calcBestStreak()}</div><div class="sc-u">يوم</div></div></div><div style="font-size:12px;font-weight:700;margin-bottom:7px">📈 آخر 8 أسابيع</div><div class="card"><canvas id="monthly-chart" style="width:100%;height:110px"></canvas></div>`;drawMonthlyChart();buildRecords();renderCalendar();}
function calcBestStreak(){if(!APP.workouts.length)return 0;const dates=[...new Set(APP.workouts.map(w=>localDay(w.date)))].sort();let b=1,c=1;for(let i=1;i<dates.length;i++){const d=(new Date(dates[i])-new Date(dates[i-1]))/86400000;if(d===1){c++;b=Math.max(b,c);}else c=1;}return b;}
function showStatTab(tab,btn){document.querySelectorAll('#stats-tabs .tab').forEach(b=>b.classList.remove('on'));btn.classList.add('on');document.getElementById('stat-overview').style.display=tab==='overview'?'block':'none';document.getElementById('stat-records').style.display=tab==='records'?'block':'none';document.getElementById('stat-performance').style.display=tab==='performance'?'block':'none';document.getElementById('stat-calendar').style.display=tab==='calendar'?'block':'none';if(tab==='overview')drawMonthlyChart();if(tab==='calendar')renderCalendar();if(tab==='performance')renderPerformance();}
function drawMonthlyChart(){const canvas=document.getElementById('monthly-chart');if(!canvas)return;const ctx=canvas.getContext('2d');canvas.width=canvas.offsetWidth*2;canvas.height=220;ctx.scale(2,2);const cw=canvas.offsetWidth/2,ch=110;const weeks=[];for(let i=7;i>=0;i--){const e=new Date();e.setDate(e.getDate()-i*7);const s=new Date(e);s.setDate(s.getDate()-7);weeks.push({l:'أ'+(8-i),c:APP.workouts.filter(w=>{const d=new Date(w.date);return d>=s&&d<e;}).length});}const mx=Math.max(...weeks.map(w=>w.c),1);const bw=(cw-16)/weeks.length-4;const p={t:7,b:20,l:4,r:4},gh=ch-p.t-p.b;ctx.clearRect(0,0,cw,ch);weeks.forEach((w,i)=>{const x=p.l+i*(bw+4);const bh=(w.c/mx)*gh;const y=p.t+gh-bh;const g=ctx.createLinearGradient(0,y,0,ch-p.b);g.addColorStop(0,'#C8102E');g.addColorStop(1,'rgba(200,16,46,.22)');ctx.fillStyle=g;ctx.beginPath();ctx.roundRect(x,y,bw,bh,2);ctx.fill();if(w.c){ctx.fillStyle=wc(.5);ctx.font='7px Segoe UI';ctx.textAlign='center';ctx.fillText(w.c,x+bw/2,y-3);}ctx.fillStyle=wc(.3);ctx.font='7px Segoe UI';ctx.textAlign='center';ctx.fillText(w.l,x+bw/2,ch-p.b+10);});}
function buildRecords(){const rec={};APP.workouts.forEach(w=>(w.exercises||[]).forEach(ex=>{const n=EX[ex.sciId||ex.id]?.n||ex.name;ex.sets?.filter(s=>s.done&&s.weight).forEach(s=>{if(!rec[n]||s.weight>rec[n].w)rec[n]={w:s.weight,r:s.reps,date:w.date};});}));const entries=Object.entries(rec);document.getElementById('stat-records').innerHTML=entries.length?entries.map(([n,r])=>`<div class="ex-item"><div class="ex-ico">🏆</div><div class="ex-info"><div class="ex-name">${n}</div><div class="ex-meta">${new Date(r.date).toLocaleDateString('ar-u-ca-gregory')}</div></div><div style="text-align:center"><div style="font-size:16px;font-weight:900;color:var(--red)">${r.w}<span style="font-size:11px"> كغ</span></div><div style="font-size:11px;color:var(--w40)">${r.r} تكرار</div></div></div>`).join(''):'<div class="empty"><div class="empty-ico">🏆</div><div class="empty-t">لا توجد أرقام قياسية بعد</div></div>';}

// ══════════════════════════════════════════════════════
// PERFORMANCE ANALYSIS — compares actual logged weights/reps
// week-over-week for the SAME exercise name, regardless of
// whether that exercise came from the generated program, the
// AI-analyzed custom program, or a quick session. Works purely
// off APP.workouts (real logged data), not the program template.
// ══════════════════════════════════════════════════════
function getISOWeek(d){const dt=new Date(d);dt.setHours(0,0,0,0);dt.setDate(dt.getDate()+3-((dt.getDay()+6)%7));const week1=new Date(dt.getFullYear(),0,4);return dt.getFullYear()+'-W'+(1+Math.round(((dt-week1)/86400000-3+((week1.getDay()+6)%7))/7));}
function weekStartDate(d){const dt=new Date(d);const day=(dt.getDay()+6)%7;dt.setDate(dt.getDate()-day);dt.setHours(0,0,0,0);return dt;}

// Build per-exercise per-week aggregates: best set (top weight, and reps at that weight),
// total volume (Σ weight×reps over completed sets), total completed sets.
function buildPerfWeeks(){
  const weeks={}; // weekKey -> {start:Date, exercises:{name:{bestWeight,bestReps,volume,sets,sessions}}}
  APP.workouts.forEach(w=>{
    const wk=getISOWeek(w.date);
    if(!weeks[wk])weeks[wk]={start:weekStartDate(w.date),exercises:{}};
    (w.exercises||[]).forEach(ex=>{
      const name=EX[ex.sciId||ex.id]?.n||ex.name;
      if(!name)return;
      const doneSets=(ex.sets||[]).filter(s=>s.done);
      if(!doneSets.length)return;
      if(!weeks[wk].exercises[name])weeks[wk].exercises[name]={bestWeight:0,bestReps:0,volume:0,sets:0,sessions:0};
      const agg=weeks[wk].exercises[name];
      agg.sessions++;
      doneSets.forEach(s=>{
        const wt=parseFloat(s.weight)||0,rp=parseInt(s.reps)||0;
        agg.volume+=wt*rp;
        agg.sets++;
        if(wt>agg.bestWeight||(wt===agg.bestWeight&&rp>agg.bestReps)){agg.bestWeight=wt;agg.bestReps=rp;}
      });
    });
  });
  return weeks;
}

// Compare the most recent training week against the one before it.
function buildWeekComparison(){
  const weeks=buildPerfWeeks();
  const keys=Object.keys(weeks).sort((a,b)=>weeks[a].start-weeks[b].start);
  if(keys.length<1)return null;
  const curKey=keys[keys.length-1];
  const prevKey=keys.length>=2?keys[keys.length-2]:null;
  const cur=weeks[curKey];
  const prev=prevKey?weeks[prevKey]:null;
  const allNames=new Set([...Object.keys(cur.exercises),...(prev?Object.keys(prev.exercises):[])]);
  const rows=[...allNames].map(name=>{
    const c=cur.exercises[name],p=prev?.exercises[name];
    let weightDelta=null,volumeDelta=null,status='new';
    if(c&&p){
      weightDelta=c.bestWeight-p.bestWeight;
      volumeDelta=p.volume>0?Math.round(((c.volume-p.volume)/p.volume)*100):null;
      status=weightDelta>0?'up':weightDelta<0?'down':'same';
    }else if(c&&!p){status='new';}
    else if(!c&&p){status='missing';}
    return {name,cur:c,prev:p,weightDelta,volumeDelta,status};
  }).filter(r=>r.cur||r.prev);
  rows.sort((a,b)=>{
    const order={down:0,missing:1,same:2,new:3,up:4};
    return order[a.status]-order[b.status];
  });
  return {curKey,prevKey,curStart:cur.start,prevStart:prev?.start,rows,hasPrev:!!prev};
}

function renderPerformance(){
  const wrap=document.getElementById('stat-performance');
  if(!wrap)return;
  const cmp=buildWeekComparison();
  if(!cmp||!cmp.rows.length){
    wrap.innerHTML=`<div class="empty"><div class="empty-ico">📈</div><div class="empty-t">لا توجد بيانات أداء كافية</div><div class="empty-s">سجّل تمرينين على الأقل في أسبوعين مختلفين لرؤية المقارنة</div></div>`;
    return;
  }
  let h='';
  if(!cmp.hasPrev){
    h+=`<div style="background:rgba(59,130,246,.07);border:1px solid rgba(59,130,246,.2);border-radius:10px;padding:10px;margin-bottom:11px;font-size:11px;color:var(--b);line-height:1.75">ℹ️ هذا أول أسبوع مسجَّل — أكمل أسبوعاً آخر لرؤية مقارنة الأداء الكاملة (وزن، تكرار، حجم)</div>`;
  } else {
    const upCount=cmp.rows.filter(r=>r.status==='up').length;
    const downCount=cmp.rows.filter(r=>r.status==='down').length;
    h+=`<div style="display:flex;gap:6px;margin-bottom:11px;flex-wrap:wrap">
      <span style="font-size:11px;background:rgba(34,197,94,.16);color:var(--g);padding:3px 9px;border-radius:10px;font-weight:700">📈 ${upCount} تمارين تحسّنت</span>
      <span style="font-size:11px;background:rgba(200,16,46,.16);color:var(--red);padding:3px 9px;border-radius:10px;font-weight:700">📉 ${downCount} تمارين تراجعت</span>
    </div>`;
  }
  h+=`<button class="btn btn-p" style="margin-bottom:12px" onclick="analyzePerformance()" id="perf-analyze-btn">🤖 حلّل أدائي بالذكاء الاصطناعي</button>`;
  h+=`<div id="perf-ai-result"></div>`;
  h+=`<div style="font-size:11px;color:var(--w40);margin-bottom:9px">مقارنة أفضل أداء مُسجَّل لكل تمرين بين هذا الأسبوع${cmp.hasPrev?' والأسبوع السابق':''}</div>`;
  cmp.rows.forEach(r=>{
    const icon=r.status==='up'?'📈':r.status==='down'?'📉':r.status==='new'?'🆕':r.status==='missing'?'⏸️':'➖';
    const color=r.status==='up'?'var(--g)':r.status==='down'?'var(--red)':r.status==='new'?'var(--b)':'var(--w40)';
    let detail='';
    if(r.cur&&r.prev){
      const wSign=r.weightDelta>0?'+':'';
      detail=`<div style="font-size:11px;color:${color}">${wSign}${r.weightDelta} كغ ${r.volumeDelta!==null?`· حجم ${r.volumeDelta>0?'+':''}${r.volumeDelta}%`:''}</div>`;
    } else if(r.cur&&!r.prev){
      detail=`<div style="font-size:11px;color:var(--b)">تمرين جديد هذا الأسبوع</div>`;
    } else if(!r.cur&&r.prev){
      detail=`<div style="font-size:11px;color:var(--w40)">لم يُسجَّل هذا الأسبوع</div>`;
    }
    const curTxt=r.cur?`${r.cur.bestWeight} كغ × ${r.cur.bestReps}`:'—';
    const prevTxt=r.prev?`${r.prev.bestWeight} كغ × ${r.prev.bestReps}`:'—';
    h+=`<div class="ex-item" style="cursor:default">
      <div class="ex-ico" style="background:${color}22">${icon}</div>
      <div class="ex-info"><div class="ex-name">${r.name}</div>${detail}</div>
      <div style="text-align:left;font-size:11px;color:var(--w60)">
        ${cmp.hasPrev?`<div style="color:var(--w40)">السابق: ${prevTxt}</div>`:''}
        <div style="font-weight:800;color:var(--w)">الآن: ${curTxt}</div>
      </div>
    </div>`;
  });
  wrap.innerHTML=h;
}

// ══════════════════════════════════════════════════════
// الذكاء الاصطناعي — كل مستخدم بمفتاحه الخاص (بدون خادم وسيط)
// كل مستخدم يحصل على مفتاح Gemini مجاني من حسابه في Google، ويُخزَّن على
// جهازه فقط (localStorage) — لا يُرسَل لأي خادم عدا Google نفسها. هذا يعني:
// لا مفتاح مشترك يمكن أن يُستهلك من زوّار آخرين، ولا اعتماد على إعدادات
// أي خادم، وكل شخص يستخدم حصته المجانية الخاصة.
// ══════════════════════════════════════════════════════
const GEMINI_MODEL='gemini-3.5-flash';
const GEMINI_KEY_STORAGE='acfv2_geminiKey';
function getGeminiKey(){try{return localStorage.getItem(GEMINI_KEY_STORAGE)||'';}catch(e){return'';}}
function setGeminiKey(k){try{if(k)localStorage.setItem(GEMINI_KEY_STORAGE,k);else localStorage.removeItem(GEMINI_KEY_STORAGE);}catch(e){}}
function renderGeminiKeyStatus(){
  const st=document.getElementById('gemini-key-status');
  const inp=document.getElementById('inp-gemini-key');
  const k=getGeminiKey();
  if(inp)inp.value=k;
  if(st)st.innerHTML=k?'✅ يوجد مفتاح محفوظ على هذا الجهاز':'⚠️ لا يوجد مفتاح بعد — ميزات الذكاء الاصطناعي (المدرب، تحليل الأداء، تحليل الجدول) معطّلة حتى تُضيف مفتاحك';
}
function saveGeminiKeyFromInput(){
  const inp=document.getElementById('inp-gemini-key');
  const k=(inp?.value||'').trim();
  if(!k){toast('أدخل مفتاحاً صالحاً أولاً','⚠️');return;}
  setGeminiKey(k);
  renderGeminiKeyStatus();
  toast('✅ تم حفظ المفتاح على هذا الجهاز فقط');
}
function clearGeminiKey(){
  setGeminiKey('');
  renderGeminiKeyStatus();
  toast('🗑 تم حذف المفتاح من هذا الجهاز');
}
// نداء مباشر من المتصفح إلى Gemini، بمفتاح هذا المستخدم فقط. يُرجع دائماً
// نفس الشكل المُوحَّد {content:[{type:'text',text}]} أو {error:{message}}
// حتى تبقى extractApiText ومعالجة الأخطاء في الدوال الثلاث كما هي.
async function callAI(system,messages,maxTokens,_depth){
  const apiKey=getGeminiKey();
  if(!apiKey)return{error:{message:'أضف مفتاح Gemini الخاص بك أولاً: الإعدادات ⚙️ ← 🔑 مفتاح الذكاء الاصطناعي'}};if(!aiConsent())return{error:{message:'لم تُمنح موافقتك على إرسال بياناتك إلى Gemini'}};
  const contents=messages.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:String(m.content||'')}]}));
  const body={contents,generationConfig:{maxOutputTokens:Math.min(Math.max(Number(maxTokens)||1024,1)+6000,16000)}};
  if(system)body.system_instruction={parts:[{text:String(system)}]};
  try{
    const ctl=new AbortController();const _to=setTimeout(()=>ctl.abort(),(Number(maxTokens)||1024)>3000?150000:70000);const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,{
      method:'POST',signal:ctl.signal,
      headers:{'Content-Type':'application/json','x-goog-api-key':apiKey},
      body:JSON.stringify(body)
    });
    clearTimeout(_to);const raw=await res.json();
    if(!res.ok){
      const msg=raw?.error?.message||('خطأ من خدمة Gemini ('+res.status+')');
      // أشهر سبب فشل: مفتاح غير صالح/منتهي — نوضّحه صراحة بدل رسالة تقنية عامة.
      return{error:{message:res.status===429?'تجاوزت الحصة المجانية لمفتاحك — انتظر قليلاً ثم حاول مجدداً':res.status===400||res.status===403?'المفتاح غير صالح أو غير مُفعَّل. تحقق منه في الإعدادات ⚙️ ← 🔑 مفتاح الذكاء الاصطناعي':msg}};
    }
    const candidate=raw?.candidates?.[0];
    if(!candidate){
      const blockReason=raw?.promptFeedback?.blockReason;
      return{error:{message:blockReason?('تم حظر الطلب من Gemini ('+blockReason+')'):'لم يُرجِع Gemini أي محتوى'}};
    }
    // الفلترة تتجاهل أجزاء "التفكير الداخلي" (thought parts) التي قد تُرجعها
    // بعض النماذج، وتُبقي فقط النص الفعلي المُوجَّه للمستخدم.
    const parts=candidate.content?.parts||[];
    const text=parts.filter(p=>!p.thought&&typeof p.text==='string').map(p=>p.text).join('').trim();
    if(!text)return{error:{message:'لم يُرجِع Gemini نصاً'+(candidate.finishReason?' ('+candidate.finishReason+')':'')}};
    if(candidate.finishReason==='MAX_TOKENS'&&(Number(maxTokens)||1024)<=3000&&(_depth||0)<2){
      const base=text.replace(/\s*\S*$/,'')||text;
      const more=await callAI(system,[...messages,{role:'assistant',content:base},{role:'user',content:'أكمل من حيث توقفت تماماً، دون تكرار ودون مقدمة.'}],maxTokens,(_depth||0)+1);
      const t2=extractApiText(more);
      return{content:[{type:'text',text:t2?base+' '+t2:text}]};
    }
    return{content:[{type:'text',text}]};
  }catch(e){
    return{error:{message:e&&e.name==='AbortError'?'انتهت مهلة الرد من Gemini — حاول مجدداً':'تعذّر الاتصال بخدمة Gemini — تحقق من اتصالك بالإنترنت'}};
  }
}

// Robustly extract all text from a callAI() response, concatenating every
// text content block (not just the first) — the response can legitimately
// contain more than one block, and reading only [0] silently drops content.
function extractApiText(data){
  if(!data||!Array.isArray(data.content))return'';
  return data.content.map(b=>(b&&b.type==='text'&&b.text)?b.text:'').join('').trim();
}
async function analyzePerformance(){
  const cmp=buildWeekComparison();
  if(!cmp||!cmp.rows.length){toast('لا توجد بيانات كافية للتحليل','⚠️');return;}
  const btn=document.getElementById('perf-analyze-btn');
  if(btn){btn.disabled=true;btn.innerHTML='⏳ جاري تحليل أدائك...';}
  toast('🤖 يحلل الذكاء الاصطناعي أداءك...','⏳');
  const u=APP.user||{};
  const dataLines=cmp.rows.map(r=>{
    if(r.cur&&r.prev)return `${r.name}: الأسبوع السابق ${r.prev.bestWeight}كغ×${r.prev.bestReps} (حجم ${Math.round(r.prev.volume)}) ← هذا الأسبوع ${r.cur.bestWeight}كغ×${r.cur.bestReps} (حجم ${Math.round(r.cur.volume)})`;
    if(r.cur&&!r.prev)return `${r.name}: تمرين جديد هذا الأسبوع — ${r.cur.bestWeight}كغ×${r.cur.bestReps}`;
    if(!r.cur&&r.prev)return `${r.name}: تم تدريبه الأسبوع السابق (${r.prev.bestWeight}كغ×${r.prev.bestReps}) لكن لم يُسجَّل هذا الأسبوع`;
    return '';
  }).filter(Boolean).join('\n');
  const sys=`أنت مدرب رياضي محترف يحلل بيانات أداء فعلية مسجَّلة من تطبيق تتبع تمارين. لديك مقارنة بين أداء المستخدم الفعلي (أوزان وتكرارات حقيقية رفعها) بين أسبوعين متتاليين. اكتب تحليلاً علمياً مختصراً بالعربية (لا يتجاوز 200 كلمة) يغطي:
1) أي تمارين تقدّمت فعلياً وبكم تقريباً
2) أي تمارين ركدت أو تراجعت، ولماذا قد يحدث ذلك علمياً (نقص تعافٍ، نوم، بروتين، أو حان وقت Deload)
3) توصية عملية واحدة لكل حالة تراجع
4) لا تخترع أرقاماً غير موجودة في البيانات أدناه — استخدم فقط ما هو مذكور
استخدم **bold** للنقاط المهمة. ${u.name?'اسم المستخدم: '+u.name+'.':''} ${u.goal?'هدفه: '+u.goal+'.':''} ${u.level?'مستواه: '+u.level+'.':''}`;
  const userMsg=`بيانات الأداء الفعلية المسجَّلة (مقارنة أسبوعين):\n\n${dataLines}\n\nحلّل هذا الأداء حسب التعليمات.`;
  try{
    const data=await callAI(sys,[{role:'user',content:userMsg}],1200);
    if(data?.error)throw new Error(data.error.message||'خطأ غير معروف');
    const txt=extractApiText(data)||'تعذّر إنشاء التحليل.';
    const resEl=document.getElementById('perf-ai-result');
    if(resEl)resEl.innerHTML=`<div class="card-blue card" style="margin-bottom:12px"><div style="font-size:12px;font-weight:800;color:var(--b);margin-bottom:7px">🤖 تحليل أدائك الأسبوعي</div><div style="font-size:12px;color:var(--w75);line-height:1.85">${txt.replace(/\*\*(.*?)\*\*/g,'<b>$1</b>').replace(/\n/g,'<br>')}</div></div>`;
    toast('✅ تم تحليل أدائك!');
  }catch(e){
    toast('⚠️ '+(e.message||'تعذّر الاتصال بالذكاء الاصطناعي'),'⚠️');
  }finally{
    if(btn){btn.disabled=false;btn.innerHTML='🤖 حلّل أدائي بالذكاء الاصطناعي';}
  }
}

function renderCalendar(){const now=new Date();const y=now.getFullYear(),m=now.getMonth();const fd=new Date(y,m,1).getDay();const dim=new Date(y,m+1,0).getDate();const wds=APP.workouts.map(w=>localDay(w.date));const mns=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];let h=`<div class="card"><div style="text-align:center;font-size:13px;font-weight:800;margin-bottom:9px;color:var(--red)">${mns[m]} ${y}</div><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;text-align:center">${['أح','اث','ثل','أر','خم','جم','سب'].map(d=>`<div style="font-size:11px;color:var(--w40);padding:2px">${d}</div>`).join('')}${Array(fd).fill('<div></div>').join('')}`;for(let d=1;d<=dim;d++){const ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;const hw=wds.includes(ds);const it=d===now.getDate();h+=`<div style="padding:4px 2px;font-size:11px;border-radius:6px;font-weight:600;background:${hw?'var(--red)':it?'rgba(200,16,46,.18)':'transparent'};color:${hw?'#fff':it?'var(--red)':'var(--w40)'};border:${it&&!hw?'1px solid var(--red)':'none'}">${d}</div>`;}h+=`</div></div>`;document.getElementById('stat-calendar').innerHTML=h;}

// ══════════════════════════════════════════════════════
// PROFILE
// ══════════════════════════════════════════════════════
function renderProfile(){const u=APP.user||{};const GOAL_AR={muscle:'بناء العضلات 💪',fat_loss:'خسارة الدهون 🔥',strength:'زيادة القوة ⚡',endurance:'تحسين التحمل 🏃',recomp:'تحسين التناسق ⚖️',maintain:'المحافظة 🛡'};document.getElementById('prof-name').textContent=u.name||'المحارب';document.getElementById('prof-goal').textContent=GOAL_AR[u.goal]||'لياقة عامة';document.getElementById('prof-tw').textContent=APP.workouts.length;document.getElementById('prof-th').textContent=Math.round(APP.workouts.reduce((s,w)=>s+(w.duration||0),0)/60);const aiSub=document.getElementById('ai-key-row-sub');if(aiSub)aiSub.textContent=getGeminiKey()?'✅ مفتاحك مضاف ومفعّل':'⚠️ مطلوب لتفعيل المدرب الذكي';}
function saveProfile(){APP.user=APP.user||{};APP.user.name=document.getElementById('ep-name').value||APP.user.name;APP.user.age=parseInt(document.getElementById('ep-age').value)||APP.user.age;APP.user.height=parseFloat(document.getElementById('ep-ht').value)||APP.user.height;save();hideMo('mo-edit-profile');toast('✓ تم الحفظ');renderProfile();renderHome();}

// ══════════════════════════════════════════════════════
// CUSTOM PROGRAM
// ══════════════════════════════════════════════════════
let _editingPlanId=null,_viewingPlanId=null;
function openCustom(id){
  _editingPlanId=id||null;
  const cp=id?getPlanById(id):null;
  document.getElementById('cp-name').value=cp?.name||'';
  document.getElementById('cp-text').value=cp?.text||'';
  showMo('mo-custom');
}
function saveCustom(){
  const name=document.getElementById('cp-name').value.trim();
  const text=document.getElementById('cp-text').value.trim();
  if(!text)return toast('أدخل محتوى الجدول ✋','⚠️');
  APP.plans=APP.plans||[];
  const existing=_editingPlanId?getPlanById(_editingPlanId):null;
  if(existing){
    const textChanged=existing.text!==text;
    existing.name=name||existing.name||'جدولي المخصص';
    existing.text=text;
    if(textChanged)existing.parsed=null; // تغيّر النص يعني أن أي تحليل سابق لم يعد يطابقه
  }else{
    const newPlan={id:genPlanId(),type:'manual',name:name||'جدولي المخصص',text,parsed:null,isPrimary:true,createdAt:new Date().toISOString()};
    APP.plans.forEach(p=>p.isPrimary=false); // خطة يدخلها المستخدم بنفسه تصبح أساسية تلقائياً
    APP.plans.push(newPlan);
    _editingPlanId=newPlan.id;
  }
  save();hideMo('mo-custom');toast('✅ تم حفظ الجدول كخطة أساسية');
  renderCustomBanner();renderHome();
}
function viewCustom(id){
  const cp=getPlanById(id);
  if(!cp)return toast('لا يوجد جدول','⚠️');
  _viewingPlanId=id;
  document.getElementById('vc-t').textContent='📋 '+cp.name;
  document.getElementById('vc-b').textContent=cp.text||'(بدون نص أصلي — أُنشئت هذه الخطة مباشرة بالذكاء الاصطناعي)';
  showMo('mo-view-custom');
}
function copyCustomDirect(id){
  const cp=getPlanById(id||_viewingPlanId);
  if(!cp)return toast('لا يوجد جدول','⚠️');
  fallbackCopy(`📋 ${cp.name}\n\n${cp.text||''}`);toast('✅ تم النسخ!');
}
function shareCustom(id){
  const cp=getPlanById(id||_viewingPlanId);
  if(!cp)return;
  const txt=`📋 ${cp.name}\n\n${cp.text||''}\n\n— AC Fitness V2`;
  if(navigator.share)navigator.share({title:cp.name,text:txt}).catch(()=>{});else fallbackCopy(txt);
}
function editCustom(){const id=_viewingPlanId;hideMo('mo-view-custom');setTimeout(()=>openCustom(id),200);}
function delCustom(){const id=_viewingPlanId;if(!id)return;hideMo('mo-view-custom');deletePlan(id);}
async function pasteCustom(){
  try{
    if(!navigator.clipboard||!navigator.clipboard.readText){toast('المتصفح لا يدعم اللصق التلقائي — استخدم لصق يدوي (اضغط مطولاً)','⚠️');return;}
    const text=await navigator.clipboard.readText();
    if(!text||!text.trim()){toast('الحافظة فارغة','⚠️');return;}
    const ta=document.getElementById('cp-text');
    ta.value=ta.value?ta.value+'\n\n'+text.trim():text.trim();
    toast('✅ تم لصق المحتوى');
  }catch(e){toast('تعذّر الوصول للحافظة — الصق يدوياً بالضغط المطول','⚠️');}
}
function renderCustomBanner(){
  const wrap=document.getElementById('custom-banner');
  if(!wrap)return;
  const plans=APP.plans||[];
  if(!plans.length){wrap.style.display='none';wrap.innerHTML='';return;}
  wrap.style.display='block';
  const typeLabel=p=>p.type==='ai-onboarding'?'🤖 ذكاء اصطناعي':(p.parsed?'✅ يدوية — محلَّلة':'📝 يدوية — لم تُحلَّل بعد');
  wrap.innerHTML=`<div style="font-size:11px;font-weight:800;color:var(--b);margin-bottom:9px">📋 خططي (${plans.length})</div>`+
    plans.map(p=>{
      const needsAnalysis=p.isPrimary&&!p.parsed&&p.text;
      return`<div style="background:linear-gradient(135deg,#060614,#0e0e2a);border:1.5px solid ${p.isPrimary?'rgba(245,158,11,.4)':'rgba(59,130,246,.22)'};border-radius:14px;padding:11px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:18px;flex-shrink:0">${p.isPrimary?'⭐':'📋'}</span>
        <div style="min-width:0;flex:1"><div style="font-size:12px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(p.name)}</div><div style="font-size:11px;color:var(--w40)">${typeLabel(p)}${p.isPrimary?' · أساسية الآن':''}</div></div>
      </div>
      ${needsAnalysis?`<div style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.28);border-radius:9px;padding:8px 9px;margin-bottom:8px;font-size:11px;color:var(--y);line-height:1.7">⚠️ خطتك الأساسية، لكنها لن تعمل بعد — اضغط "🤖 حلّل" بالأسفل لتحويل النص إلى جدول فعلي. قبل ذلك، سيستخدم "ابدأ التمرين" برنامجك الجاهز مؤقتاً.</div>`:''}
      <div style="display:flex;gap:5px;flex-wrap:wrap">
        ${p.parsed?`<button onclick="renderPlanSchedule('${p.id}')" style="background:rgba(59,130,246,.17);border:1px solid rgba(59,130,246,.28);color:var(--b);border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">عرض الجدول</button>`:''}
        ${p.text?`<button onclick="viewCustom('${p.id}')" style="background:var(--w8);border:1px solid rgba(var(--wa),.09);color:var(--w60);border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">النص</button>`:''}
        ${!p.parsed&&p.text?`<button onclick="analyzeCustom('${p.id}')" style="background:${needsAnalysis?'rgba(245,158,11,.22)':'rgba(142,124,255,.16)'};border:1px solid ${needsAnalysis?'rgba(245,158,11,.4)':'rgba(142,124,255,.3)'};color:${needsAnalysis?'var(--y)':'var(--g)'};border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit" id="analyze-btn-${p.id}">🤖 حلّل${needsAnalysis?' الآن':''}</button>`:''}
        ${!p.isPrimary?`<button onclick="setPrimaryPlan('${p.id}')" style="background:rgba(245,158,11,.14);border:1px solid rgba(245,158,11,.26);color:var(--y);border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">⭐ اجعلها أساسية</button>`:''}
        <button onclick="deletePlan('${p.id}')" style="background:rgba(200,16,46,.14);border:1px solid rgba(200,16,46,.24);color:var(--red);border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit">🗑</button>
      </div>
    </div>`;
    }).join('');
}
function copyGenProgram(){copyProgram();}

// ══════════════════════════════════════════════════════
// AI ANALYSIS OF CUSTOM PROGRAM — turns free text into a
// structured weekly plan with day/exercise/sets/reps/rest,
// so the user can actually run their own program inside the
// tracker exactly like a generated one.
// ══════════════════════════════════════════════════════
const CUSTOM_DAY_KEYS=['ahad','ithnin','thulatha','arbaa','khamis','jumua','sabt'];
const CUSTOM_DAY_AR={ahad:'الأحد',ithnin:'الإثنين',thulatha:'الثلاثاء',arbaa:'الأربعاء',khamis:'الخميس',jumua:'الجمعة',sabt:'السبت'};
const PHASE_LABELS={
  warmup:{label:'🔥 إحماء',color:'var(--y)',desc:'حضّر عضلاتك قبل الأساسي'},
  main:{label:'💪 التمارين الأساسية',color:'var(--red)',desc:''},
  cooldown:{label:'🧘 تمدد وتبريد',color:'var(--b)',desc:'بعد انتهاء التمرين'}
};
// للبرامج الجاهزة (غير المخصصة بالذكاء الاصطناعي) لا يوجد تصنيف لكل تمرين على
// حدة، فنعرض بطاقة إحماء/تبريد عامة من محتوى Prehab المُعَدّ مسبقاً بدل ترك
// المستخدم بلا أي إرشاد إحماء أو تمدد إطلاقاً.
function renderPhaseCard(type){
  const items=(PREHAB[type]||[]).slice(0,4);
  if(!items.length)return'';
  const isWarmup=type==='warmup';
  return`<div style="background:${isWarmup?'rgba(245,158,11,.06)':'rgba(59,130,246,.06)'};border:1px solid ${isWarmup?'rgba(245,158,11,.2)':'rgba(59,130,246,.2)'};border-radius:13px;padding:11px 13px;margin:${isWarmup?'0 0 12px':'12px 0 0'}">
    <div style="display:flex;align-items:center;gap:7px;margin-bottom:8px">
      <span style="font-size:15px">${isWarmup?'🔥':'🧘'}</span>
      <span style="font-size:12px;font-weight:800;color:${isWarmup?'var(--y)':'var(--b)'}">${isWarmup?'إحماء مقترح قبل البدء':'تمدد مقترح بعد الانتهاء'}</span>
      <span onclick="showPg('prehab')" style="font-size:11px;color:var(--w40);margin-right:auto;text-decoration:underline;cursor:pointer">المزيد ←</span>
    </div>
    <div style="display:flex;flex-direction:column;gap:6px">
      ${items.map(it=>`<div style="display:flex;align-items:center;gap:8px;font-size:11px"><span>${it.ico}</span><span style="flex:1;color:var(--w75)">${it.name}</span><span style="color:var(--w40);font-size:11px">${it.time}</span></div>`).join('')}
    </div>
  </div>`;
}

// يحوّل نص استجابة من الذكاء الاصطناعي (يُفترض أنه JSON لخطة أسبوعية) إلى
// كائن، مع محاولة إصلاح أي JSON مقطوع/غير مكتمل. يُستخدم من تحليل البرنامج
// المخصص ومن بناء الخطة الذكية عند التسجيل معاً، لتفادي تكرار نفس المنطق.
function parseAiProgramJson(raw){
  raw=(raw||'').trim().replace(/^```json\s*/i,'').replace(/^```\s*/,'').replace(/```\s*$/,'').trim();
  if(!raw)throw new Error('لم يُرجِع الذكاء الاصطناعي أي محتوى — حاول مجدداً');
  let parsed;
  try{
    parsed=JSON.parse(raw);
  }catch(parseErr){
    const firstBrace=raw.indexOf('{');
    if(firstBrace===-1)throw new Error('لا يوجد JSON في الاستجابة');
    let r=raw.slice(firstBrace);
    const cps=[r.lastIndexOf('}]'),r.lastIndexOf('},'),r.lastIndexOf('}')].filter(x=>x>0);
    if(cps.length)r=r.slice(0,Math.max(...cps)+1);
    r=r.replace(/,\s*"[^"]*"\s*:\s*"[^"]*$/,'')
       .replace(/,\s*"[^"]*"\s*:\s*[^,}\]]*$/,'')
       .replace(/,\s*"[^"]*"\s*:\s*$/,'')
       .replace(/,\s*"[^"]*"?\s*$/,'')
       .replace(/,\s*\{[^}]*$/,'')
       .replace(/,\s*$/,'');
    const ob=(r.match(/{/g)||[]).length,cb=(r.match(/}/g)||[]).length;
    const oa=(r.match(/\[/g)||[]).length,ca=(r.match(/\]/g)||[]).length;
    r+=']'.repeat(Math.max(0,oa-ca))+'}'.repeat(Math.max(0,ob-cb));
    try{parsed=JSON.parse(r);}catch(e2){throw new Error('تعذّر فهم استجابة الذكاء الاصطناعي — حاول مجدداً');}
  }
  if(!parsed.days||!Array.isArray(parsed.days)||!parsed.days.length)throw new Error('لم يتم استخراج أي أيام تدريب — حاول مجدداً');
  return parsed;
}

async function analyzeCustom(id){
  const cp=getPlanById(id);
  if(!cp||!cp.text||!cp.text.trim()){toast('لا يوجد جدول لتحليله','⚠️');return;}
  const btn=document.getElementById('analyze-btn-'+id);
  if(btn){btn.disabled=true;btn.innerHTML='⏳ جاري التحليل...';}
  toast('🤖 يحلل الذكاء الاصطناعي برنامجك...','⏳');
  const sys=`أنت محلل برامج تدريبية رياضية محترف. مهمتك تحويل نص برنامج تدريبي حر (قد يكون بالعربية أو الإنجليزية أو مختلطاً، وقد يكون منظماً أو فوضوياً، وقد يحتوي كلمات أو جملاً إضافية حول التمارين) إلى JSON منظم يمثل خطة أسبوعية كاملة، مع استخراج كل تمرين مذكور في النص ولو ضمن جملة طويلة.

القواعد:
- اقرأ النص كاملاً كلمة كلمة. استخرج كل تمرين مذكور، حتى لو كان مدمجاً داخل جملة وصفية وليس بصيغة قائمة منظمة.
- أرجع JSON فقط، بدون أي نص قبله أو بعده، بدون Markdown fences.
- بنية الإخراج:
{
  "days": [
    {
      "dayKey": "ithnin",  // أحد المفاتيح: ahad,ithnin,thulatha,arbaa,khamis,jumua,sabt — استنتج اليوم من النص إن أمكن، وإلا وزّع الأيام بالترتيب على أيام تدريب منطقية مع ترك أيام راحة
      "isRest": false,
      "title": "صدر + كتفين",  // عنوان مختصر لليوم
      "exercises": [
        {"name":"دوران الكتفين","nameEn":"Shoulder Circles","phase":"warmup","sets":1,"repsLo":15,"repsHi":15,"restSeconds":0,"notes":"","isPrimary":false},
        {"name":"بنش بريس","nameEn":"Bench Press","phase":"main","sets":4,"repsLo":6,"repsHi":10,"restSeconds":120,"notes":"","isPrimary":true},
        {"name":"تمديد الصدر","nameEn":"Pec Stretch","phase":"cooldown","sets":1,"repsLo":45,"repsHi":45,"restSeconds":0,"notes":"","isPrimary":false}
      ]
    }
  ],
  "summary": {
    "totalTrainingDays": 4,
    "totalRestDays": 3,
    "warnings": ["أي ملاحظات علمية — مثلاً عدم وجود راحة كافية بين تمارين نفس العضلة، أو حجم تدريبي غير متوازن"],
    "recommendations": ["توصيات قصيرة لتحسين البرنامج علمياً حسب NSCA/ACSM"]
  }
}

- كل تمرين يحمل حقل "phase" إلزامياً: "warmup" (إحماء) أو "main" (تمرين قوة أساسي) أو "cooldown" (إطالة/تبريد).
- صنّف حسب ما هو مذكور فعلياً في النص: إذا وصف المستخدم تمريناً بأنه إحماء أو تسخين، اجعل phase:"warmup". إذا ذكر إطالة أو تمديد أو تبريد بعد التمرين، اجعل phase:"cooldown". غير ذلك (تمارين القوة/المقاومة الرئيسية) اجعلها phase:"main".
- لا تخترع تمارين إحماء أو إطالة غير مذكورة في النص الأصلي — فقط صنّف ما ذُكر فعلاً. إذا لم يذكر النص أي إحماء أو تبريد إطلاقاً، اجعل كل التمارين المستخرجة phase:"main" فقط، وأضف في summary.recommendations توصية بإضافة إحماء ديناميكي قبل التمرين وإطالات بعده.

- "isPrimary": true يُعطى لتمرين واحد فقط من تمارين phase:"main" في كل يوم تدريب — وهو التمرين الأساسي/الرئيسي لليوم (عادة أول تمرين مركّب مذكور، أو التمرين الذي يحمل أعلى وزن/أهمية في النص، أو الذي وصفه المستخدم بكلمات مثل "أساسي"، "رئيسي"، "main"، "الأهم"). لا تضعها أبداً على تمارين warmup أو cooldown. باقي تمارين نفس اليوم isPrimary:false.
- استنتج عدد المجموعات والتكرارات من النص (مثل "4×8" يعني 4 مجموعات و8 تكرارات، اجعل repsLo=repsHi=8 في هذه الحالة، أو إن كُتب "8-12" فاجعل repsLo=8,repsHi=12).
- ⚠️ إلزامي: أي رقم كتبه المستخدم صراحةً (مجموعات، تكرارات، أو راحة بالثواني/الدقائق) يجب نقله كما هو بالضبط دون أي تغيير أو "تصحيح علمي" — لا تستبدل رقماً محدَّداً براحته أو تكراره الخاص برأيك حتى لو بدا مختلفاً عمّا تراه مثالياً. التعديل العلمي المسموح به فقط في summary.recommendations كنص منفصل، وليس بتغيير الأرقام نفسها.
- إذا لم يُذكر وقت راحة إطلاقاً لتمرين معيّن، استنتج قيمة معقولة علمياً حسب نوع التمرين (مركّب=90-180 ثانية، عزل=45-90 ثانية) — هذا الاستنتاج فقط للحالات غير المذكورة، لا كبديل لرقم ذكره المستخدم بنفسه.
- إذا ذُكر يوم "راحة" أو لم يُذكر شيء لبعض الأيام، اجعل isRest=true وexercises=[].
- يجب أن يكون الأسبوع كاملاً قدر الإمكان (املأ الأيام غير المذكورة كأيام راحة إن كان عدد أيام التدريب المذكورة أقل من 7).
- لا تخترع تمارين غير مذكورة في النص الأصلي، فقط استخرج ونظّم ما هو موجود فعلياً، حتى التمارين المذكورة بشكل عابر ضمن الجمل.
- قد يكون النص المُدخل نفسه أسلوباً محادثاتياً (مثلاً منسوخاً من محادثة مع ذكاء اصطناعي آخر، يتضمن عبارات مثل "معك حق" أو "بناءً على مستواك...")؛ في هذه الحالة تجاهل الإطار المحادثاتي واستخرج فقط المعلومات التدريبية الفعلية (التمارين، المجموعات، التكرارات) الموجودة داخله.
- تذكير أخير حاسم: ردّك بالكامل يجب أن يكون JSON صالحاً فقط — أول حرف في ردّك يجب أن يكون { وآخر حرف يجب أن يكون }. لا تكتب أي مقدمة مثل "بالتأكيد" أو "إليك التحليل"، ولا أي خاتمة أو تعليق بعد الـJSON، ولا Markdown fences من أي نوع.`;
  const userMsg=`حلّل هذا البرنامج التدريبي وحوّله لـ JSON منظم حسب التعليمات:\n\n${cp.text}`;
  try{
    const data=await callAI(sys,[{role:'user',content:userMsg}],16000);
    if(data?.error){throw new Error(data.error.message||'خطأ غير معروف');}
    const raw=extractApiText(data);
    const parsed=parseAiProgramJson(raw);
    cp.parsed=parsed;
    cp.analyzedAt=new Date().toISOString();
    save();
    toast('✅ تم تحليل البرنامج بنجاح!');
    renderCustomBanner();
    renderPlanSchedule(id);
  }catch(e){
    console.error(e);
    toast('⚠️ '+(e.message||'تعذّر التحليل — حاول مجدداً'),'⚠️');
  }finally{
    if(btn){btn.disabled=false;btn.innerHTML='🤖 حلّل برنامجي بالذكاء الاصطناعي';}
  }
}

function renderPlanSchedule(planId){
  const wrap=document.getElementById('custom-analyzed-wrap');
  if(!wrap)return;
  const cp=getPlanById(planId);
  if(!cp||!cp.parsed){wrap.style.display='none';wrap.innerHTML='';return;}
  const p=cp.parsed;
  const trainCount=p.days.filter(d=>!d.isRest).length;
  const restCount=p.days.filter(d=>d.isRest).length;
  let h=`<div class="card" style="margin-bottom:0">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px">
      <div style="font-size:13px;font-weight:800;color:var(--b)">${cp.type==='ai-onboarding'?'🤖':'📋'} ${escapeHtml(cp.name)}</div>
      <button onclick="document.getElementById('custom-analyzed-wrap').style.display='none'" style="background:var(--w8);border:none;color:var(--w60);border-radius:8px;padding:5px 9px;font-size:11px;cursor:pointer">✕</button>
    </div>
    <div style="display:flex;gap:6px;margin-bottom:10px;flex-wrap:wrap">
      <span style="font-size:11px;background:rgba(200,16,46,.16);color:var(--red);padding:3px 9px;border-radius:10px;font-weight:700">🏋️ ${trainCount} أيام تدريب</span>
      <span style="font-size:11px;background:rgba(34,197,94,.16);color:var(--g);padding:3px 9px;border-radius:10px;font-weight:700">😴 ${restCount} أيام راحة</span>
    </div>`;
  // Quick summary of the primary/main exercise extracted for each training day
  const primaryRows=p.days.filter(d=>!d.isRest&&d.exercises?.length).map((d,di)=>{
    const realIdx=p.days.indexOf(d);
    const primary=d.exercises.find(ex=>ex.isPrimary)||d.exercises[0];
    const dayLabel=CUSTOM_DAY_AR[d.dayKey]||d.title||('يوم '+(realIdx+1));
    return {dayLabel,primary};
  });
  if(primaryRows.length){
    h+=`<div style="background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.22);border-radius:9px;padding:10px;margin-bottom:9px">
      <div style="font-size:11px;font-weight:800;color:var(--y);margin-bottom:7px">⭐ التمرين الأساسي لكل يوم</div>
      ${primaryRows.map(r=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 0;font-size:11px"><span style="color:var(--w60)">${r.dayLabel}</span><span style="font-weight:700;color:var(--w)">${r.primary?.name||'—'}</span></div>`).join('')}
    </div>`;
  }
  if(p.summary?.warnings?.length){
    h+=`<div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.22);border-radius:9px;padding:9px;margin-bottom:9px"><div style="font-size:11px;font-weight:800;color:var(--y);margin-bottom:5px">⚠️ ملاحظات علمية</div><div style="font-size:11px;color:var(--w60);line-height:1.8">${p.summary.warnings.map(w=>'• '+w).join('<br>')}</div></div>`;
  }
  if(p.summary?.recommendations?.length){
    h+=`<div style="background:rgba(59,130,246,.07);border:1px solid rgba(59,130,246,.2);border-radius:9px;padding:9px;margin-bottom:11px"><div style="font-size:11px;font-weight:800;color:var(--b);margin-bottom:5px">💡 توصيات للتحسين</div><div style="font-size:11px;color:var(--w60);line-height:1.8">${p.summary.recommendations.map(r=>'• '+r).join('<br>')}</div></div>`;
  }
  h+=`</div>`;
  const bgC=['#1a0508','#0a1205','#0a0a1a','#1a0f00','#100F26','#1a1500'];
  p.days.forEach((day,di)=>{
    const dayLabel=CUSTOM_DAY_AR[day.dayKey]||day.title||('يوم '+(di+1));
    if(day.isRest||!day.exercises?.length){
      h+=`<div style="background:rgba(34,197,94,.05);border:1px dashed rgba(34,197,94,.26);border-radius:13px;margin-top:8px;padding:11px 13px;display:flex;align-items:center;gap:10px"><span style="font-size:19px">😴</span><div><div style="font-size:12px;font-weight:800;color:var(--g)">${dayLabel} — راحة</div></div></div>`;
      return;
    }
    // ترتيب حسب المرحلة (إحماء ← أساسي ← تبريد)، والتمرين الأساسي يتصدّر مجموعته.
    const phaseOrder={warmup:0,main:1,cooldown:2};
    const sortedEx=[...day.exercises].sort((a,b)=>{
      const pa=phaseOrder[a.phase]??1,pb=phaseOrder[b.phase]??1;
      if(pa!==pb)return pa-pb;
      return(b.isPrimary?1:0)-(a.isPrimary?1:0);
    });
    const hasPhaseTags=day.exercises.some(e=>e.phase&&e.phase!=='main');
    h+=`<div class="day-card" style="background:${bgC[di%6]};margin-top:8px">
      <div class="day-hdr" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'block':'none'">
        <div><div class="day-name" style="color:var(--red)">${dayLabel}${day.title?' — '+day.title:''}</div></div>
        <div style="text-align:center"><div style="font-size:11px;color:var(--w40)">${day.exercises.length} تمرين</div><button class="btn btn-p btn-sm" style="margin-top:4px;padding:4px 10px;font-size:11px" onclick="event.stopPropagation();startCustomDayWk('${planId}',${di})">▶ ابدأ</button></div>
      </div>
      <div class="day-body">
      ${sortedEx.map((ex,exi)=>{
        const repStr=ex.repsLo&&ex.repsHi&&ex.repsLo!==ex.repsHi?`${ex.repsLo}-${ex.repsHi}`:(ex.repsLo||ex.repsHi||'—');
        const rest=ex.restSeconds||90;
        const curPhase=ex.phase||'main';
        const prevPhase=exi>0?(sortedEx[exi-1].phase||'main'):null;
        const phaseRow=(hasPhaseTags&&curPhase!==prevPhase)?`<div style="font-size:11px;font-weight:800;color:${PHASE_LABELS[curPhase].color};margin:${exi>0?'8px':'0'} 0 4px;padding-bottom:3px;border-bottom:1px solid rgba(var(--wa),.07)">${PHASE_LABELS[curPhase].label}</div>`:'';
        const ico=curPhase==='warmup'?'🔥':curPhase==='cooldown'?'🧘':(ex.isPrimary?'⭐':'🏋️');
        return `${phaseRow}<div class="day-ex-row" style="${ex.isPrimary?'background:rgba(245,158,11,.06);border-radius:8px;padding:6px 7px;margin:-1px -2px 2px':''}">
          <span style="font-size:17px">${ico}</span>
          <div style="flex:1"><div class="ex-name">${ex.name}${ex.isPrimary?' <span style="color:var(--y);font-size:11px;font-weight:800">(أساسي)</span>':''}${ex.nameEn?` <span style="color:var(--w40);font-size:11px">(${ex.nameEn})</span>`:''}</div>${ex.notes?`<div class="ex-meta">${ex.notes}</div>`:''}</div>
          <div style="text-align:center"><div style="font-size:11px;font-weight:800;color:var(--red)">${ex.sets||3}×${repStr}</div><div style="font-size:11px;color:var(--w40)">${rest}ث راحة</div></div>
        </div>`;
      }).join('')}
      </div>
    </div>`;
  });
  wrap.innerHTML=h;
  wrap.style.display='block';
  wrap.scrollIntoView({behavior:'smooth',block:'start'});
}

function startCustomDayWk(planId,di){
  const cp=getPlanById(planId);
  if(!cp?.parsed?.days?.[di])return;
  const day=cp.parsed.days[di];
  if(day.isRest||!day.exercises?.length){toast('😴 هذا يوم راحة','💤');return;}
  // ترتيب حسب المرحلة أولاً (إحماء ← أساسي ← إطالة)، ثم التمرين الأساسي
  // يتصدّر مجموعة "الأساسي" تحديداً.
  const phaseOrder={warmup:0,main:1,cooldown:2};
  const sortedEx=[...day.exercises].sort((a,b)=>{
    const pa=phaseOrder[a.phase]??1,pb=phaseOrder[b.phase]??1;
    if(pa!==pb)return pa-pb;
    return(b.isPrimary?1:0)-(a.isPrimary?1:0);
  });
  APP.activeWorkout={
    id:Date.now(),
    name:(CUSTOM_DAY_AR[day.dayKey]||day.title||'تمرين مخصص')+(day.title?' — '+day.title:''),
    startTime:Date.now(),
    date:new Date().toISOString(),
    sourcePlanId:planId,
    exercises:sortedEx.map(ex=>{
      const phase=ex.phase||'main';
      // Try to reconnect this free-text exercise name to a real database
      // entry — this is what makes timed exercises (plank, shadowboxing...)
      // actually get their countdown UI, icon, and guidance instead of
      // silently falling back to a generic weighted-set row.
      const matchedId=matchExerciseId(ex.name);
      const dbEx=matchedId?EX[matchedId]:null;
      // تمارين الإحماء/الإطالة تُعامَل كتمارين مؤقتة دائماً (بلا وزن) — لا
      // معنى لتتبّع "وزن" لدوران الكتفين أو إطالة ثابتة.
      const isTimed=phase==='warmup'||phase==='cooldown'||!!(dbEx&&dbEx.isTimed)||looksLikeTimedHold(ex.name);
      // numOr يحافظ على القيمة إن كانت رقماً صحيحاً حتى لو كانت 0 (بعكس ||
      // الذي كان يستبدل أي "0" بالقيمة الاحتياطية بالخطأ — مهم خصوصاً أن
      // تمارين الإحماء/التبريد تُرسَل عمداً بـ restSeconds:0).
      const numOr=(v,fb)=>(typeof v==='number'&&!isNaN(v))?v:fb;
      const setCount=numOr(ex.sets,1);
      const sets=isTimed
        ? Array.from({length:setCount},()=>({duration:numOr(ex.repsLo,numOr(dbEx?.lo,phase==='cooldown'?45:20)),remaining:null,done:false,running:false}))
        : Array.from({length:setCount},()=>({weight:'',reps:numOr(ex.repsLo,numOr(ex.repsHi,10)),rest:numOr(ex.restSeconds,numOr(dbEx?.rest,90)),done:false}));
      return{id:matchedId,sciId:matchedId,name:ex.name,nameEn:ex.nameEn||null,phase,isPrimary:!!ex.isPrimary,sets};
    })
  };
  save();showPg('tracker');renderTracker();startWtTimer();toast('🏋️ '+(day.title||'بدأ التمرين'));
}

// ══════════════════════════════════════════════════════
// AI COACH
// ══════════════════════════════════════════════════════
let chatHist=[],aiLoading=false;
const SUGGS=['💪 تمارين الصدر','🥊 تمارين الملاكمة','🔥 خسارة الدهون','🥩 البروتين','😴 النوم','📈 التقدم التدريبي'];
const LOCAL_AI={'صدر':()=>'تمارين الصدر الأفضل:\n**جيم:** بنش بريس (4×6-10) • إنكلاين (3×10-12) • كابل فلاي (3×12-15)\n**منزل:** بوش آب (4×20) • ديبس • دايموند بوش آب','ظهر':()=>'تمارين الظهر:\n**أساس:** ديدليفت (3×5) • بول آب (4×max)\n**جيم:** لات بوللداون • كابل رو\n**منزل:** إنفيرتد رو • دامبل رو','ملاكمة':()=>'تدريب القوة للملاكمة:\n**قوة الضربة:** بوش آب انفجاري • ميديسن بول\n**أرجل:** سكوات انفجاري • لانج\n**بطن:** بلانك • ليج ريز\n**شادو بوكسينج:** 5 جولات × 3 دقائق','دامبل':(q)=>{const m=q.match(/(\d+)/);return`مع دامبل ${m?m[1]:'?'} كغ:\n• دامبل برس: 3×12\n• دامبل رو: 3×12\n• دامبل كيرل: 3×15\n• غوبليت سكوات: 3×15\n• هامر كيرل: 3×15`;},'خسار':()=>'خسارة الدهون علمياً (ISSN 2017):\n• عجز 300-500 سعرة/يوم فقط\n• بروتين 2.2-2.4 غ/كغ\n• تمارين قوة 3-4× + كارديو اختياري\n• نوم 8+ ساعات — الكورتيزول يخزن الدهون!','بروتين':()=>'البروتين (Stokes et al. 2018):\n• **بناء عضلات:** 2.0 غ/كغ\n• **خسارة دهون:** 2.4 غ/كغ\n• مصادر: دجاج، تونة، بيض، عدس، قريش\n• بعد التمرين: 25-40 غ خلال 30-60 دقيقة','نوم':()=>'النوم والأداء الرياضي:\n• 7-9 ساعات — ضرورة لا رفاهية\n• 70% من هرمون النمو يُفرز في النوم العميق\n• قلة النوم ترفع الكورتيزول وتهدم العضلة\n• نصيحة: أغلق الشاشات قبل ساعة من النوم','تقدم':()=>'Double Progression (للمتوسط):\n• ابدأ بـ 8 تكرارات\n• عندما تصل لـ 12 في كل المجموعات\n• زد الوزن 2.5 كغ وابدأ من جديد\n• **أفضل** من زيادة أسبوعية ثابتة','deload':()=>'Deload كل 4-8 أسابيع:\n• خفض الوزن 40%\n• خفض المجموعات 40%\n• حافظ على الأيام\n• نم أكثر وارفع البروتين\n• لا تقفز للتدريب الثقيل قبل راحة كافية'};
function initChat(){document.getElementById('chat-suggs').innerHTML=SUGGS.map(s=>`<div class="chip" onclick="sendSugg('${s}')" style="flex-shrink:0">${s}</div>`).join('');if(!chatHist.length)addMsg(`أهلاً ${APP.user?.name||''}! 💪 أنا مدرب AC الذكي. مبني على NSCA · ACSM · ISSN. أسألني عن التمارين، التغذية، التقدم، Prehab، أو أي شيء رياضي!`,'ai');}
function escapeHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
// ردود Gemini أحياناً تستخدم عناوين ### وفواصل --- بأسلوب Markdown كامل، لا
// **bold** فقط — بدون هذا التحويل تظهر كنص خام (#, -) بدل تنسيق حقيقي.
function formatChatMarkdown(txt){
  const escaped=escapeHtml(txt||'');
  const lines=escaped.split('\n');
  const out=[];
  for(const line of lines){
    const t=line.trim();
    const h=t.match(/^(#{1,3})\s+(.*)$/);
    if(h){out.push(`<div style="font-weight:800;font-size:${h[1].length===1?13:12}px;margin:6px 0 4px">${h[2]}</div>`);continue;}
    if(/^-{3,}$/.test(t)){out.push('<div style="height:1px;background:rgba(var(--wa),.14);margin:8px 0"></div>');continue;}
    out.push(line);
  }
  return out.join('<br>')
    .replace(/\*\*(.*?)\*\*/g,'<b>$1</b>')
    .replace(/<br>(<div)/g,'$1')
    .replace(/(<\/div>)<br>/g,'$1');
}
function addMsg(txt,role){const c=document.getElementById('chat-msgs');const d=document.createElement('div');d.className='msg';d.style.cssText=`max-width:86%;${role==='ai'?'background:var(--b3);border:1px solid rgba(255,255,255,.06);border-radius:13px 13px 13px 3px;padding:10px 12px;align-self:flex-start':'background:var(--red);border-radius:13px 13px 3px 13px;padding:10px 12px;align-self:flex-end;text-align:right'}`;const safe=formatChatMarkdown(txt);d.innerHTML=`<div style="font-size:12px;line-height:1.65">${safe}</div><div style="font-size:11px;color:rgba(var(--wa),.35);margin-top:3px">${new Date().toLocaleTimeString('ar-SA',{hour:'2-digit',minute:'2-digit'})}</div>`;c.appendChild(d);c.scrollTop=c.scrollHeight;}
async function sendMsg(){
  const inp=document.getElementById('chat-inp');
  const msg=inp.value.trim();
  if(!msg||aiLoading)return;
  inp.value='';
  addMsg(msg,'user');
  chatHist.push({role:'user',content:msg});
  const td=document.createElement('div');
  td.id='td';
  td.style.cssText='display:flex;gap:4px;padding:10px 12px;background:var(--b3);border-radius:13px;align-self:flex-start;width:fit-content';
  td.innerHTML='<span style="animation:pulse 1.2s infinite;width:5px;height:5px;background:var(--w40);border-radius:50%;display:inline-block"></span>'.repeat(3);
  if(!document.getElementById('chat-pulse-style')){
    const st=document.createElement('style');st.id='chat-pulse-style';
    st.textContent='@keyframes pulse{0%,80%,100%{transform:scale(.8);opacity:.5}40%{transform:scale(1);opacity:1}}';
    document.head.appendChild(st);
  }
  document.getElementById('chat-msgs').appendChild(td);
  document.getElementById('chat-msgs').scrollTop=99999;
  aiLoading=true;
  APP.aiMsgs=(APP.aiMsgs||0)+1;
  save();
  let reply;
  // كل رسالة تصل الآن إلى Gemini فعلياً — كان هناك نظام ردود جاهزة يعترض
  // كلمات شائعة (بروتين، نوم، تقدم...) ويمنعها من الوصول للذكاء الاصطناعي
  // إطلاقاً، وهذا بالضبط ما جعل المحادثة تبدو آلية ومكرّرة بدل شعورها كأنها
  // Gemini حقيقي. تمت إزالته بالكامل.
  {
    const u=APP.user||{};
    const primSp=SPORTS.find(s=>s.id===u.primarySport);
    const wkCount=APP.workouts.length;
    const streak=calcStreak(APP.workouts);
    const lastWt=APP.weights.length?APP.weights[APP.weights.length-1].value:null;
    const sys=`أنت "مدرب AC" — مدرب رياضي شخصي ذكي متخصص، تتحدث العربية بطلاقة وتستخدم مصطلحات رياضية عربية صحيحة.

معايير علمية: NSCA · ACSM · ISSN · Schoenfeld · Israetel (RP Strength)

معلومات المستخدم الحالية:
- الاسم: ${u.name||'المستخدم'}
- الهدف: ${({muscle:'بناء العضلات',fat_loss:'خسارة الدهون',strength:'زيادة القوة',endurance:'تحسين التحمل',recomp:'تحسين التناسق',maintain:'المحافظة'}[u.goal])||'غير محدد'}
- المستوى: ${({beginner:'مبتدئ',intermediate:'متوسط',advanced:'متقدم'}[u.level])||'غير محدد'}
- الرياضة الأساسية: ${primSp?.name||'غير محددة'}
- إجمالي التمارين المسجلة: ${wkCount}
- السلسلة الحالية: ${streak} يوم
${lastWt?'- آخر وزن مسجل: '+lastWt+' كغ':''}
${u.tdee?'- TDEE: '+u.tdee+' سعرة | هدف: '+u.calories+' سعرة':''}
${todayCtx()}

أسلوب الردود:
- اكتب بالعربية العامية المفهومة، مع المصطلحات الإنجليزية الرياضية عند الحاجة
- تحدّث بأسلوب طبيعي ومتدفق كمحادثة حقيقية — لا تفرض نفس القالب (نقاط دائماً) على كل رد. استخدم نقاطاً عند سرد عناصر متعددة (تمارين، خطوات)، ونثراً عادياً عند الشرح أو النقاش
- الطول يتناسب مع السؤال فعلياً: رد قصير لسؤال بسيط، وتفصيل أوسع لسؤال معقّد يستحق ذلك — لا تُقصّر رداً يحتاج تفصيلاً فقط بحجة الاختصار، ولا تُطِل رداً بسيطاً
- استخدم **bold** للمصطلحات المهمة والأرقام عند الحاجة
- إذا سأل عن تمرين: أعطِ التقنية الصحيحة + الأخطاء الشائعة + البدائل
- إذا سأل عن تغذية: أعطِ أرقاماً محددة مبنية على وزنه وهدفه
- إذا سأل عن برنامج: ابنِ برنامجاً واضحاً بالأيام والمجموعات والتكرارات
- إذا شعرت بتعب أو ألم: أعطِ نصيحة Deload أو راحة محددة
- لا تكرر السؤال ولا تقل "سؤال رائع" — اذهب للإجابة مباشرة
- إن حاد النقاش قليلاً عن الرياضة، جاوب بشكل طبيعي كمحاور حقيقي بدل رفض الموضوع — أنت مدرب يتحدث مع صديقه، لا سكربت مقيّد بكلمات مفتاحية

قاعدة البرنامج: عند أي سؤال عن تمارين اليوم أو الإطالة أو الإحماء أو التبريد أو الراحة اعتمد حصراً على «برنامج اليوم الفعلي» أعلاه (أسماء التمارين وعضلاتها)؛ إن لم يتوفر فاسأل المستخدم عن تمرينه ولا تفترض يوماً أو برنامجاً من عندك.

قواعد السلامة (إلزامية): أنت لست طبيباً ولا تشخّص. عند ذكر ألم في الصدر أو دوخة أو إغماء أو ضيق نفس أو ألم حاد أو إصابة أو حمل أو أمراض مزمنة أو أدوية: انصح بمراجعة الطبيب قبل التمرين. لا تقترح أقل من 1200 سعرة للنساء و1500 للرجال، ولا أي عجز سعرات لمن هم دون 18 سنة، ولا صياماً قاسياً أو أساليب تجفيف. إذا ظهرت علامات اضطراب أكل أو إيذاء للنفس فاعتذر بلطف ووجّه لطلب مساعدة مختص.`;
    try{
      const data=await callAI(sys,chatHist.slice(-10),2500);
      if(data?.error)throw new Error(data.error.message);
      reply=extractApiText(data)||'عذراً، حدث خطأ في الاستجابة.';
    }catch(e){
      reply='⚠️ '+(e.message||'تعذّر الاتصال بالمدرب الذكي.')+'\n\nتأكد من اتصالك بالإنترنت ثم حاول مجدداً.';
    }
  }
  document.getElementById('td')?.remove();
  addMsg(reply,'ai');
  chatHist.push({role:'assistant',content:reply});
  aiLoading=false;
}
function sendSugg(t){document.getElementById('chat-inp').value=t;sendMsg();}
function clearChat(){chatHist=[];document.getElementById('chat-msgs').innerHTML='';addMsg('تم المسح. كيف يمكنني مساعدتك؟ 💪','ai');}

// ══════════════════════════════════════════════════════
// NAVIGATION
// ══════════════════════════════════════════════════════
const PG_MAP={home:0,programs:1,tracker:2,ai:3,challenges:4};
function showPg(id){
  document.querySelectorAll('.pg').forEach(p=>p.classList.remove('on'));
  document.querySelectorAll('.ni').forEach(n=>n.classList.remove('on'));
  const p=document.getElementById('pg-'+id);if(p)p.classList.add('on');
  if(PG_MAP[id]!==undefined)document.querySelectorAll('.ni')[PG_MAP[id]]?.classList.add('on');
  const renders={home:renderHome,programs:renderPrograms,tracker:renderTracker,ai:initChat,challenges:renderChallenges,measurements:renderMeas,stats:renderStats,profile:()=>{renderProfile();renderInstallCard();document.getElementById('ep-name').value=APP.user?.name||'';document.getElementById('ep-age').value=APP.user?.age||'';document.getElementById('ep-ht').value=APP.user?.height||'';},prehab:renderPrehab,progress:renderProgress,achievements:renderAchievements};
  renders[id]?.();window.scrollTo(0,0);
}
function showMo(id){document.getElementById(id)?.classList.add('on');if(id==='mo-add-ex')filterAddEx('');}
function hideMo(id){document.getElementById(id)?.classList.remove('on');}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.mo').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('on');}));});
let _tt;
function toast(msg,ico='✓'){document.getElementById('toast-txt').textContent=msg;document.getElementById('toast-ico').textContent=ico;document.getElementById('toast').classList.add('on');clearTimeout(_tt);_tt=setTimeout(()=>document.getElementById('toast').classList.remove('on'),2400);}
function shake(id){const e=document.getElementById(id);if(!e)return;e.style.animation='none';requestAnimationFrame(()=>{e.style.animation='shake .32s ease';});}
function fallbackCopy(txt){const ta=document.createElement('textarea');ta.value=txt;ta.style.cssText='position:fixed;opacity:0;top:0;right:0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast('✅ تم النسخ!');}catch{toast('افتح في متصفح للنسخ','⚠️');}document.body.removeChild(ta);}
function exportData(){const b=new Blob([JSON.stringify(APP,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='ac-fitness-v2.json';a.click();try{localStorage.setItem('acfv2_lastExport',String(Date.now()));}catch(e){}toast('✓ تم التصدير');}
function importData(inp){const f=inp.files[0];if(!f)return;if(f.size>5e6){toast('الملف كبير جداً','⚠️');return;}const r=new FileReader();r.onload=e=>{try{Object.assign(APP,safeImport(JSON.parse(e.target.result)));save();toast('✓ تم الاستيراد');renderAll();}catch{toast('خطأ في الملف','⚠️');}};r.readAsText(f);}
function resetApp(){APP={user:null,weights:[],measurements:[],workouts:[],water:{},activeWorkout:null,challenges:{},customProgram:null,fatigue:{},dailyNotes:{},_wtTimer:null,_restTimer:null,_restSecs:90};save();location.reload();}
function renderAll(){renderHome();renderPrograms();renderChallenges();renderMeas();}

// ══════════════════════════════════════════════════════
// INIT
// ══════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════
// PWA INSTALL — "Add to Home Screen" support.
// Android/Chrome fires beforeinstallprompt so we can show a native-style
// install button. iOS Safari doesn't support that API at all, so we detect
// iOS and show manual instructions instead. Already-installed (standalone)
// sessions hide the card entirely.
// ══════════════════════════════════════════════════════
let deferredInstallPrompt=null;
window.addEventListener('beforeinstallprompt',(e)=>{
  e.preventDefault();
  deferredInstallPrompt=e;
  renderInstallCard();
});
window.addEventListener('appinstalled',()=>{
  deferredInstallPrompt=null;
  toast('✅ تم تثبيت التطبيق!');
  renderInstallCard();
});
function isStandaloneApp(){
  return (window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches)||window.navigator.standalone===true;
}
function isIOSDevice(){
  return /iphone|ipad|ipod/i.test(navigator.userAgent)&&!window.MSStream;
}
function renderInstallCard(){
  const el=document.getElementById('install-card');
  if(!el)return;
  if(isStandaloneApp()){el.style.display='none';el.innerHTML='';return;}
  if(deferredInstallPrompt){
    el.style.display='block';
    el.innerHTML=`<div class="card" style="background:linear-gradient(135deg,rgba(142,124,255,.1),rgba(142,124,255,.03));border-color:rgba(142,124,255,.3)">
      <div style="display:flex;align-items:center;gap:11px">
        <span style="font-size:28px">📲</span>
        <div style="flex:1"><div style="font-size:12px;font-weight:800">ثبّت AC Fitness على هاتفك</div><div style="font-size:11px;color:var(--w55);margin-top:2px">يعمل كتطبيق كامل من الشاشة الرئيسية، حتى بدون إنترنت</div></div>
      </div>
      <button class="btn btn-p" style="margin-top:11px" onclick="triggerInstall()">تثبيت التطبيق 📥</button>
    </div>`;
  } else if(isIOSDevice()){
    el.style.display='block';
    el.innerHTML=`<div class="card" style="background:linear-gradient(135deg,rgba(142,124,255,.1),rgba(142,124,255,.03));border-color:rgba(142,124,255,.3)">
      <div style="display:flex;align-items:center;gap:11px;margin-bottom:10px">
        <span style="font-size:28px">📲</span>
        <div><div style="font-size:12px;font-weight:800">ثبّت AC Fitness على هاتفك</div><div style="font-size:11px;color:var(--w55);margin-top:2px">يعمل كتطبيق كامل من الشاشة الرئيسية</div></div>
      </div>
      <div style="font-size:11px;color:var(--w60);line-height:2.2;background:var(--b3);border-radius:11px;padding:11px">
        <div>1️⃣ اضغط زر المشاركة <b>⬆️</b> في أسفل شاشة سفاري</div>
        <div>2️⃣ مرّر لأسفل واختر "إضافة إلى الشاشة الرئيسية"</div>
        <div>3️⃣ اضغط "إضافة" — ستجد الأيقونة على شاشتك مباشرة</div>
      </div>
    </div>`;
  } else {
    el.style.display='none';el.innerHTML='';
  }
}
async function triggerInstall(){
  if(!deferredInstallPrompt)return;
  deferredInstallPrompt.prompt();
  try{
    const{outcome}=await deferredInstallPrompt.userChoice;
    if(outcome==='accepted')toast('✅ جاري التثبيت...');
  }catch(e){}
  deferredInstallPrompt=null;
  renderInstallCard();
}
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    const _had=!!navigator.serviceWorker.controller;navigator.serviceWorker.addEventListener('controllerchange',()=>{if(_had)toast('🔄 تم تحديث التطبيق — أعد تشغيله لتفعيل آخر نسخة');});navigator.serviceWorker.register('./sw.js').catch(()=>{});try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist();}catch(e){}
  });
}

window.addEventListener('load',()=>{
  load();
  restoreStepSessionIfAny();
  if(!APP.user){
    document.getElementById('ob').style.display='block';
    buildSportGrids();
    initEquipCards();
  } else {
    showAppShell();
    renderAll();
    if(APP.activeWorkout){_wtStart=APP.activeWorkout.startTime;startWtTimer();}
    showPg('home');
    checkAchievements();
  }
  renderWater();
});
// When the phone screen locks or the user switches away and comes back,
// setInterval ticks get throttled/suspended by the browser. The moment the
// page becomes visible again, immediately recompute every running timer
// from real elapsed time (rather than waiting for the next tick), so the
// displayed time is always accurate — this is what actually fixes needing
// to leave the app to use a separate timer for things like a 30s plank.
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState!=='visible')return;
  const aw=APP.activeWorkout;
  if(aw){
    aw.exercises.forEach((ex,ei)=>{
      ex.sets.forEach((s,si)=>{
        if(s.running&&s.endAt){
          const remaining=Math.max(0,Math.round((s.endAt-Date.now())/1000));
          s.remaining=remaining;
          if(remaining<=0){
            clearInterval(APP._timedInterval);
            s.done=true;s.running=false;s.endAt=null;
            save();
            const d=EX[ex.sciId||ex.id]||{};
            startRestTimer(d.rest||60);
            toast('✅ انتهى الوقت!','⏰');
          }
        }
      });
    });
    if(document.getElementById('tracker-exs'))renderTrackerExs();
  }
  if(APP._restEndAt){
    const remaining=Math.max(0,Math.round((APP._restEndAt-Date.now())/1000));
    APP._restSecs=remaining;
    updRest();
    if(remaining<=0){
      clearInterval(APP._restTimer);
      APP._restEndAt=null;
      const rb=document.getElementById('rest-box');
      if(rb)rb.style.display='none';
      toast('⏰ انتهت الراحة!');
    }
  }
});


function cleanStr(s){return String(s==null?'':s).replace(/[<>"'`]/g,c=>({'<':'‹','>':'›','"':'”',"'":'’','`':'ʼ'}[c]));}
function cleanDeep(o){if(typeof o==='string')return cleanStr(o);if(Array.isArray(o))return o.map(cleanDeep);if(o&&typeof o==='object'){const r={};for(const k of Object.keys(o)){if(k==='__proto__'||k==='constructor'||k==='prototype')continue;r[k]=cleanDeep(o[k]);}return r;}return o;}
function safeImport(d){if(!d||typeof d!=='object'||Array.isArray(d))throw new Error('bad');const A=['user','weights','measurements','workouts','plans','water','challenges','fatigue','dailyNotes','customProgram','activeWorkout','chalLast','chalStart','chalLog'],arr=['weights','measurements','workouts','plans'],obj=['water','challenges','fatigue','dailyNotes','chalLast','chalStart','chalLog'],o={};for(const k of A){if(!(k in d))continue;const v=d[k];if(arr.includes(k)&&!Array.isArray(v))throw new Error('bad');if(obj.includes(k)&&(v===null||typeof v!=='object'||Array.isArray(v)))throw new Error('bad');o[k]=v;}return cleanDeep(o);}
function localDay(v){const d=new Date(v);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function todayKey(){return localDay(new Date());}
function healthConsent(cb){try{if(localStorage.getItem('acfv2_consent')==='1')return true;}catch(e){return true;}
 const Q=['هل أخبرك طبيب أن لديك مشكلة في القلب أو ضغطاً مرتفعاً؟','هل تشعر بألم في الصدر عند النشاط البدني أو في الراحة؟','هل تفقد توازنك بسبب الدوخة أو فقدت الوعي من قبل؟','هل لديك حالة مزمنة أخرى (سكري، ربو، أمراض كلى...) أو تتناول أدوية بانتظام؟','هل لديك مشكلة في العظام أو المفاصل أو العضلات قد يزيدها التمرين؟','هل أنتِ حامل أو في فترة ما بعد الولادة مباشرة؟','هل نصحك طبيب بممارسة الرياضة تحت إشراف مختص فقط؟'];
 const o=document.createElement('div');o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');o.setAttribute('aria-label','فحص الجاهزية للتمرين');
 o.style.cssText='position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.88);display:flex;align-items:center;justify-content:center;padding:16px';
 o.innerHTML='<div style="background:var(--bg2);border:1px solid rgba(var(--wa),.12);border-radius:20px;padding:18px;max-width:440px;width:100%;max-height:90vh;overflow:auto;color:var(--w);line-height:1.7"><div style="font-size:17px;font-weight:900">فحص الجاهزية للتمرين (PAR-Q)</div><div style="font-size:12px;color:rgba(var(--wa),.75);margin:4px 0 8px">أجب بصدق. التطبيق للتثقيف الرياضي ولا يغني عن الطبيب. <a href="privacy.html" target="_blank" rel="noopener" style="color:#8E7CFF">سياسة الخصوصية والشروط</a></div>'+Q.map(q=>'<label style="display:flex;gap:8px;align-items:flex-start;font-size:13px;margin:8px 0"><input type="checkbox" class="parq" style="margin-top:5px"><span>'+q+'</span></label>').join('')+'<label style="display:flex;gap:8px;align-items:flex-start;font-size:13px;margin:12px 0;font-weight:700"><input type="checkbox" id="parq-ok" style="margin-top:5px"><span>أقرّ بأنني قرأت التنبيه وأوافق على الشروط، وأن من هم دون 18 سنة يتدرّبون بإشراف ولي الأمر.</span></label><div id="parq-warn" style="display:none;background:rgba(255,77,109,.18);border-radius:12px;padding:10px;font-size:12px;margin-bottom:10px">أجبت بـ«نعم» على سؤال أو أكثر: استشر طبيبك قبل البدء بأي برنامج تدريبي.</div><button id="parq-go" class="btn btn-p" disabled style="opacity:.5">متابعة</button></div>';
 document.body.appendChild(o);
 const ok=o.querySelector('#parq-ok'),go=o.querySelector('#parq-go');let warned=false;
 ok.onchange=()=>{go.disabled=!ok.checked;go.style.opacity=ok.checked?1:.5;};
 go.onclick=()=>{const n=[...o.querySelectorAll('.parq')].filter(c=>c.checked).length;if(n&&!warned){warned=true;o.querySelector('#parq-warn').style.display='block';go.textContent='فهمت — متابعة';return;}try{localStorage.setItem('acfv2_consent','1');localStorage.setItem('acfv2_parq',JSON.stringify({flags:n,at:todayKey()}));}catch(e){}o.remove();if(cb)cb();};
 return false;}
function aiConsent(){try{if(localStorage.getItem('acfv2_aiConsent')==='1')return true;if(confirm('ميزات الذكاء الاصطناعي ترسل بياناتك (الاسم، العمر، الوزن، الطول، الهدف، الإصابات، سجل التمارين) مباشرة إلى Google Gemini بمفتاحك، وتخضع لشروط Google وليس لهذا التطبيق. هل توافق؟')){localStorage.setItem('acfv2_aiConsent','1');return true;}return false;}catch(e){return true;}}
(function(){
 const _p=parseAiProgramJson;parseAiProgramJson=function(t){const r=_p(t);return r?cleanDeep(r):r;};
 const _b=buildProgram;buildProgram=function(u){const p=_b(u);try{(p.schedule||[]).forEach(d=>{if(!d.isRest&&!(d.exIds&&d.exIds.length)){d.exIds=['plank','dead_bug','glute_bridge','bodyweight_squat','crunch'].filter(i=>canDoExercise(i,u.equipment,u.limits)).slice(0,4);if(!d.exIds.length){d.isRest=true;d.label='راحة';d.focus='لا توجد تمارين مناسبة لقيودك — استشر مختصاً';}}});}catch(e){}return p;};
 const fix=()=>{labelIcons();document.querySelectorAll('[onclick]:not(button):not(a):not(input):not([tabindex])').forEach(e=>{e.setAttribute('role','button');e.setAttribute('tabindex','0');});document.querySelectorAll('label:not([for])').forEach(l=>{const n=l.nextElementSibling;if(n&&n.id&&/^(INPUT|SELECT|TEXTAREA)$/.test(n.tagName))l.htmlFor=n.id;});};
 let q=0;const sched=()=>{if(q)return;q=requestAnimationFrame(()=>{q=0;fix();});};
 [['app','main'],['nav','navigation'],['hdr','banner']].forEach(([i,r])=>{const e=document.getElementById(i);if(e)e.setAttribute('role',r);});
 const t=document.getElementById('toast');if(t){t.setAttribute('role','status');t.setAttribute('aria-live','polite');}
 document.querySelectorAll('.mo').forEach(m=>{m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');});
 fix();new MutationObserver(sched).observe(document.body,{childList:true,subtree:true});
 document.addEventListener('keydown',e=>{const el=e.target;if((e.key==='Enter'||e.key===' ')&&el&&el.getAttribute&&el.getAttribute('role')==='button'&&el.hasAttribute('onclick')&&!/^(BUTTON|A|INPUT|TEXTAREA|SELECT)$/.test(el.tagName)){e.preventDefault();el.click();}if(e.key==='Escape')document.querySelectorAll('.mo.on').forEach(m=>m.classList.remove('on'));});
})();

function labelIcons(){const M={'⚙️':'الإعدادات','⚙':'الإعدادات','✕':'إغلاق','✖':'إغلاق','×':'إغلاق','←':'رجوع','→':'رجوع','+':'إضافة','＋':'إضافة','−':'إنقاص','-':'إنقاص','🗑':'حذف','🗑️':'حذف','📋':'نسخ','▶':'تشغيل','⏸':'إيقاف مؤقت','⏭':'التالي','⏮':'السابق','🔄':'تحديث','📤':'مشاركة','📥':'استيراد','🔔':'التنبيهات','👤':'الملف الشخصي','🏠':'الرئيسية'};
 document.querySelectorAll('button:not([aria-label]),[role=button]:not([aria-label])').forEach(b=>{const t=(b.textContent||'').trim();if(!t||/[A-Za-z\u0600-\u06FF0-9]/.test(t))return;const l=b.getAttribute('title')||M[t]||M[t.replace(/\uFE0F/g,'')];if(l)b.setAttribute('aria-label',l);});}
(function(){
 const _rp=renderProfile;renderProfile=function(){_rp.apply(this,arguments);try{const pg=document.getElementById('pg-profile');if(pg&&!pg.querySelector('#legal-links')){const d=document.createElement('div');d.id='legal-links';d.style.cssText='text-align:center;font-size:12px;margin:18px 0 90px';d.innerHTML='<a href="privacy.html" target="_blank" rel="noopener" style="color:var(--mint)">سياسة الخصوصية وشروط الاستخدام</a>';pg.appendChild(d);}}catch(e){}};
 setTimeout(()=>{try{const t=+localStorage.getItem('acfv2_lastExport')||0;if(APP.workouts&&APP.workouts.length>=3&&Date.now()-t>14*864e5&&!sessionStorage.getItem('acfv2_bk')){sessionStorage.setItem('acfv2_bk','1');toast('صدّر نسخة احتياطية من بياناتك — فهي محفوظة على جهازك فقط','💾');}}catch(e){}},4000);
})();

function todayCtx(){try{
  const di=new Date().getDay(),parts=[];
  if(APP.activeWorkout&&APP.activeWorkout.exercises&&APP.activeWorkout.exercises.length)parts.push('- تمرين جارٍ الآن: '+APP.activeWorkout.name+' — '+APP.activeWorkout.exercises.map(e=>e.name).join('، '));
  const pr=getPrimaryPlan();
  if(pr&&pr.parsed&&pr.parsed.days){const d=pr.parsed.days.find(x=>x.dayKey===CUSTOM_DAY_KEYS[di]);if(d)parts.push('- برنامج اليوم الفعلي (خطته المخصصة "'+(pr.name||'')+'"): '+(d.isRest?'يوم راحة':JSON.stringify(d).slice(0,900)));}
  else{const t=APP.user&&APP.user.program&&APP.user.program.schedule&&APP.user.program.schedule[di];if(t)parts.push(t.isRest?'- برنامج اليوم الفعلي: يوم راحة':'- برنامج اليوم الفعلي ('+t.label+' — '+t.focus+'): '+(t.exIds||[]).filter(i=>EX[i]).map(i=>EX[i].n+' ['+EX[i].mu+']').join('، '));}
  const last=(APP.workouts||[]).slice(-3).map(w=>w.name+' ('+localDay(w.date)+')');if(last.length)parts.push('- آخر تمارين منجزة: '+last.join('، '));
  {const b=APP.user&&APP.user.baseline;if(b){const t=[];if(b.pushups!=null)t.push('ضغط '+b.pushups);if(b.squats!=null)t.push('سكوات '+b.squats);if(b.pullups!=null)t.push('عقلة '+b.pullups);if(b.plank!=null)t.push('بلانك '+b.plank+'ث');const l=b.lifts?Object.entries(b.lifts).map(([k,v])=>k+' '+v+'كغ'):[];parts.push('- مستواه المقاس (أقصى أداء): '+t.join('، ')+(l.length?' | أوزان 8 تكرارات: '+l.join('، '):''));}}
  return parts.length?'\nبرنامج اليوم الفعلي للمستخدم (مرجعك الوحيد لأسئلة تمارين اليوم والإطالة):\n'+parts.join('\n'):'';
}catch(e){return '';}}
setTimeout(()=>{try{const u=APP.user;if(u&&u.program&&u.program._v!==3&&u.days&&u.goal&&u.equipment){const np=buildProgram(u);np._v=3;APP.user.program=np;save();if(typeof renderAll==='function')renderAll();}}catch(e){}},60);

const SYS_TPL={
 ppl:{n:'دفع / سحب / أرجل (PPL)',d:'الأشهر عالمياً — من 3 إلى 6 أيام',days:[{l:'دفع',s:['صدر','صدر','كتف','كتف','ترايسبس','ترايسبس']},{l:'سحب',s:['ظهر','ظهر','ظهر','كتف خلفي','بايسبس','بايسبس']},{l:'أرجل',s:['أرجل','أرجل','بطن فخذ','مؤخرة','ساق','core']}]},
 ul:{n:'علوي / سفلي',d:'مثالي لـ 4 أيام',days:[{l:'جزء علوي',s:['صدر','ظهر','كتف','ظهر','ترايسبس','بايسبس']},{l:'جزء سفلي',s:['أرجل','بطن فخذ','أرجل','مؤخرة','ساق','core']}]},
 fb:{n:'كامل الجسم',d:'الأفضل للمبتدئين — من 2 إلى 4 أيام',days:[{l:'كامل الجسم A',s:['أرجل','صدر','ظهر','كتف','بطن فخذ','core']},{l:'كامل الجسم B',s:['أرجل','ظهر','صدر','مؤخرة','بايسبس','ترايسبس']},{l:'كامل الجسم C',s:['أرجل','كتف','ظهر','صدر','ساق','core']}]},
 bro:{n:'تقسيم العضلات (Bro Split)',d:'عضلة لكل يوم — 5 أيام',days:[{l:'صدر',s:['صدر','صدر','صدر','صدر','ترايسبس','core']},{l:'ظهر',s:['ظهر','ظهر','ظهر','ظهر','كتف خلفي','بايسبس']},{l:'كتف',s:['كتف','كتف','كتف','كتف خلفي','core']},{l:'أرجل',s:['أرجل','أرجل','بطن فخذ','مؤخرة','ساق','core']},{l:'ذراعين',s:['بايسبس','ترايسبس','بايسبس','ترايسبس','core']}]},
 phul:{n:'PHUL (قوة + حجم)',d:'4 أيام: علوي وسفلي مرتين',days:[{l:'علوي — قوة',s:['صدر','ظهر','كتف','ظهر','بايسبس','ترايسبس']},{l:'سفلي — قوة',s:['أرجل','بطن فخذ','أرجل','ساق','core']},{l:'علوي — حجم',s:['صدر','ظهر','كتف','صدر','بايسبس','ترايسبس']},{l:'سفلي — حجم',s:['أرجل','مؤخرة','بطن فخذ','ساق','core']}]},
 arnold:{n:'تقسيم أرنولد',d:'6 أيام: صدر+ظهر / كتف+ذراعين / أرجل',days:[{l:'صدر + ظهر',s:['صدر','ظهر','صدر','ظهر','core']},{l:'كتف + ذراعين',s:['كتف','كتف','بايسبس','ترايسبس','بايسبس','ترايسبس']},{l:'أرجل',s:['أرجل','أرجل','بطن فخذ','مؤخرة','ساق','core']}]}
};
function sysFillDay(day,u,used){
  const n=Math.min(day.s.length,({30:4,45:5,60:6,90:7}[u.duration]||5)),ids=[],cnt={};
  for(const k of day.s.slice(0,n)){
    const pick=Object.keys(EX).filter(id=>(k==='core'?PROG_CORE.has(id):((EX[id].mu||'').includes(k)&&!PROG_CORE.has(id)&&!(k==='كتف'&&(EX[id].mu||'').includes('خلفي'))))&&!ids.includes(id)&&canDoExercise(id,u.equipment,u.limits)&&!(u.level==='beginner'&&EX[id].lv==='adv')&&(!PROG_PAT[id]||(cnt[PROG_PAT[id]]||0)<(PROG_CAP[PROG_PAT[id]]||1))).sort((a,b)=>(used[a]||0)-(used[b]||0))[0];
    if(pick){ids.push(pick);const p=PROG_PAT[pick];if(p)cnt[p]=(cnt[p]||0)+1;used[pick]=(used[pick]||0)+1;}
  }
  ['plank','dead_bug','crunch','glute_bridge','bodyweight_squat'].forEach(i=>{if(ids.length<3&&!ids.includes(i)&&EX[i]&&canDoExercise(i,u.equipment,u.limits))ids.push(i);});
  const rk=id=>PROG_RANK[PROG_PAT[id]]||(PROG_CORE.has(id)?9:5);
  return ids.sort((a,b)=>rk(a)-rk(b));
}
function applySystem(p,u){
  const sy=u.system||{},tpl=SYS_TPL[sy.id],WD=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  if(tpl&&sy.weekdays&&sy.weekdays.length){
    const used={},wds=[...sy.weekdays].sort((a,b)=>a-b);
    p.schedule=WD.map((nm,i)=>{const k=wds.indexOf(i);if(k<0)return{day:nm,weekday:i,label:'راحة',focus:'يوم راحة — تعافٍ نشط (مشي خفيف / تمدد / Mobility)',exIds:[],isRest:true};const d=tpl.days[k%tpl.days.length];return{day:nm,weekday:i,label:d.l,focus:d.l,exIds:sysFillDay(d,u,used),isRest:false};});
    p.splitLabel=tpl.n;p.trainingDays=wds.length;p.restDayCount=7-wds.length;
  }
  const ed=sy.edits||{};
  p.schedule.forEach(d=>{if(ed[d.weekday]){d.exIds=ed[d.weekday].filter(i=>EX[i]);d.isRest=!d.exIds.length;if(d.isRest)d.label='راحة';else if(d.label==='راحة'){d.label='تمرين مخصص';d.focus='تمرين مخصص';}}});
  const lbs=sy.labels||{};p.schedule.forEach(d=>{const lb=lbs[d.weekday];if(lb&&!d.isRest){d.label=lb.l;d.focus=lb.f;}});
  p._v=3;return p;
}
(function(){const _b3=buildProgram;buildProgram=function(u){const p=_b3(u);try{if(u&&u.system)applySystem(p,u);}catch(e){}return p;};})();
function sysOpen(){
  const u=APP.user;if(!u){toast('أكمل التسجيل أولاً','⚠️');return;}
  const sy=u.system||{},WD=['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'];
  let pick=sy.id&&SYS_TPL[sy.id]?sy.id:'ppl',wds=new Set(sy.weekdays||((u.program&&u.program.schedule)?u.program.schedule.filter(d=>!d.isRest).map(d=>d.weekday):[0,2,4]));
  const o=document.createElement('div');o.id='sys-ov';o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');
  o.style.cssText='position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.88);overflow:auto;padding:14px';
  o.innerHTML=`<div style="max-width:460px;margin:0 auto;background:var(--bg2);border:1px solid var(--w12);border-radius:20px;padding:16px;color:var(--w)"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">🧩 نظام التمرين</b><button class="btn btn-g btn-sm" data-close="1">إغلاق</button></div><div style="font-size:12px;color:var(--w75);margin:6px 0 10px;line-height:1.7">اختر أي نظام وأيام تدريبك، وسيُبنى البرنامج من معداتك وإصاباتك. ثم عدّل تمارين أي يوم يدوياً.</div><div id="sys-tpls"></div><div style="font-size:12px;margin:10px 0 6px">أيام التدريب:</div><div id="sys-wd" style="display:flex;gap:5px;flex-wrap:wrap"></div><button class="btn btn-p" style="width:100%;margin-top:12px" data-go="1">إنشاء البرنامج</button><div style="font-size:12px;margin:16px 0 6px"><b>تعديل أيام البرنامج الحالي:</b></div><div id="sys-days"></div></div>`;
  document.body.appendChild(o);
  const draw=()=>{
    o.querySelector('#sys-tpls').innerHTML=Object.entries(SYS_TPL).map(([id,t])=>`<div data-t="${id}" style="padding:10px 12px;border-radius:14px;margin-bottom:6px;cursor:pointer;border:1px solid ${id===pick?'var(--mint)':'var(--w12)'};background:${id===pick?'var(--mint-glow)':'var(--bg3)'}"><b style="font-size:13px">${t.n}</b><div style="font-size:11px;color:var(--w35)">${t.d}</div></div>`).join('');
    o.querySelector('#sys-wd').innerHTML=WD.map((n,i)=>`<span data-d="${i}" style="padding:8px 11px;border-radius:12px;font-size:12px;cursor:pointer;font-weight:700;border:1px solid var(--w12);background:${wds.has(i)?'var(--mint)':'var(--bg3)'};color:${wds.has(i)?'#0B0A24':'var(--w)'}">${n}</span>`).join('');
    o.querySelector('#sys-days').innerHTML=((u.program&&u.program.schedule)||[]).map(d=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;background:var(--bg3);border-radius:12px;margin-bottom:5px;font-size:12px"><span><b>${d.day}</b> — ${d.isRest?'راحة':escapeHtml(d.label)+' ('+d.exIds.length+')'}</span><span style="display:flex;gap:6px">${d.isRest?`<button class="btn btn-g btn-sm" data-bk="${d.weekday}">➕ يوم جري + محطة</button>`:''}<button class="btn btn-g btn-sm" data-e="${d.weekday}">تعديل</button></span></div>`).join('');
  };
  draw();
  o.onclick=e=>{const t=e.target.closest('[data-t],[data-d],[data-e],[data-bk],[data-close],[data-go]');if(!t)return;const d=t.dataset;
    if(d.close)o.remove();else if(d.t){pick=d.t;draw();}else if(d.d!==undefined){const i=+d.d;wds.has(i)?wds.delete(i):wds.add(i);draw();}else if(d.bk!==undefined)sysBackupDay(+d.bk,draw);else if(d.e!==undefined)sysEdit(+d.e,draw);
    else if(d.go){if(wds.size<1||wds.size>6){toast('اختر من 1 إلى 6 أيام','⚠️');return;}u.system={id:pick,weekdays:[...wds].sort((a,b)=>a-b),edits:{}};u.days=wds.size;u.program=buildProgram(u);u.program._v=3;save();renderAll();toast('✅ تم إنشاء برنامج '+SYS_TPL[pick].n);o.remove();}};
}
function sysEdit(wd,done){
  const u=APP.user,sc=u.program.schedule.find(d=>d.weekday===wd),sel=new Set(sc.exIds),o=document.createElement('div');
  o.style.cssText='position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.92);overflow:auto;padding:14px';
  const G=[['الكل',''],['صدر','صدر'],['ظهر','ظهر'],['كتف','كتف'],['ذراع','ايسبس'],['أرجل','أرجل|مؤخرة|بطن فخذ|ساق'],['بطن/كارديو','بطن|كارديو|كل الجسم']];let f='';
  const draw=()=>{o.innerHTML=`<div style="max-width:460px;margin:0 auto;background:var(--bg2);border:1px solid var(--w12);border-radius:20px;padding:16px;color:var(--w)"><b>${sc.day} — اختر التمارين (${sel.size})</b><div style="display:flex;gap:5px;flex-wrap:wrap;margin:10px 0">${G.map(g=>`<span data-g="${g[1]}" style="padding:6px 10px;border-radius:99px;font-size:11px;cursor:pointer;border:1px solid var(--w12);background:${f===g[1]?'var(--mint)':'var(--bg3)'};color:${f===g[1]?'#0B0A24':'var(--w)'}">${g[0]}</span>`).join('')}</div>${Object.keys(EX).filter(id=>!f||new RegExp(f).test(EX[id].mu)).map(id=>`<label style="display:flex;gap:8px;align-items:center;padding:8px;border-bottom:1px solid var(--w8);font-size:13px"><input type="checkbox" data-x="${id}" ${sel.has(id)?'checked':''}><span>${EX[id].n} <small style="color:var(--w35)">${EX[id].mu}</small></span></label>`).join('')}<div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-p" style="flex:2" data-save="1">حفظ</button><button class="btn btn-g" style="flex:1" data-cancel="1">إلغاء</button></div></div>`;};
  draw();
  o.onclick=e=>{const g=e.target.closest('[data-g]');if(g){f=g.dataset.g;draw();return;}if(e.target.closest('[data-cancel]')){o.remove();return;}
    if(e.target.closest('[data-save]')){const sy=u.system=u.system||{id:'auto',weekdays:null,edits:{}};sy.edits=sy.edits||{};sy.edits[wd]=[...sel];sc.exIds=[...sel];sc.isRest=!sel.size;if(sc.isRest)sc.label='راحة';else if(sc.label==='راحة'){sc.label='تمرين مخصص';sc.focus='تمرين مخصص';}save();renderAll();o.remove();if(done)done();toast('✓ تم حفظ تمارين '+sc.day);}};
  o.addEventListener('change',e=>{const x=e.target.dataset&&e.target.dataset.x;if(x){e.target.checked?sel.add(x):sel.delete(x);}});
  document.body.appendChild(o);
}
(function(){const _rp2=renderPrograms;renderPrograms=function(){_rp2.apply(this,arguments);try{const pg=document.getElementById('pg-programs');if(pg&&!pg.querySelector('#sys-card')){const d=document.createElement('div');d.id='sys-card';d.style.cssText='background:linear-gradient(135deg,var(--mint-glow),var(--bg3));border:1px solid var(--w12);border-radius:18px;padding:14px;margin:10px 0;display:flex;align-items:center;gap:10px';d.innerHTML='<div style="font-size:26px">🧩</div><div style="flex:1"><div style="font-weight:800;font-size:14px">نظام التمرين</div><div style="font-size:12px;color:var(--w75)">PPL · علوي/سفلي · كامل الجسم · Bro Split · PHUL · أرنولد — أو عدّل أيامك بنفسك</div></div><div style="display:flex;flex-direction:column;gap:6px"><button class="btn btn-p btn-sm" onclick="sysOpen()">تغيير</button><button class="btn btn-g btn-sm" onclick="lvlOpen()">📏 مستواي</button></div>';pg.insertBefore(d,pg.children[1]||null);}}catch(e){}};})();

function chalSetInput(id){const el=document.getElementById('ci-'+id),c=CHALLENGES.find(x=>x.id===id),v=parseFloat(el&&el.value);if(!c||!el||el.value===''||!(v>=0)){toast('أدخل رقماً صحيحاً','⚠️');return;}APP.chalLog=APP.chalLog||{};const L=APP.chalLog[id]=APP.chalLog[id]||{},k=todayKey(),before=L[k]&&L[k].v>=L[k].t,e=L[k]||(L[k]={v:0,t:chalTarget(c)});e.v=Math.min(Math.round(v),1000000);APP.challenges[id]=chalDays(c);toast(e.v>=e.t&&!before?'🎯 حققت هدف اليوم!':'✓ تم ضبط إجمالي اليوم: '+e.v.toLocaleString('en')+' '+c.unit);save();renderChallenges();}
function wkBreakdown(w){
  const top=ex=>(ex.sets||[]).filter(s=>s.done).reduce((a,s)=>((parseFloat(s.weight)||0)>(parseFloat(a.weight)||0)?s:a),{weight:0,reps:0});
  const prevTop=name=>{const ws=APP.workouts.slice(0,-1).reverse();for(const p of ws){const e=(p.exercises||[]).find(x=>x.name===name);if(e){const t=top(e);if(parseFloat(t.weight))return parseFloat(t.weight);}}return null;};
  const rows=(w.exercises||[]).map(ex=>{const ds=(ex.sets||[]).filter(s=>s.done);if(!ds.length)return'';const t=top(ex),tw=parseFloat(t.weight)||0,vol=ds.reduce((a,s)=>a+(parseFloat(s.weight)||0)*(parseInt(s.reps)||0),0),pw=prevTop(ex.name),d=pw===null?'':(tw>pw?' ▲ +'+(tw-pw):tw<pw?' ▼ '+(tw-pw):' =')+' عن آخر مرة';
    return`<div style="display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-top:1px solid var(--w8);font-size:12px"><span style="flex:1">${escapeHtml(ex.name)}<div style="color:var(--w35);font-size:11px">${ds.length} مجموعات · أعلى وزن ${tw} كغ × ${parseInt(t.reps)||0}${d}</div></span><b>${Math.round(vol).toLocaleString('en')} كغ</b></div>`;}).join('');
  return`<div style="margin-top:12px"><div style="font-size:12px;font-weight:800;margin-bottom:4px">⚖️ الأوزان المستخدمة (الحجم = وزن × تكرار)</div>${rows||'<div style="font-size:12px;color:var(--w35)">لم تُسجَّل مجموعات منجزة</div>'}<div style="font-size:11px;color:var(--w35);margin-top:8px">السعرات تقدير تقريبي (MET × وزنك × المدة) وقد تختلف نحو ±20%.</div></div>`;
}

Object.assign(EX,{
 pike_pushup:{n:'ضغط بايك',e:'Pike Push-Up',mu:'كتف',sec:'ترايسبس، صدر علوي',eq:['bodyweight'],lv:'int',ico:'🔺',rpe:7,tempo:'2-0-1',rest:75,lo:6,hi:12,alts:['pushup'],err:'نزول الظهر وعدم رفع الوركين',how:['ابدأ بوضع V مقلوب: الوركان للأعلى والذراعان والساقان مستقيمة','اثنِ الكوعين وأنزل الرأس نحو الأرض ثم ادفع للأعلى']},
 chinup:{n:'عقلة قبضة عكسية',e:'Chin-Up',mu:'ظهر-بايسبس',sec:'بطن',eq:['pullup_bar','full_gym'],lv:'int',ico:'🙌',rpe:8,tempo:'2-1-2',rest:75,lo:4,hi:10,alts:['pullup','inverted_row'],err:'التأرجح ونصف الحركة',how:['أمسك العقلة بقبضة عكسية بعرض الكتفين','اسحب حتى يتجاوز الذقن العقلة ثم انزل ببطء']},
 hollow_hold:{n:'هولو هولد',e:'Hollow Hold',mu:'بطن ثبات',sec:'ثني الورك',eq:['bodyweight'],lv:'int',ico:'🛶',rpe:7,tempo:'hold',rest:45,lo:20,hi:45,isTimed:true,alts:['plank','dead_bug'],err:'ارتفاع أسفل الظهر عن الأرض',how:['استلقِ على ظهرك وارفع الكتفين والساقين قليلاً عن الأرض','ثبّت أسفل الظهر ملاصقاً للأرض وحافظ على الوضعية']},
 jump_rope:{n:'نط الحبل',e:'Jump Rope',mu:'كارديو',sec:'سمانة، كتفين',eq:['bodyweight'],lv:'beg',ico:'🪢',rpe:7,tempo:'rounds',rest:45,lo:3,hi:6,isTimed:true,unit:'جولة 2د',alts:['high_knees','shadowboxing'],err:'القفز عالياً والهبوط بقدم مسطحة',how:['اقفز على مقدمة القدمين بقفزات صغيرة مع دوران المعصمين','لا حبل؟ قلّد الحركة بقفزات خفيفة في المكان']},
 high_knees:{n:'ركبة عالية',e:'High Knees',mu:'كارديو',sec:'أرجل، بطن',eq:['bodyweight'],lv:'beg',ico:'🏃',rpe:7,tempo:'rounds',rest:45,lo:3,hi:5,isTimed:true,unit:'30 ثانية',alts:['jump_rope','mountain_climber'],err:'الانحناء للخلف',how:['اجرِ في المكان مع رفع الركبتين لمستوى الوركين','حرّك الذراعين بالتبادل وحافظ على جذع مستقيم']},
 sprawl:{n:'سبرول',e:'Sprawl',mu:'كارديو كامل',sec:'كتفين، بطن، أرجل',eq:['bodyweight'],lv:'int',ico:'🤼',rpe:8,tempo:'explosive',rest:60,lo:8,hi:15,alts:['burpee','mountain_climber'],err:'ترك الوركين معلقين في الهواء',how:['من الوقوف ارمِ ساقيك للخلف بسرعة وأنزل الوركين للأرض','عد بسرعة إلى القرفصاء ثم قفز أو وقوف']},
 bear_crawl:{n:'زحف الدب',e:'Bear Crawl',mu:'كل الجسم',sec:'كتفين، بطن',eq:['bodyweight'],lv:'beg',ico:'🐻',rpe:7,tempo:'rounds',rest:60,lo:3,hi:5,isTimed:true,unit:'20 متراً',alts:['mountain_climber','plank'],err:'رفع الوركين عالياً',how:['على اليدين والقدمين والركبتان مرفوعتان قليلاً عن الأرض','تحرك للأمام بالتبادل يد-قدم مع ظهر مسطح']},
 wrestler_bridge:{n:'جسر المصارع',e:'Wrestler Bridge',mu:'مؤخرة-رقبة',sec:'ظهر سفلي',eq:['bodyweight'],lv:'int',ico:'🌉',rpe:6,tempo:'hold',rest:60,lo:15,hi:30,isTimed:true,alts:['glute_bridge'],err:'تحميل وزن زائد على الرقبة',how:['استلقِ على ظهرك والقدمان قريبتان من الوركين','ارفع الوركين عالياً وثبّت الوضعية بحذر (ابدأ بجسر الأرداف إن كنت مبتدئاً)']},
 hip_escape:{n:'هروب الورك',e:'Hip Escape (Shrimp)',mu:'بطن حركة',sec:'ورك، أرجل',eq:['bodyweight'],lv:'beg',ico:'🦐',rpe:6,tempo:'controlled',rest:45,lo:8,hi:12,alts:['dead_bug'],err:'الدفع بالذراع بدل الورك',how:['استلقِ على جانبك وادفع بقدمك لتحريك الوركين للخلف','بدّل الجانبين بحركة مضبوطة مسافة 5 أمتار']}
});
Object.assign(EX_POSE,{pike_pushup:'push_v',chinup:'pull',hollow_hold:'core',jump_rope:'cardio',high_knees:'cardio',sprawl:'cardio',bear_crawl:'cardio',wrestler_bridge:'hip_lift',hip_escape:'core'});
Object.assign(PROG_PAT,{hollow_hold:'core',chinup:'vpull',pike_pushup:'vpress'});PROG_CORE.add('hollow_hold');
const SUPPORT_POOL={calisthenics:{up:['pushup','pike_pushup','chinup','dip','diamond_pushup','inverted_row'],low:['bodyweight_squat','lunge','jump_squat','glute_bridge'],core:['hollow_hold','leg_raise','plank']},boxing:{any:['shadowboxing','jump_rope','heavy_bag','high_knees','burpee','mountain_climber']},wrestling:{any:['sprawl','bear_crawl','wrestler_bridge','hip_escape','farmers_walk']}};
function applySupport(p,u){
  const sp=(u.supportSports||[]).filter(x=>SUPPORT_POOL[x]);if(!sp.length||!p.schedule)return;
  const used={},ed=(u.system&&u.system.edits)||{},mx=({30:4,45:5,60:6,90:7}[u.duration]||5);
  p.schedule.filter(d=>!d.isRest&&!ed[d.weekday]).forEach((d,k)=>{
    const f=d.focus||'',up=/دفع|صدر|ظهر|سحب|علوي|كتف|بايسبس|ترايسبس/.test(f),lo=/أرجل|سفلي|مؤخرة/.test(f),picks=[];
    for(let r=0;r<Math.min(2,sp.length);r++){
      const P=SUPPORT_POOL[sp[(k+r)%sp.length]],pool=[...(P.any||[]),...((up&&!lo)?(P.up||[]):[]),...((lo&&!up)?(P.low||[]):[]),...(P.core||[])];
      const id=pool.filter(i=>EX[i]&&!d.exIds.includes(i)&&!picks.includes(i)&&canDoExercise(i,u.equipment,u.limits)).sort((a,b)=>(used[a]||0)-(used[b]||0))[0];
      if(id){picks.push(id);used[id]=(used[id]||0)+1;}
    }
    let bs=[...d.exIds],g=0;while(bs.length+picks.length>mx&&bs.length>3&&g++<20){let k=-1;for(let j=bs.length-1;j>=0;j--){if(!/ظهر/.test((EX[bs[j]]||{}).mu||'')){k=j;break;}}bs.splice(k<0?bs.length-1:k,1);}d.exIds=[...bs,...picks];
  });
}
(function(){const _b4=buildProgram;buildProgram=function(u){const p=_b4(u);try{ensureBack(p,u);}catch(e){}try{diversify(p,u);}catch(e){}try{applySupport(p,u);}catch(e){}return p;};})();
function sysBackupDay(wd,done){
  const u=APP.user,sc=u.program.schedule.find(d=>d.weekday===wd);if(!sc)return;
  const ids=['pullup','dip','pushup','leg_raise','bodyweight_squat','hollow_hold'],sy=u.system=u.system||{id:'auto',weekdays:null,edits:{}};
  sy.edits=sy.edits||{};sy.labels=sy.labels||{};sy.edits[wd]=ids;sy.labels[wd]={l:'جري + محطة عقلة/ديبس',f:'جري خفيف 20–30 دقيقة (زون 2) ثم دوائر العقلة والديبس والضغط في مكان الجري'};
  sc.exIds=ids;sc.isRest=false;sc.label=sy.labels[wd].l;sc.focus=sy.labels[wd].f;save();renderAll();toast('✅ أُضيف يوم الجري + المحطة');if(done)done();
}
function chalFrom(c){const b=APP.user&&APP.user.baseline,key={c1:'pushups',c4:'squats',c8:'pullups',c2:'plank'}[c.id],v=b&&key?b[key]:null;if(!(v>0))return c.from;return Math.max(c.from,Math.min(Math.round(v*0.6/c.step)*c.step,Math.round(c.to*0.6/c.step)*c.step));}
function prefillWeights(){
  const aw=APP.activeWorkout;if(!aw||!aw.exercises)return;const L=(APP.user&&APP.user.baseline&&APP.user.baseline.lifts)||{};
  const F={squat:['squat',1],leg_press:['squat',1.5],hip_thrust:['squat',.8],deadlift:['deadlift',1],rdl:['deadlift',.65],bench_press:['bench',1],db_press:['bench',.36],ohp:['bench',.6],db_ohp:['bench',.22]};
  const last=name=>{for(let i=APP.workouts.length-1;i>=0;i--){const e=(APP.workouts[i].exercises||[]).find(x=>x.name===name);if(e){const w=Math.max(0,...(e.sets||[]).filter(s=>s.done).map(s=>parseFloat(s.weight)||0));if(w>0)return w;}}return 0;};
  let n=0;aw.exercises.forEach(ex=>{const id=Object.keys(EX).find(k=>EX[k].n===ex.name),w=last(ex.name)||(id&&F[id]&&L[F[id][0]]?Math.round(L[F[id][0]]*F[id][1]*0.9/2.5)*2.5:0);if(w>0)(ex.sets||[]).forEach(s=>{if(!(parseFloat(s.weight)>0)){s.weight=w;n++;}});});
  if(n){save();if(typeof renderTracker==='function')renderTracker();}
}
(function(){const _sd=startDayWk;startDayWk=function(di){const r=_sd.apply(this,arguments);try{prefillWeights();}catch(e){}return r;};})();
function lvlOpen(){
  const u=APP.user;if(!u){toast('أكمل التسجيل أولاً','⚠️');return;}
  const b=u.baseline||{},o=document.createElement('div');o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');
  o.style.cssText='position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.88);overflow:auto;padding:14px';
  const F=[['pushups','ضغط (أقصى تكرار بتكنيك سليم)','تكرار'],['squats','سكوات بوزن الجسم (أقصى تكرار)','تكرار'],['pullups','عقلة (أقصى تكرار — 0 إن لم تستطع)','تكرار'],['dips','ديبس (اختياري)','تكرار'],['plank','بلانك (أطول مدة)','ثانية']],W=[['squat','سكوات'],['bench','بنش بريس'],['deadlift','ديدليفت']];
  o.innerHTML=`<div style="max-width:460px;margin:0 auto;background:var(--bg2);border:1px solid var(--w12);border-radius:20px;padding:16px;color:var(--w)"><b style="font-size:17px">📏 اختبار مستواي</b><div style="font-size:12px;color:var(--w75);margin:6px 0 10px;line-height:1.7">أدخل أقصى ما تستطيعه بتكنيك سليم. سنحدّد مستواك ونضبط أوزان البداية والتحديات. اترك ما لا تعرفه فارغاً.</div>${F.map(f=>`<label style="font-size:12px;display:block;margin-top:8px">${f[1]}</label><input class="ch2-in" style="width:100%" data-k="${f[0]}" type="number" inputmode="numeric" min="0" max="500" value="${b[f[0]]!=null?b[f[0]]:''}" placeholder="${f[2]}">`).join('')}<div style="font-size:12px;margin:14px 0 2px"><b>أثقل وزن لـ 8 تكرارات (كغ) — اختياري</b></div>${W.map(w=>`<label style="font-size:12px;display:block;margin-top:8px">${w[1]}</label><input class="ch2-in" style="width:100%" data-w="${w[0]}" type="number" inputmode="decimal" min="0" max="500" value="${b.lifts&&b.lifts[w[0]]!=null?b.lifts[w[0]]:''}" placeholder="كغ">`).join('')}<div style="display:flex;gap:8px;margin-top:14px"><button class="btn btn-p" style="flex:2" data-save="1">حفظ وتحديد مستواي</button><button class="btn btn-g" style="flex:1" data-close="1">إلغاء</button></div></div>`;
  document.body.appendChild(o);
  o.onclick=e=>{if(e.target.closest('[data-close]')){o.remove();return;}if(!e.target.closest('[data-save]'))return;
    const g=(a,k)=>{const el=o.querySelector('['+a+'="'+k+'"]'),v=el&&el.value!==''?parseFloat(el.value):NaN;return v>=0?Math.min(v,500):null;};
    const bl={lifts:{}};F.forEach(f=>{const v=g('data-k',f[0]);if(v!==null)bl[f[0]]=v;});W.forEach(w=>{const v=g('data-w',w[0]);if(v>0)bl.lifts[w[0]]=v;});
    if(bl.pushups===undefined&&bl.squats===undefined&&bl.pullups===undefined&&bl.plank===undefined){toast('أدخل رقماً واحداً على الأقل','⚠️');return;}
    const sc=(v,a,c)=>v===undefined?null:(v<a?0:v<c?1:2),sv=[sc(bl.pushups,10,25),sc(bl.squats,20,40),sc(bl.pullups,3,8),sc(bl.plank,45,90)].filter(x=>x!==null),avg=sv.reduce((a,c)=>a+c,0)/sv.length;
    u.baseline=bl;u.level=avg<0.67?'beginner':avg<1.5?'intermediate':'advanced';u.program=buildProgram(u);u.program._v=3;save();renderAll();o.remove();toast('✅ مستواك: '+({beginner:'مبتدئ',intermediate:'متوسط',advanced:'متقدم'}[u.level]));};
}

function wc(a){return 'rgba('+((getComputedStyle(document.documentElement).getPropertyValue('--wa')||'').trim()||'255,255,255')+','+a+')';}
function wtxt(){return (getComputedStyle(document.documentElement).getPropertyValue('--w')||'').trim()||'#fff';}
function themeGet(){try{return Object.assign({mode:'dark',accent:'violet'},JSON.parse(localStorage.getItem('acfv2_theme')||'{}'));}catch(e){return{mode:'dark',accent:'violet'};}}
function themeApply(t){t=t||themeGet();const r=document.documentElement,m=t.mode==='auto'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):t.mode;r.setAttribute('data-theme',m);if(t.accent&&t.accent!=='violet')r.setAttribute('data-accent',t.accent);else r.removeAttribute('data-accent');const mc=document.querySelector('meta[name="theme-color"]');if(mc)mc.setAttribute('content',m==='light'?'#F2F4FA':'#0A0E14');}
function themeSet(p){const t=Object.assign(themeGet(),p);try{localStorage.setItem('acfv2_theme',JSON.stringify(t));}catch(e){}themeApply(t);try{renderAll();}catch(e){}}
function themeOpen(){
  const M=[['dark','🌙','ليلي'],['light','☀️','فاتح'],['auto','🖥️','تلقائي']],C=[['violet','#8E7CFF'],['blue','#4F9DFF'],['teal','#19D3B5'],['orange','#FF8A3D'],['rose','#FF5C8A'],['gold','#F5B829']];
  const o=document.createElement('div');o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');o.style.cssText='position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.6);display:flex;align-items:flex-end;justify-content:center;padding:0';
  const draw=()=>{const t=themeGet();o.innerHTML=`<div style="width:100%;max-width:460px;background:var(--bg2);border:1px solid var(--w12);border-radius:24px 24px 0 0;padding:18px 16px calc(24px + env(safe-area-inset-bottom));color:var(--w)"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><b style="font-size:17px">🎨 المظهر</b><button class="btn btn-g btn-sm" style="width:auto" data-close="1">تم</button></div><div style="font-size:12px;color:var(--w35);margin-bottom:6px">الوضع</div><div style="display:flex;gap:8px;margin-bottom:16px">${M.map(m=>`<button data-m="${m[0]}" style="flex:1;padding:12px 4px;border-radius:14px;font:inherit;font-size:13px;font-weight:700;cursor:pointer;color:${t.mode===m[0]?'#0B0A24':'var(--w)'};background:${t.mode===m[0]?'var(--mint)':'var(--bg4)'};border:1px solid var(--w12)">${m[1]} ${m[2]}</button>`).join('')}</div><div style="font-size:12px;color:var(--w35);margin-bottom:8px">لون التطبيق</div><div style="display:flex;gap:12px;flex-wrap:wrap">${C.map(c=>`<button data-a="${c[0]}" aria-label="${c[0]}" style="width:44px;height:44px;border-radius:50%;cursor:pointer;background:${c[1]};border:3px solid ${t.accent===c[0]?'var(--w)':'transparent'};box-shadow:0 0 0 1px var(--w12)"></button>`).join('')}</div></div>`;};
  draw();o.onclick=e=>{const b=e.target.closest('[data-m],[data-a],[data-close]');if(e.target===o||(b&&b.dataset.close!==undefined)){o.remove();return;}if(!b)return;if(b.dataset.m)themeSet({mode:b.dataset.m});else themeSet({accent:b.dataset.a});draw();};
  document.body.appendChild(o);
}
(function(){
  try{matchMedia('(prefers-color-scheme: light)').addEventListener('change',()=>{if(themeGet().mode==='auto')themeApply();});}catch(e){}
  themeApply();
  const b=document.querySelector('.ico-btn');
  if(b&&b.parentNode&&!document.getElementById('theme-btn')){const t=document.createElement('button');t.className=b.className;t.id='theme-btn';t.title='المظهر';t.setAttribute('aria-label','المظهر');t.textContent='🎨';t.onclick=themeOpen;b.parentNode.appendChild(t);}
})();

let _navStack=[],_navCur='home';
function _isTab(id){return PG_MAP[id]!==undefined;}
function ensureBackBtn(id){
  if(_isTab(id))return;const p=document.getElementById('pg-'+id);if(!p||p.querySelector('.pg-back'))return;
  p.insertAdjacentHTML('afterbegin','<div class="pg-back"><button type="button" onclick="goBack()" aria-label="رجوع">→ رجوع</button></div>');
}
function goBack(){if(typeof history!=='undefined'&&history.state&&history.state.pg)history.back();else showPg(_navStack.pop()||'home',true);}
(function(){
  const _sp=showPg;
  showPg=function(id,isBack){
    if(!isBack&&_navCur!==id){_navStack.push(_navCur);if(_navStack.length>20)_navStack.shift();if(!_isTab(id)&&typeof history!=='undefined')try{history.pushState({pg:id},'');}catch(e){}}
    _navCur=id;_sp.call(this,id);ensureBackBtn(id);
  };
  window.addEventListener('popstate',()=>{if(!_isTab(_navCur))showPg(_navStack.pop()||'home',true);});
})();

Object.assign(EX,{
 barbell_row:{n:'باربل رو',e:'Barbell Row',mu:'ظهر',sec:'بايسبس، أسفل الظهر',eq:['barbell','full_gym'],lv:'int',ico:'🏋️',rpe:8,tempo:'2-0-1',rest:90,lo:6,hi:10,alts:['db_row','cable_row'],err:'تقوّس الظهر أو استخدام الزخم',how:['انحنِ من الوركين بظهر مستقيم وأمسك البار بقبضة أعرض قليلاً من الكتفين','اسحب البار نحو أسفل الصدر مع ضم لوحي الكتف ثم أنزله ببطء']},
 table_row:{n:'صف تحت الطاولة',e:'Table Row',mu:'ظهر',sec:'بايسبس، كتف خلفي',eq:['bodyweight'],lv:'beg',ico:'🪑',rpe:7,tempo:'2-1-2',rest:75,lo:6,hi:15,alts:['backpack_row','superman'],err:'ترك الوركين يهبطان',how:['استلقِ تحت طاولة ثقيلة ومستقرة وأمسك حافتها بقبضة بعرض الكتفين','شدّ الجسم مستقيماً واسحب صدرك نحو الحافة ثم انزل ببطء (تأكد من ثبات الطاولة)']},
 backpack_row:{n:'صف بحقيبة ظهر',e:'Backpack Row',mu:'ظهر',sec:'بايسبس',eq:['bodyweight'],lv:'beg',ico:'🎒',rpe:7,tempo:'2-0-1',rest:60,lo:10,hi:15,alts:['db_row','table_row'],err:'تقوّس الظهر',how:['املأ حقيبة بالكتب وأمسكها بكلتا يديك وانحنِ من الوركين بظهر مستقيم','اسحب الحقيبة نحو بطنك وضمّ لوحي الكتف ثم أنزلها ببطء']},
 superman:{n:'سوبرمان',e:'Superman',mu:'ظهر سفلي',sec:'مؤخرة، كتف خلفي',eq:['bodyweight'],lv:'beg',ico:'🦸',rpe:6,tempo:'2-1-2',rest:45,lo:10,hi:15,alts:['glute_bridge'],err:'رفع الرقبة أكثر من اللازم',how:['استلقِ على بطنك والذراعان ممدودتان أمامك','ارفع الذراعين والساقين معاً عن الأرض لثانية ثم انزل ببطء']}
});
Object.assign(EX_POSE,{barbell_row:'pull',table_row:'pull',backpack_row:'pull',superman:'core'});
Object.assign(PROG_PAT,{barbell_row:'row',table_row:'row',backpack_row:'row'});
const BACK_V=['pullup','chinup','lat_pulldown'],BACK_H=['barbell_row','db_row','cable_row','inverted_row','table_row','backpack_row'];
function ensureBack(p,u){
  if(!p.schedule)return;const ed=(u.system&&u.system.edits)||{},ok=i=>EX[i]&&canDoExercise(i,u.equipment,u.limits),uV={},uH={};
  const isBack=i=>EX[i]&&/ظهر/.test(EX[i].mu)&&i!=='deadlift';
  p.schedule.filter(d=>!d.isRest&&!ed[d.weekday]).forEach(d=>{
    const f=d.focus||'',pull=/سحب|ظهر/.test(f),low=/أرجل|سفلي/.test(f),up=/علوي/.test(f),full=/كامل/.test(f);
    if(!pull&&!up&&!full)return;
    const need=pull?(low?3:4):up?2:1,have=d.exIds.filter(isBack).length;if(have>=need)return;
    const cands=[...BACK_V.filter(ok).sort((a,b)=>(uV[a]||0)-(uV[b]||0)).slice(0,1),...BACK_H.filter(ok).sort((a,b)=>(uH[a]||0)-(uH[b]||0)),...(ok('superman')?['superman']:[])];
    const add=[];for(const c of cands){if(have+add.length>=need)break;if(!d.exIds.includes(c))add.push(c);}
    if(!add.length)return;add.forEach(c=>{if(BACK_V.includes(c))uV[c]=(uV[c]||0)+1;else uH[c]=(uH[c]||0)+1;});
    const max=d.exIds.length;let base=[...d.exIds];
    let g=0;while(base.length&&base.length+add.length>max&&g++<50){let k=-1;for(let j=base.length-1;j>=0;j--){const id=base[j];if(!isBack(id)&&!PROG_CORE.has(id)&&EX[id]&&/كتف|ترايسبس|صدر/.test(EX[id].mu)){k=j;break;}}if(k<0)k=base.length-1;base.splice(k,1);}
    d.exIds=[base[0],add[0],base[1],...add.slice(1),...base.slice(2)].filter(Boolean);
  });
}
function diversify(p,u){
  if(!p.schedule)return;const ed=(u.system&&u.system.edits)||{},prev={};
  p.schedule.filter(d=>!d.isRest&&!ed[d.weekday]).forEach(d=>{
    const f=d.focus||'',t=(/أرجل|سفلي/.test(f)&&!/علوي|دفع|سحب|ظهر|كامل/.test(f))?'L':/علوي/.test(f)?'U':null;if(!t)return;
    const before=prev[t];prev[t]=[...d.exIds];if(!before)return;
    const taken=new Set(d.exIds);let sw=0;
    d.exIds=d.exIds.map((id,i)=>{
      if(i===0||!before.includes(id)||sw>=Math.ceil(d.exIds.length/2))return id;
      const pat=PROG_PAT[id],alt=[...((EX[id]&&EX[id].alts)||[]),...Object.keys(EX).filter(k=>pat&&PROG_PAT[k]===pat)].find(k=>k!==id&&EX[k]&&!taken.has(k)&&!before.includes(k)&&canDoExercise(k,u.equipment,u.limits));
      if(alt){taken.add(alt);sw++;return alt;}return id;});
  });
}
